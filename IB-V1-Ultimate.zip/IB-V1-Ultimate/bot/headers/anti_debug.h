#pragma once

void anti_debug_init(void);
void anti_debug_check(void);
