#pragma once

#include "users.h"

int theme_exists(const char *theme_name);
char **get_available_themes(int *count);
void free_theme_list(char **themes, int count);

char *load_theme_file(const char *filename, const User *user);
void free_theme_string(char *str);

typedef struct {
    char user_prompt[128];
    char pass_prompt[128];
} LoginTheme;

LoginTheme *load_login_theme(const User *user);
void free_login_theme(LoginTheme *theme);

char *load_banner(const User *user);

char *load_placeholder(const User *user);
char *load_placeholder_with_subs(const User *user, const char *username);

char *process_string_colors(const char *input);

char *handle_prefix_command(const User *user, const char *command);

/* themed output: {COLOR} tags resolved from themes/colors.txt.
   only error paths may use hardcoded colors directly. */
int themed_snprintf(char *dst, size_t n, const char *fmt, ...);
int send_themed(int sock, const char *fmt, ...);
