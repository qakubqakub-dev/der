#!/bin/sh
# honeyblock.sh - block every ip/subnet listed in honeypots.txt
# via a dedicated iptables chain hooked into INPUT, OUTPUT, FORWARD.
#
# usage:
#   ./honeyblock.sh            # (re)load blocks
#   ./honeyblock.sh unblock    # remove all honeyblock rules

set -u

CHAIN="HONEYBLOCK"
DIR="$(cd "$(dirname "$0")" && pwd)"
LIST="$DIR/honeypots.txt"

[ "$(id -u)" -eq 0 ] || { echo "need root"; exit 1; }
[ -f "$LIST" ] || { echo "missing: $LIST"; exit 1; }

case "${1:-block}" in
    unblock|flush)
        for c in INPUT OUTPUT FORWARD; do
            while iptables -C "$c" -j "$CHAIN" 2>/dev/null; do
                iptables -D "$c" -j "$CHAIN"
            done
        done
        iptables -F "$CHAIN" 2>/dev/null
        iptables -X "$CHAIN" 2>/dev/null
        echo "honeyblock removed"
        exit 0
        ;;
esac

# (re)create chain, drop anything stale from a previous run
iptables -N "$CHAIN" 2>/dev/null
iptables -F "$CHAIN"

# validate + add, one rule per entry (ips and CIDRs pass through as-is)
added=0
skipped=0
while IFS= read -r entry || [ -n "$entry" ]; do
    # strip CR, whitespace, comments, blanks
    entry=$(printf '%s' "$entry" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    case "$entry" in
        ''|'#'*) continue ;;
    esac

    if printf '%s' "$entry" | grep -Eq '^[0-9]{1,3}(\.[0-9]{1,3}){3}$'; then
        octets_ok=1
        oifs=$(printf '%s' "$entry" | tr '.' ' ')
        for o in $oifs; do
            [ "$o" -le 255 ] || { octets_ok=0; break; }
        done
        [ "$octets_ok" -eq 1 ] || { skipped=$((skipped + 1)); echo "skip bad ip: $entry"; continue; }
    elif printf '%s' "$entry" | grep -Eq '^[0-9]{1,3}(\.[0-9]{1,3}){3}/[0-9]{1,2}$'; then
        pref=${entry#*/}
        [ "$pref" -le 32 ] || { skipped=$((skipped + 1)); echo "skip bad cidr: $entry"; continue; }
    else
        skipped=$((skipped + 1))
        echo "skip unparseable: $entry"
        continue
    fi

    iptables -A "$CHAIN" -s "$entry" -j DROP
    added=$((added + 1))
done < "$LIST"

# hook chain at the top of each direction (idempotent)
for c in INPUT OUTPUT FORWARD; do
    while iptables -C "$c" -j "$CHAIN" 2>/dev/null; do
        iptables -D "$c" -j "$CHAIN"
    done
    iptables -I "$c" 1 -j "$CHAIN"
done

echo "honeyblock loaded: $added blocked, $skipped skipped"
