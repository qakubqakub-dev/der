#define _GNU_SOURCE

#include "headers/dns.h"
#include "headers/tls.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int build_query(const char *host, uint8_t *buf, uint16_t txid) {
    buf[0] = (txid >> 8) & 0xff;
    buf[1] = txid & 0xff;
    buf[2] = 0x01; /* RD */
    buf[3] = 0x00;
    buf[4] = 0x00; buf[5] = 0x01; /* QDCOUNT */
    buf[6] = 0x00; buf[7] = 0x00;
    buf[8] = 0x00; buf[9] = 0x00;
    buf[10] = 0x00; buf[11] = 0x00;
    int p = 12;
    const char *label = host;
    while (*label) {
        const char *dot = strchr(label, '.');
        int sl = dot ? (int)(dot - label) : (int)strlen(label);
        if (sl <= 0 || sl > 63 || p + sl + 1 >= 512) return -1;
        buf[p++] = (uint8_t)sl;
        memcpy(buf + p, label, (size_t)sl);
        p += sl;
        if (!dot) break;
        label = dot + 1;
    }
    if (p + 5 >= 512) return -1;
    buf[p++] = 0x00;
    buf[p++] = 0x00; buf[p++] = 0x01; /* A */
    buf[p++] = 0x00; buf[p++] = 0x01; /* IN */
    return p;
}

/* skip a possibly-compressed name, return new offset or -1 */
static int skip_name(const uint8_t *m, int len, int off) {
    int jumped = 0;
    int orig = off;
    while (off < len) {
        uint8_t c = m[off];
        if ((c & 0xc0) == 0xc0) {
            if (off + 1 >= len) return -1;
            if (!jumped) orig = off + 2;
            off = ((c & 0x3f) << 8) | m[off + 1];
            jumped = 1;
            continue;
        }
        if (c == 0) return jumped ? orig : off + 1;
        off += 1 + c;
    }
    return -1;
}

static int parse_resp(const uint8_t *m, int len, uint16_t txid, struct in_addr *addr) {
    if (len < 12) return -1;
    if (((m[0] << 8) | m[1]) != txid) return -1;
    if ((m[3] & 0x0f) != 0) return -1; /* RCODE != 0 */
    int qd = (m[4] << 8) | m[5];
    int an = (m[6] << 8) | m[7];
    int off = 12;
    for (int i = 0; i < qd; i++) {
        off = skip_name(m, len, off);
        if (off < 0 || off + 4 > len) return -1;
        off += 4;
    }
    for (int i = 0; i < an; i++) {
        off = skip_name(m, len, off);
        if (off < 0 || off + 10 > len) return -1;
        int type = (m[off] << 8) | m[off + 1];
        int cls = (m[off + 2] << 8) | m[off + 3];
        int rdlen = (m[off + 8] << 8) | m[off + 9];
        off += 10;
        if (off + rdlen > len) return -1;
        if (type == 1 && cls == 1 && rdlen == 4) {
            memcpy(addr, m + off, 4);
            return 0;
        }
        off += rdlen;
    }
    return -1;
}

/* DNS-over-TLS (port 853): 2-byte length-prefixed query over tls.c */
static const uint32_t dot_servers[] = {0x09090909, 0x01010101, 0x08080808, 0x08080404};

static int query_dot(uint32_t ns, const uint8_t *q, int ql, uint16_t txid, struct in_addr *addr) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return -1;
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons(853);
    d.sin_addr.s_addr = ns;
    int r = connect(s, (struct sockaddr *)&d, sizeof(d));
    if (r < 0 && errno != EINPROGRESS) { close(s); return -1; }
    if (r < 0) {
        struct pollfd p = {s, POLLOUT, 0};
        if (poll(&p, 1, 3000) <= 0) { close(s); return -1; }
        int e = 0;
        socklen_t el = sizeof(e);
        getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
        if (e != 0) { close(s); return -1; }
    }
    fcntl(s, F_SETFL, fl);
    TLSContext *tls = tls_connect(s, NULL, 0);
    if (!tls) { close(s); return -1; }
    uint8_t msg[514];
    msg[0] = (uint8_t)((ql >> 8) & 0xff);
    msg[1] = (uint8_t)(ql & 0xff);
    memcpy(msg + 2, q, (size_t)ql);
    if (tls_write(tls, msg, ql + 2) < 0) {
        tls_close(tls);
        close(s);
        return -1;
    }
    uint8_t resp[2048];
    int total = 0;
    /* slide for [len][txid] marker: server may coalesce records or
       interleave tickets, so the answer is not always first. */
    uint8_t th = (uint8_t)((txid >> 8) & 0xff);
    uint8_t tl = (uint8_t)(txid & 0xff);
    while (total < (int)sizeof(resp)) {
        int n = tls_read(tls, resp + total, (int)sizeof(resp) - total);
        if (n <= 0) break;
        total += n;
        for (int i = 0; i + 3 < total; i++) {
            if (resp[i + 2] == th && resp[i + 3] == tl) {
                int plen = (resp[i] << 8) | resp[i + 1];
                if (plen > 0 && i + 2 + plen <= total) {
                    if (parse_resp(resp + i + 2, plen, txid, addr) == 0) {
                        tls_close(tls);
                        close(s);
                        return 0;
                    }
                    break;
                }
            }
        }
    }
    tls_close(tls);
    close(s);
    return -1;
}

int dns_resolve(const char *host, struct in_addr *addr) {
    struct in_addr tmp;
    if (!host || !*host || !addr) return -1;
    if (strlen(host) > 253) return -1;
    /* literal IP: no lookup needed */
    if (inet_pton(AF_INET, host, &tmp) == 1) {
        *addr = tmp;
        return 0;
    }
    /* labels sanity: letters/digits/hyphen/dots only */
    for (const char *c = host; *c; c++) {
        char ch = *c;
        if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
              (ch >= '0' && ch <= '9') || ch == '-' || ch == '.')) return -1;
    }
    uint8_t q[512];
    uint16_t txid = (uint16_t)(rand() & 0xffff);
    int ql = build_query(host, q, txid);
    if (ql < 0) return -1;
    /* DoT-only: no plain UDP fallback */
    for (size_t si = 0; si < sizeof(dot_servers) / sizeof(dot_servers[0]); si++) {
        if (query_dot(dot_servers[si], q, ql, txid, addr) == 0) return 0;
    }
    return -1;
}
