#pragma once

#include "users.h"

#define RESP_SZ 8192

void handle_command(User *user, const char *cmd, int sock, const char *ip);
