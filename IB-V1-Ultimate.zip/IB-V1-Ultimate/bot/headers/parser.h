#pragma once

void handle_line(const char *line, int sock);
void parser_stop(void);
