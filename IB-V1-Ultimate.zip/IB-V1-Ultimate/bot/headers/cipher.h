#pragma once

#include <stddef.h>
#include <stdint.h>

#define CHACHA20_KEY_SIZE 32
#define CHACHA20_NONCE_SIZE 12
#define CHACHA20_BLOCK_SIZE 64

typedef struct {
    uint32_t state[16];
} chacha20_ctx;

int recv_decrypt(const uint8_t *in, size_t in_len, uint8_t *out, size_t *out_len);
