#pragma once

/* minimal code colors (theme content itself comes from themes/colors.txt).
   only error/fallback paths may use these directly. */
#define LIME "\033[92m"
#define RED "\033[31m"
#define GRAY "\033[0;90m"
#define RESET "\033[0m"
