#pragma once

#include <stdint.h>

typedef struct {
    char ip[64];
    char host[256];
    int port;
    int duration;
    int psize;
    char msg[1024];
    char path[256];
    int tcpflags;
    int srcport;
    char spoof[512];
    volatile int *active;
} flood_args;

/* one-shot flood workers. each runs until end_time. */
void *udp_flood(void *arg);
void *icmp_flood(void *arg);
void *tcp_flood(void *arg);
void *https_flood(void *arg);
void *http_flood(void *arg);
void *https_classic_flood(void *arg);
void *raknet_flood(void *arg);
void *minecraft_flood(void *arg);
void *tcpraw_flood(void *arg);
void *udpraw_flood(void *arg);

/* shared helpers (attacks.c) */
int build_payload(const flood_args *a, unsigned char *out, int cap);
uint16_t csum(const void *data, int len);
