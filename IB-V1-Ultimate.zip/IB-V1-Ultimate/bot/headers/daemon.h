#pragma once

void daemonize(int argc, char **argv);
