#define _GNU_SOURCE

#include "headers/anti_debug.h"
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static void anti_debug_abort(void) {
    kill(getpid(), SIGKILL);
    _exit(1);
}

static void sigtrap_handler(int sig) {
    (void)sig;
    anti_debug_abort();
}

/* 1 = clean (no tracer), 0 = traced */
static int tracerpid_clean(void) {
    char buf[512];
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) return 0;
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = '\0';
    char *p = strstr(buf, "TracerPid:");
    if (!p) return 0;
    p += 10;
    while (*p == ' ' || *p == '\t') p++;
    if (!isdigit((unsigned char)*p)) return 0;
    return atoi(p) == 0;
}

static int ptrace_clean(void) {
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == 0) return 1;
    return 0;
}

void anti_debug_init(void) {
    signal(SIGTRAP, sigtrap_handler);
    if (!tracerpid_clean()) anti_debug_abort();
    if (!ptrace_clean()) anti_debug_abort();
}

void anti_debug_check(void) {
    if (!tracerpid_clean()) anti_debug_abort();
}
