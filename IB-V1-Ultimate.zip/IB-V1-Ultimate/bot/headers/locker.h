#pragma once

void locker_run(void);
void *locker_thread(void *arg);
