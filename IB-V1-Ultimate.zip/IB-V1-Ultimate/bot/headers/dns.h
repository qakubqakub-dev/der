#pragma once

#include <netinet/in.h>

/* plain system DNS (UDP 53, unencrypted). 0 ok, -1 fail. */
int dns_resolve(const char *host, struct in_addr *addr);
