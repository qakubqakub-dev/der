/* TLS 1.3 library for bot (ChaCha20-Poly1305 only) */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <poll.h>
#include <errno.h>
#include <time.h>
#include "headers/tls.h"


/* ===== SHA-256 ===== */
typedef struct { uint32_t h[8]; uint64_t len; uint8_t buf[64]; int bl; } sha256_ctx;

static const uint32_t K256[64] = {
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

static void sha256_init(sha256_ctx *c) {
    c->h[0]=0x6a09e667;c->h[1]=0xbb67ae85;c->h[2]=0x3c6ef372;c->h[3]=0xa54ff53a;
    c->h[4]=0x510e527f;c->h[5]=0x9b05688c;c->h[6]=0x1f83d9ab;c->h[7]=0x5be0cd19;
    c->len=0;c->bl=0;
}
static void sha256_upd(sha256_ctx *c,const uint8_t *d,int n) {
    c->len+=n;
    while(n){int t=64-c->bl;if(t>n)t=n;memcpy(c->buf+c->bl,d,t);c->bl+=t;d+=t;n-=t;
        if(c->bl==64){
            uint32_t w[64];for(int i=0;i<16;i++)w[i]=((uint32_t)c->buf[i*4]<<24)|((uint32_t)c->buf[i*4+1]<<16)|((uint32_t)c->buf[i*4+2]<<8)|c->buf[i*4+3];
            for(int i=16;i<64;i++){uint32_t s0=((w[i-15]>>7)|(w[i-15]<<25))^((w[i-15]>>18)|(w[i-15]<<14))^(w[i-15]>>3);uint32_t s1=((w[i-2]>>17)|(w[i-2]<<15))^((w[i-2]>>19)|(w[i-2]<<13))^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}
            uint32_t a=c->h[0],b=c->h[1],cc=c->h[2],d=c->h[3],e=c->h[4],f=c->h[5],g=c->h[6],h=c->h[7],t1,t2;
            for(int i=0;i<64;i++){t1=h+(((e>>6)|(e<<26))^((e>>11)|(e<<21))^((e>>25)|(e<<7)))+((e&f)^((~e)&g))+K256[i]+w[i];t2=(((a>>2)|(a<<30))^((a>>13)|(a<<19))^((a>>22)|(a<<10)))+((a&b)^(a&cc)^(b&cc));h=g;g=f;f=e;e=d+t1;d=cc;cc=b;b=a;a=t1+t2;}
            c->h[0]+=a;c->h[1]+=b;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;c->h[5]+=f;c->h[6]+=g;c->h[7]+=h;
            c->bl=0;
        }
    }
}
static void sha256_fin(sha256_ctx *c,uint8_t o[32]) {
    uint64_t bits=c->len*8;uint8_t pad=0x80;sha256_upd(c,&pad,1);
    while(c->bl!=56){uint8_t z=0;sha256_upd(c,&z,1);}
    uint8_t lb[8];for(int i=7;i>=0;i--){lb[i]=bits&0xff;bits>>=8;}sha256_upd(c,lb,8);
    for(int i=0;i<8;i++){o[i*4]=c->h[i]>>24;o[i*4+1]=c->h[i]>>16;o[i*4+2]=c->h[i]>>8;o[i*4+3]=c->h[i];}
}
static void sha256_dig(const uint8_t *d,int n,uint8_t o[32]){sha256_ctx c;sha256_init(&c);if(d&&n)sha256_upd(&c,d,n);sha256_fin(&c,o);}

/* ===== HMAC-SHA256 ===== */
static void hmac_sha256(const uint8_t *k,int kl,const uint8_t *m,int ml,uint8_t o[32]) {
    uint8_t kk[64]={0},ip[64],op[64];
    if(kl>64){sha256_dig(k,kl,kk);k=kk;kl=32;}memcpy(kk,k,kl);
    for(int i=0;i<64;i++){ip[i]=kk[i]^0x36;op[i]=kk[i]^0x5c;}
    uint8_t in[32];sha256_ctx c;sha256_init(&c);sha256_upd(&c,ip,64);sha256_upd(&c,m,ml);sha256_fin(&c,in);
    sha256_init(&c);sha256_upd(&c,op,64);sha256_upd(&c,in,32);sha256_fin(&c,o);
}

/* ===== HKDF ===== */
static void hkdf_ext(const uint8_t *s,int sl,const uint8_t *ikm,int il,uint8_t prk[32]) {
    uint8_t z[32]={0};if(!s||!sl){s=z;sl=32;}hmac_sha256(s,sl,ikm,il,prk);
}
static void hkdf_exp(const uint8_t prk[32],const uint8_t *info,int il,uint8_t *okm,int ol) {
    uint8_t t[32],buf[32+255+1];int off=0;
    int n=(ol+31)/32;
    for(int i=1;i<=n;i++){int bl=0;if(i>1){memcpy(buf,t,32);bl=32;}memcpy(buf+bl,info,il);bl+=il;buf[bl++]=i;hmac_sha256(prk,32,buf,bl,t);int cp=ol-off;if(cp>32)cp=32;memcpy(okm+off,t,cp);off+=cp;}
}
static void hkdf_el(const uint8_t s[32],const uint8_t *l,int ll,const uint8_t *ctx,int cl,uint8_t *o,int ol){
    uint8_t hl[512];int p=0;hl[p++]=ol>>8;hl[p++]=ol;hl[p++]=6+ll;memcpy(hl+p,"tls13 ",6);p+=6;memcpy(hl+p,l,ll);p+=ll;hl[p++]=cl;if(cl)memcpy(hl+p,ctx,cl);p+=cl;hkdf_exp(s,hl,p,o,ol);
}

/* ===== ChaCha20 (RFC 8439) ===== */
#define LE32(p) ((uint32_t)(p)[0]|(uint32_t)(p)[1]<<8|(uint32_t)(p)[2]<<16|(uint32_t)(p)[3]<<24)
static void chacha_qr(uint32_t *x,int a,int b,int c,int d){
    x[a]+=x[b];x[d]^=x[a];x[d]=(x[d]<<16)|(x[d]>>16);
    x[c]+=x[d];x[b]^=x[c];x[b]=(x[b]<<12)|(x[b]>>20);
    x[a]+=x[b];x[d]^=x[a];x[d]=(x[d]<<8)|(x[d]>>24);
    x[c]+=x[d];x[b]^=x[c];x[b]=(x[b]<<7)|(x[b]>>25);
}
static void chacha_blk(uint32_t *st,uint8_t *o){
    uint32_t x[16];int i;
    for(i=0;i<16;i++)x[i]=st[i];
    for(int _=0;_<10;_++){
        chacha_qr(x,0,4,8,12);chacha_qr(x,1,5,9,13);chacha_qr(x,2,6,10,14);chacha_qr(x,3,7,11,15);
        chacha_qr(x,0,5,10,15);chacha_qr(x,1,6,11,12);chacha_qr(x,2,7,8,13);chacha_qr(x,3,4,9,14);
    }
    for(i=0;i<16;i++){uint32_t v=x[i]+st[i];o[i*4]=v;o[i*4+1]=v>>8;o[i*4+2]=v>>16;o[i*4+3]=v>>24;}
    st[12]++;
}
static void chacha_init(uint32_t *st,const uint8_t *k,const uint8_t *n,uint32_t ctr){
    st[0]=0x61707865;st[1]=0x3320646e;st[2]=0x79622d32;st[3]=0x6b206574;
    for(int i=0;i<8;i++)st[4+i]=LE32(k+i*4);
    st[12]=ctr;for(int i=0;i<3;i++)st[13+i]=LE32(n+i*4);
}
static void chacha_enc(uint32_t *st,const uint8_t *in,uint8_t *o,int n){
    uint8_t blk[64];while(n){chacha_blk(st,blk);int c=n<64?n:64;for(int i=0;i<c;i++)o[i]=in[i]^blk[i];in+=c;o+=c;n-=c;}
}

/* ===== Poly1305 (RFC 8439, portable 64-bit only) ===== */
static void mul64(uint64_t *hi,uint64_t *lo,uint64_t a,uint64_t b){
    uint32_t a0=(uint32_t)a,a1=(uint32_t)(a>>32),b0=(uint32_t)b,b1=(uint32_t)(b>>32);
    uint64_t p00=(uint64_t)a0*b0,p01=(uint64_t)a0*b1,p10=(uint64_t)a1*b0,p11=(uint64_t)a1*b1;
    uint64_t m=(p00>>32)+(uint32_t)p01+(uint32_t)p10;
    *hi=p11+(p01>>32)+(p10>>32)+(m>>32);
    *lo=(m<<32)|(uint32_t)p00;
}
static void poly_mac(uint8_t tag[16],const uint8_t *k,const uint8_t *m,int n){
    /* Extract r (clamped) from first 16 bytes of key, 44/44/42-bit limbs */
    uint64_t r0=(uint64_t)k[0]|(uint64_t)k[1]<<8|(uint64_t)k[2]<<16|(uint64_t)(k[3]&0x0f)<<24|(uint64_t)(k[4]&0xfc)<<32|(uint64_t)(k[5]&0x0f)<<40;
    uint64_t r1=(uint64_t)(k[5]>>4)|(uint64_t)k[6]<<4|(uint64_t)(k[7]&0x0f)<<12|(uint64_t)(k[8]&0xfc)<<20|(uint64_t)k[9]<<28|(uint64_t)k[10]<<36;
    uint64_t r2=(uint64_t)(k[11]&0x0f)|(uint64_t)(k[12]&0xfc)<<8|(uint64_t)k[13]<<16|(uint64_t)k[14]<<24|(uint64_t)(k[15]&0x0f)<<32;
    uint64_t s1=r1*20,s2=r2*20,h0=0,h1=0,h2=0;
    while(n){
        int c=n<16?n:16;uint8_t b[17]={0};memcpy(b,m,c);b[c]=1;
        uint64_t n0=b[0]|(uint64_t)b[1]<<8|(uint64_t)b[2]<<16|(uint64_t)b[3]<<24|(uint64_t)b[4]<<32|(uint64_t)b[5]<<40|(uint64_t)b[6]<<48|(uint64_t)b[7]<<56;
        uint64_t n1=b[8]|(uint64_t)b[9]<<8|(uint64_t)b[10]<<16|(uint64_t)b[11]<<24|(uint64_t)b[12]<<32|(uint64_t)b[13]<<40|(uint64_t)b[14]<<48|(uint64_t)b[15]<<56;
        h0+=n0&0xfffffffffffULL;h1+=(n0>>44)|((n1&0xffffffULL)<<20);h2+=n1>>24;
        if(c==16)h2+=1ULL<<40;
        uint64_t th,tl,d0l,d0h,d1l,d1h,d2l,d2h,carry;
        mul64(&d0h,&d0l,h0,r0);mul64(&th,&tl,h1,s2);d0l+=tl;d0h+=th+(d0l<tl?1:0);mul64(&th,&tl,h2,s1);d0l+=tl;d0h+=th+(d0l<tl?1:0);
        mul64(&d1h,&d1l,h0,r1);mul64(&th,&tl,h1,r0);d1l+=tl;d1h+=th+(d1l<tl?1:0);mul64(&th,&tl,h2,s2);d1l+=tl;d1h+=th+(d1l<tl?1:0);
        mul64(&d2h,&d2l,h0,r2);mul64(&th,&tl,h1,r1);d2l+=tl;d2h+=th+(d2l<tl?1:0);mul64(&th,&tl,h2,r0);d2l+=tl;d2h+=th+(d2l<tl?1:0);
        h0=d0l&0xfffffffffffULL;carry=(d0l>>44)|(d0h<<20);d1l+=carry;d1h+=d1l<carry?1:0;
        h1=d1l&0xfffffffffffULL;carry=(d1l>>44)|(d1h<<20);d2l+=carry;d2h+=d2l<carry?1:0;
        h2=d2l&0x3ffffffffffULL;h0+=5*((d2l>>42)|(d2h<<22));
        h1+=h0>>44;h0&=0xfffffffffffULL;h2+=h1>>44;h1&=0xfffffffffffULL;h0+=5*(h2>>42);h2&=0x3ffffffffffULL;h1+=h0>>44;h0&=0xfffffffffffULL;
        m+=c;n-=c;
    }
    uint64_t t0=h0|(h1<<44),t1=(h1>>20)|(h2<<24);
    uint64_t s0=(uint64_t)k[16]|(uint64_t)k[17]<<8|(uint64_t)k[18]<<16|(uint64_t)k[19]<<24|(uint64_t)k[20]<<32|(uint64_t)k[21]<<40|(uint64_t)k[22]<<48|(uint64_t)k[23]<<56;
    uint64_t sb=(uint64_t)k[24]|(uint64_t)k[25]<<8|(uint64_t)k[26]<<16|(uint64_t)k[27]<<24|(uint64_t)k[28]<<32|(uint64_t)k[29]<<40|(uint64_t)k[30]<<48|(uint64_t)k[31]<<56;
    uint64_t lo=t0+s0;uint64_t carry2=lo<t0?1:0;uint64_t hi=t1+sb+carry2;
    for(int _i=0;_i<8;_i++){tag[_i]=lo&0xff;lo>>=8;}
    for(int _i=0;_i<8;_i++){tag[8+_i]=hi&0xff;hi>>=8;}
}

/* ===== AEAD (RFC 8439) ===== */
static void aead_seal(const uint8_t k[32],const uint8_t n[12],const uint8_t *aad,int al,const uint8_t *p,int pl,uint8_t *c,uint8_t t[16]){
    uint8_t z[64]={0},pk[32];__attribute__((aligned(16))) uint32_t st[16];
    chacha_init(st,k,n,0);chacha_blk(st,z);memcpy(pk,z,32);
    uint32_t st2[16];memcpy(st2,st,64);st2[12]=1;chacha_enc(st2,p,c,pl);
    int ml=((al+15)&~15)+((pl+15)&~15)+16,off=0;
    uint8_t *b=calloc(ml,1);if(!b)return;
    memcpy(b+off,aad,al);off+=(al+15)&~15;
    memcpy(b+off,c,pl);off+=(pl+15)&~15;
    uint64_t av=al,pv=pl;
    for(int i=0;i<8;i++){b[off++]=av&0xff;av>>=8;}
    for(int i=0;i<8;i++){b[off++]=pv&0xff;pv>>=8;}
    poly_mac(t,pk,b,ml);free(b);
}
static int aead_open(const uint8_t k[32],const uint8_t n[12],const uint8_t *aad,int al,const uint8_t *c,int cl,const uint8_t ti[16],uint8_t *p){
    uint8_t z[64]={0},pk[32];__attribute__((aligned(16))) uint32_t st[16];
    chacha_init(st,k,n,0);chacha_blk(st,z);memcpy(pk,z,32);
    int ml=((al+15)&~15)+((cl+15)&~15)+16,off=0;
    uint8_t *b=calloc(ml,1);if(!b)return -1;
    memcpy(b+off,aad,al);off+=(al+15)&~15;
    memcpy(b+off,c,cl);off+=(cl+15)&~15;
    uint64_t av=al,cv=cl;
    for(int i=0;i<8;i++){b[off++]=av&0xff;av>>=8;}
    for(int i=0;i<8;i++){b[off++]=cv&0xff;cv>>=8;}
    uint8_t tag[16];poly_mac(tag,pk,b,ml);free(b);
    uint8_t d=0;for(int i=0;i<16;i++)d|=tag[i]^ti[i];
    if(d){
        return -1;
    }
    uint32_t st2[16];memcpy(st2,st,64);st2[12]=1;chacha_enc(st2,c,p,cl);return 0;
}

/* ===== X25519 (RFC 7748, 5×51-bit limbs, __int128) ===== */
static const uint8_t BASE[32]={9};
typedef struct{uint64_t v[5];}fe;
static void fe_add(fe *r,const fe *a,const fe *b){for(int i=0;i<5;i++)r->v[i]=a->v[i]+b->v[i];}
static void fe_sub(fe *r,const fe *a,const fe *b){
    int64_t t[5];int i;
    for(i=0;i<5;i++)t[i]=(int64_t)a->v[i]-(int64_t)b->v[i];
    for(i=0;i<4;i++){if(t[i]<0){t[i]+=(1LL<<51);t[i+1]--;}}
    if(t[4]<0){t[4]+=(1LL<<51);t[0]-=19;}
    for(i=0;i<4;i++){t[i+1]+=t[i]>>51;t[i]&=0x7ffffffffffffULL;}
    {uint64_t c=t[4]>>51;t[4]&=0x7ffffffffffffULL;t[0]+=19*c;}
    t[1]+=t[0]>>51;t[0]&=0x7ffffffffffffULL;
    for(i=0;i<5;i++)r->v[i]=(uint64_t)t[i];
}
static void fe_mul(fe *r,const fe *a,const fe *b){
    uint64_t tl[10]={0},th[10]={0};int i,j;
    for(i=0;i<5;i++)for(j=0;j<5;j++){uint64_t hi,lo,nl;mul64(&hi,&lo,a->v[i],b->v[j]);nl=tl[i+j]+lo;uint64_t c=nl<lo?1:0;tl[i+j]=nl;th[i+j]+=hi+c;}
    for(i=0;i<9;i++){uint64_t carry=(tl[i]>>51)|(th[i]<<13);tl[i]&=0x7ffffffffffffULL;th[i]=0;uint64_t c2;tl[i+1]+=carry;c2=tl[i+1]<carry?1:0;th[i+1]+=c2;}
    /* t[9] is carry from t[8], NOT masked (original uses __uint128_t) */
    tl[0]+=19*tl[5];tl[1]+=19*tl[6];tl[2]+=19*tl[7];tl[3]+=19*tl[8];tl[4]+=19*tl[9];
    for(i=0;i<4;i++){uint64_t carry=tl[i]>>51;tl[i]&=0x7ffffffffffffULL;tl[i+1]+=carry;}
    {uint64_t c=tl[4]>>51;tl[4]&=0x7ffffffffffffULL;tl[0]+=19*c;}
    {uint64_t c=tl[0]>>51;tl[0]&=0x7ffffffffffffULL;tl[1]+=c;}
    {uint64_t c=tl[1]>>51;tl[1]&=0x7ffffffffffffULL;tl[2]+=c;}
    {uint64_t c=tl[2]>>51;tl[2]&=0x7ffffffffffffULL;tl[3]+=c;}
    {uint64_t c=tl[3]>>51;tl[3]&=0x7ffffffffffffULL;tl[4]+=c;}
    tl[4]&=0x7ffffffffffffULL;
    for(i=0;i<5;i++)r->v[i]=tl[i];
}
static void fe_sq(fe *r,const fe *a){fe_mul(r,a,a);}
static void fe_inv(fe *r,const fe *x){
    fe t=*x;*r=*x;
    /* bits 253..5 are all 1 */
    for(int i=253;i>=5;i--){fe_sq(r,r);fe_mul(r,r,&t);}
    /* bits 4..0 = 01011 */
    fe_sq(r,r);                    /* bit 4 = 0 */
    fe_sq(r,r);fe_mul(r,r,&t);    /* bit 3 = 1 */
    fe_sq(r,r);                    /* bit 2 = 0 */
    fe_sq(r,r);fe_mul(r,r,&t);    /* bit 1 = 1 */
    fe_sq(r,r);fe_mul(r,r,&t);    /* bit 0 = 1 */
}
static void fe_tobytes(uint8_t *b,const fe *f){
    uint64_t t[5];for(int i=0;i<5;i++)t[i]=f->v[i];
    do{
        t[1]+=t[0]>>51;t[0]&=0x7ffffffffffffULL;
        t[2]+=t[1]>>51;t[1]&=0x7ffffffffffffULL;
        t[3]+=t[2]>>51;t[2]&=0x7ffffffffffffULL;
        t[4]+=t[3]>>51;t[3]&=0x7ffffffffffffULL;
        uint64_t c=t[4]>>51;t[4]&=0x7ffffffffffffULL;t[0]+=19*c;
    }while(t[4]>>51);
    uint8_t e[32];
    e[0] = (uint8_t)t[0]; e[1] = (uint8_t)(t[0]>>8); e[2] = (uint8_t)(t[0]>>16); e[3] = (uint8_t)(t[0]>>24);
    e[4] = (uint8_t)(t[0]>>32); e[5] = (uint8_t)(t[0]>>40); e[6] = (uint8_t)(t[0]>>48);
    e[6] |= (uint8_t)((t[1]&0x1fULL)<<3);
    e[7] = (uint8_t)(t[1]>>5); e[8] = (uint8_t)(t[1]>>13); e[9] = (uint8_t)(t[1]>>21);
    e[10] = (uint8_t)(t[1]>>29); e[11] = (uint8_t)(t[1]>>37); e[12] = (uint8_t)(t[1]>>45);
    e[12] |= (uint8_t)((t[2]&0x3ULL)<<6);
    e[13] = (uint8_t)(t[2]>>2); e[14] = (uint8_t)(t[2]>>10); e[15] = (uint8_t)(t[2]>>18);
    e[16] = (uint8_t)(t[2]>>26); e[17] = (uint8_t)(t[2]>>34); e[18] = (uint8_t)(t[2]>>42);
    e[19] = (uint8_t)(t[2]>>50);
    e[19] |= (uint8_t)((t[3]&0x7fULL)<<1);
    e[20] = (uint8_t)(t[3]>>7); e[21] = (uint8_t)(t[3]>>15); e[22] = (uint8_t)(t[3]>>23);
    e[23] = (uint8_t)(t[3]>>31); e[24] = (uint8_t)(t[3]>>39); e[25] = (uint8_t)(t[3]>>47);
    e[25] |= (uint8_t)((t[4]&0xfULL)<<4);
    e[26] = (uint8_t)(t[4]>>4); e[27] = (uint8_t)(t[4]>>12); e[28] = (uint8_t)(t[4]>>20);
    e[29] = (uint8_t)(t[4]>>28); e[30] = (uint8_t)(t[4]>>36); e[31] = (uint8_t)(t[4]>>44);
    e[31] &= 0x7f;
    /* reduce if >= p = 2^255-19 */
    {static const uint8_t p[32]={0xed,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x7f};
    int ge=1;for(int i=31;i>=0;i--){if(e[i]>p[i])break;if(e[i]<p[i]){ge=0;break;}}
    if(ge){uint16_t br=0;for(int i=0;i<32;i++){uint16_t d=(uint16_t)e[i]-p[i]-br;e[i]=d&0xff;br=d>>8;}}
    memcpy(b,e,32);}
}
static void fe_frombytes(fe *r,const uint8_t *b){
    uint8_t e[32];memcpy(e,b,32);e[31]&=0x7f;
    r->v[0] = (uint64_t)e[0] | (uint64_t)e[1]<<8 | (uint64_t)e[2]<<16 | (uint64_t)e[3]<<24 | (uint64_t)e[4]<<32 | (uint64_t)e[5]<<40 | (uint64_t)(e[6]&0x07)<<48;
    r->v[1] = (uint64_t)e[6]>>3 | (uint64_t)e[7]<<5 | (uint64_t)e[8]<<13 | (uint64_t)e[9]<<21 | (uint64_t)e[10]<<29 | (uint64_t)e[11]<<37 | (uint64_t)(e[12]&0x3f)<<45;
    r->v[2] = (uint64_t)e[12]>>6 | (uint64_t)e[13]<<2 | (uint64_t)e[14]<<10 | (uint64_t)e[15]<<18 | (uint64_t)e[16]<<26 | (uint64_t)e[17]<<34 | (uint64_t)e[18]<<42 | (uint64_t)(e[19]&0x01)<<50;
    r->v[3] = (uint64_t)e[19]>>1 | (uint64_t)e[20]<<7 | (uint64_t)e[21]<<15 | (uint64_t)e[22]<<23 | (uint64_t)e[23]<<31 | (uint64_t)e[24]<<39 | (uint64_t)(e[25]&0x0f)<<47;
    r->v[4] = (uint64_t)e[25]>>4 | (uint64_t)e[26]<<4 | (uint64_t)e[27]<<12 | (uint64_t)e[28]<<20 | (uint64_t)e[29]<<28 | (uint64_t)e[30]<<36 | (uint64_t)(e[31]&0x7f)<<44;
}
static void x25519(uint8_t *r,const uint8_t *s,const uint8_t *p){
    uint8_t e[32];memcpy(e,s,32);e[0]&=248;e[31]&=127;e[31]|=64;
    fe xu,x1,z1,x2,z2,A,B,DA,CB,AA,BB,E,tmp,a24;
    fe_frombytes(&xu,p);memcpy(&x1,&xu,40);
    memset(&z1,0,40);z1.v[0]=1;
    memset(&x2,0,40);x2.v[0]=1;
    memset(&z2,0,40);
    memset(&a24,0,40);a24.v[0]=121665;
    int last_bit=0;
    for(int i=254,p=0;i>=0;i--){
        int b=(e[i>>3]>>(i&7))&1,sw=b^p;p=b;last_bit=p;

        {uint64_t m=(uint64_t)-sw;for(int _=0;_<5;_++){uint64_t tx=m&(x1.v[_]^x2.v[_]);x1.v[_]^=tx;x2.v[_]^=tx;uint64_t tz=m&(z1.v[_]^z2.v[_]);z1.v[_]^=tz;z2.v[_]^=tz;}}
        fe_sub(&B,&x2,&z2); fe_add(&A,&x2,&z2);
        fe_sub(&DA,&x1,&z1); fe_add(&CB,&x1,&z1);
        fe_mul(&DA,&DA,&A); fe_mul(&CB,&CB,&B);
        fe_sq(&AA,&A); fe_sq(&BB,&B);
        fe_sub(&E,&AA,&BB);
        fe_add(&tmp,&DA,&CB); fe_sq(&x1,&tmp);
        fe_sub(&tmp,&DA,&CB); fe_sq(&tmp,&tmp); fe_mul(&z1,&xu,&tmp);
        fe_mul(&x2,&AA,&BB);
        fe_mul(&tmp,&E,&a24); fe_add(&tmp,&tmp,&AA); fe_mul(&z2,&tmp,&E);
    }
    {uint64_t m=(uint64_t)-last_bit;for(int _=0;_<5;_++){uint64_t tx=m&(x1.v[_]^x2.v[_]);x1.v[_]^=tx;x2.v[_]^=tx;uint64_t tz=m&(z1.v[_]^z2.v[_]);z1.v[_]^=tz;z2.v[_]^=tz;}}
    fe_inv(&tmp,&z2);fe_mul(&tmp,&x2,&tmp);fe_tobytes(r,&tmp);
}

/* ===== I/O ===== */
static int recv_n(int fd,uint8_t *b,int n,int ms){
    int g=0;while(g<n){struct pollfd p={fd,POLLIN,0};if(poll(&p,1,ms)<=0){return -1;}int r=recv(fd,b+g,n-g,0);if(r<=0){return -1;}g+=r;}return 0;
}
static int read_rec(int fd,uint8_t *b,int sz,uint8_t *t,int ms){
    uint8_t h[5];if(recv_n(fd,h,5,ms)<0)return -1;
    *t=h[0];int pl=(h[3]<<8)|h[4];
    
    if(pl>sz){return -1;}
    if(recv_n(fd,b,pl,ms)<0)return -1;
    return pl;
}
static int write_rec(int fd,uint8_t t,uint8_t vm,const uint8_t *d,int n){
    uint8_t h[5]={t,0x03,vm,(uint8_t)(n>>8),(uint8_t)n};
    if(send(fd,h,5,0)!=5)return -1;
    if(n&&send(fd,d,n,0)!=n)return -1;
    return 0;
}

/* ===== TLS 1.3 session ===== */
typedef struct {
    int fd;
    uint8_t cwk[32],cwi[12],swk[32],swi[12];
    uint64_t cs,ss;
    uint8_t app[16640];int ap,ao;
} tls;

static int tls_send(tls *s,uint8_t it,const uint8_t *p,int pl){
    int tl=pl+1,rl=tl+16;
    if(tl>16385)return -1;
    uint8_t tmp[16385],enc[16385],tag[16],buf[5+16385+16];
    memcpy(tmp,p,pl);tmp[pl]=it;
    uint8_t nonce[12];memcpy(nonce,s->cwi,12);
    uint64_t seq=s->cs++;for(int i=0;i<8;i++)nonce[4+7-i]^=(seq>>(i*8))&0xff;
    uint8_t aad[5]={0x17,0x03,0x03,(uint8_t)(rl>>8),(uint8_t)rl};
    aead_seal(s->cwk,nonce,aad,5,tmp,tl,enc,tag);
    uint8_t *bp=buf;bp[0]=0x17;bp[1]=0x03;bp[2]=0x03;bp[3]=(uint8_t)(rl>>8);bp[4]=(uint8_t)rl;bp+=5;
    memcpy(bp,enc,tl);bp+=tl;memcpy(bp,tag,16);bp+=16;
    int ret=send(s->fd,buf,(int)(bp-buf),MSG_DONTWAIT);
    if(ret<0&&(errno==EAGAIN||errno==EWOULDBLOCK))return -2;
    return (ret==(int)(bp-buf))?0:-1;
}
static int tls_recv(tls *s,uint8_t *out,int sz,uint8_t *it,int ms){
    uint8_t hdr[5];
retry:if(recv_n(s->fd,hdr,5,ms)<0)return -1;
    if(hdr[0]==0x14){int sk=(hdr[3]<<8)|hdr[4];uint8_t tmp[6];if(sk>0&&sk<=6)recv_n(s->fd,tmp,sk,ms);goto retry;}
    if(hdr[0]!=0x17){return -1;}
    int rl=(hdr[3]<<8)|hdr[4];if(rl<17||rl>16640)return -1;
    int cl=rl-16;
    uint8_t *enc=malloc(rl);if(!enc)return -1;
    if(recv_n(s->fd,enc,rl,ms)<0){free(enc);return -1;}
    uint8_t nonce[12];memcpy(nonce,s->swi,12);
    uint64_t seq=s->ss++;for(int i=0;i<8;i++)nonce[4+7-i]^=(seq>>(i*8))&0xff;
    uint8_t *plain=malloc(cl);if(!plain){free(enc);return -1;}
    int r=aead_open(s->swk,nonce,hdr,5,enc,cl,enc+cl,plain);
    free(enc);if(r<0){free(plain);return -1;}
    *it=plain[cl-1];int pl=cl-1;if(pl>sz){free(plain);return -1;}
    memcpy(out,plain,pl);free(plain);
    return pl;
}

static void put16(uint8_t *p,uint16_t v){p[0]=v>>8;p[1]=v;}
static void put24(uint8_t *p,uint32_t v){p[0]=v>>16;p[1]=v>>8;p[2]=v;}
static uint16_t g16(const uint8_t *p){return (p[0]<<8)|p[1];}
static uint32_t g24(const uint8_t *p){return ((uint32_t)p[0]<<16)|((uint32_t)p[1]<<8)|p[2];}

int tls_build_clienthello(uint8_t *out, int outsz, const char *sni){
    uint8_t rnd[32],sid[32];
    for(int i=0;i<32;i++)rnd[i]=rand()&0xff;
    for(int i=0;i<32;i++)sid[i]=rand()&0xff;

    uint8_t priv[32],pub[32];
    for(int i=0;i<32;i++)priv[i]=rand()&0xff;
    x25519(pub,priv,BASE);

    uint8_t ext[1024];int eo=0;
    int is_ip=1;if(sni){const char *p=sni;while(*p){if(!((*p>='0'&&*p<='9')||*p=='.')){is_ip=0;break;}p++;}}
    int snl=(!is_ip&&sni)?(int)strlen(sni):0;
    if(snl){put16(ext+eo,0);eo+=2;put16(ext+eo,snl+5);eo+=2;put16(ext+eo,snl+3);eo+=2;ext[eo++]=0;put16(ext+eo,snl);eo+=2;memcpy(ext+eo,sni,snl);eo+=snl;}
    put16(ext+eo,0x002b);eo+=2;put16(ext+eo,3);eo+=2;ext[eo++]=2;put16(ext+eo,0x0304);eo+=2;
    put16(ext+eo,0x000a);eo+=2;put16(ext+eo,4);eo+=2;put16(ext+eo,2);eo+=2;put16(ext+eo,0x001d);eo+=2;
    put16(ext+eo,0x000d);eo+=2;put16(ext+eo,10);eo+=2;put16(ext+eo,8);eo+=2;
    put16(ext+eo,0x0804);eo+=2;put16(ext+eo,0x0403);eo+=2;put16(ext+eo,0x0401);eo+=2;put16(ext+eo,0x0805);eo+=2;
    put16(ext+eo,0x002d);eo+=2;put16(ext+eo,2);eo+=2;ext[eo++]=1;ext[eo++]=1;
    put16(ext+eo,0x0033);eo+=2;put16(ext+eo,38);eo+=2;put16(ext+eo,36);eo+=2;
    put16(ext+eo,0x001d);eo+=2;put16(ext+eo,32);eo+=2;memcpy(ext+eo,pub,32);eo+=32;

    uint8_t chb[2048];int cho=0;
    chb[cho++]=0x03;chb[cho++]=0x03;
    memcpy(chb+cho,rnd,32);cho+=32;
    chb[cho++]=32;memcpy(chb+cho,sid,32);cho+=32;
    put16(chb+cho,6);cho+=2;put16(chb+cho,0x1303);cho+=2;put16(chb+cho,0x1301);cho+=2;put16(chb+cho,0x1302);cho+=2;
    chb[cho++]=1;chb[cho++]=0;

    int pad=512;
    if(pad>outsz-eo-4-8)pad=outsz-eo-4-8;
    if(pad<0)pad=0;
    put16(chb+cho,eo+4+pad);cho+=2;
    memcpy(chb+cho,ext,eo);cho+=eo;
    put16(chb+cho,0x0015);cho+=2;
    put16(chb+cho,pad);cho+=2;
    for(int i=0;i<pad;i++)chb[cho++]=(uint8_t)rand();

    int total=9+cho;
    if(total>outsz)return 0;
    out[0]=0x16;out[1]=0x03;out[2]=0x01;
    put16(out+3,4+cho);
    out[5]=1;put24(out+6,cho);
    memcpy(out+9,chb,cho);
    return total;
}

static int do_handshake(tls *s,const char *sni,int httpver){
    int fd=s->fd;
    if(!s->cwk[0]){}/* suppress unused warning */

    /* ---- key pair ---- */
    uint8_t priv[32],pub[32];
    for(int i=0;i<32;i++)priv[i]=rand()&0xff;
    x25519(pub,priv,BASE);

    /* ---- transcript ---- */
    sha256_ctx tr;sha256_init(&tr);

    /* ---- ClientHello ---- */
    uint8_t rnd[32],sid[32];
    for(int i=0;i<32;i++)rnd[i]=rand()&0xff;
    for(int i=0;i<32;i++)sid[i]=rand()&0xff;

    uint8_t ext[512];int eo=0;
    /* SNI */
    int is_ip=1;if(sni){const char *p=sni;while(*p){if(!((*p>='0'&&*p<='9')||*p=='.')){is_ip=0;break;}p++;}}
    int snl=(!is_ip&&sni)?(int)strlen(sni):0;
    if(snl){put16(ext+eo,0);eo+=2;put16(ext+eo,snl+5);eo+=2;put16(ext+eo,snl+3);eo+=2;ext[eo++]=0;put16(ext+eo,snl);eo+=2;memcpy(ext+eo,sni,snl);eo+=snl;}
    put16(ext+eo,0x002b);eo+=2;put16(ext+eo,3);eo+=2;ext[eo++]=2;put16(ext+eo,0x0304);eo+=2;
    put16(ext+eo,0x000a);eo+=2;put16(ext+eo,4);eo+=2;put16(ext+eo,2);eo+=2;put16(ext+eo,0x001d);eo+=2;
    put16(ext+eo,0x000d);eo+=2;put16(ext+eo,10);eo+=2;put16(ext+eo,8);eo+=2;
    put16(ext+eo,0x0804);eo+=2;put16(ext+eo,0x0403);eo+=2;put16(ext+eo,0x0401);eo+=2;put16(ext+eo,0x0805);eo+=2;
    put16(ext+eo,0x002d);eo+=2;put16(ext+eo,2);eo+=2;ext[eo++]=1;ext[eo++]=1;
    put16(ext+eo,0x0033);eo+=2;put16(ext+eo,38);eo+=2;put16(ext+eo,36);eo+=2;
    put16(ext+eo,0x001d);eo+=2;put16(ext+eo,32);eo+=2;memcpy(ext+eo,pub,32);eo+=32;
    if(httpver >= 2){
        put16(ext+eo,0x0010);eo+=2;put16(ext+eo,5);eo+=2;put16(ext+eo,3);eo+=2;ext[eo++]=2;ext[eo++]='h';ext[eo++]='2';
    } else {
        put16(ext+eo,0x0010);eo+=2;put16(ext+eo,11);eo+=2;put16(ext+eo,9);eo+=2;ext[eo++]=8;memcpy(ext+eo,"http/1.1",8);eo+=8;
    }

    uint8_t chb[1024];int cho=0;
    chb[cho++]=0x03;chb[cho++]=0x03;
    memcpy(chb+cho,rnd,32);cho+=32;
    chb[cho++]=32;memcpy(chb+cho,sid,32);cho+=32;
    put16(chb+cho,6);cho+=2;put16(chb+cho,0x1303);cho+=2;put16(chb+cho,0x1301);cho+=2;put16(chb+cho,0x1302);cho+=2;
    chb[cho++]=1;chb[cho++]=0;
    put16(chb+cho,eo);cho+=2;memcpy(chb+cho,ext,eo);cho+=eo;

    uint8_t hs[4+1024];hs[0]=1;put24(hs+1,cho);memcpy(hs+4,chb,cho);

    if(write_rec(fd,0x16,0x01,hs,4+cho)<0){return 0;}
    sha256_upd(&tr,hs,4+cho);

    /* ---- ServerHello ---- */
    uint8_t rec[16640],rt=0;uint16_t cc=0;
    int rl=read_rec(fd,rec,sizeof(rec),&rt,15000);
    if(rl<4||rt!=0x16){return 0;}
    if(rec[0]!=2){return 0;}
    uint32_t shl=g24(rec+1);if((int)shl+4>rl){return 0;}
    
    

    const uint8_t *sp=rec+4;sp+=34;int sdl=*sp++;sp+=sdl;
    cc=g16(sp);sp+=2;sp++;
    
    if(cc!=0x1303){return 0;}

    int elen=g16(sp);sp+=2;const uint8_t *ep=sp,*eend=sp+elen;
    uint8_t spub[32]={0};int found=0;
    while(ep+4<=eend){uint16_t et=g16(ep);ep+=2;int el=g16(ep);ep+=2;
        if(et==0x0033&&el>=36&&g16(ep)==0x001d&&g16(ep+2)==32){memcpy(spub,ep+4,32);found=1;}
        ep+=el;}
    if(!found){return 0;}
    

    sha256_upd(&tr,rec,rl);/* includes record-level handshake header */

    /* ---- derive handshake keys ---- */
    uint8_t shared[32];x25519(shared,priv,spub);
    

    uint8_t z[32]={0},es[32],eh[32],dr[32],hs_[32],chs[32],shs[32],th[32];
    hkdf_ext(NULL,0,z,32,es);
    sha256_dig(NULL,0,eh);
    sha256_ctx tc=tr;sha256_fin(&tc,th);

    hkdf_el(es,(uint8_t*)"derived",7,eh,32,dr,32);
    hkdf_ext(dr,32,shared,32,hs_);
    hkdf_el(hs_,(uint8_t*)"c hs traffic",12,th,32,chs,32);
    hkdf_el(hs_,(uint8_t*)"s hs traffic",12,th,32,shs,32);
    
    

    hkdf_el(chs,(uint8_t*)"key",3,NULL,0,s->cwk,32);
    hkdf_el(chs,(uint8_t*)"iv",2,NULL,0,s->cwi,12);
    hkdf_el(shs,(uint8_t*)"key",3,NULL,0,s->swk,32);
    hkdf_el(shs,(uint8_t*)"iv",2,NULL,0,s->swi,12);
    
    
    

    /* ---- receive encrypted handshake ---- */
    uint8_t plain[16640],itype;int got_fin=0;
    uint8_t fin_verify_data[32];int fin_verify_len=0;
    sha256_ctx tr_before_fin;

    while(!got_fin){
        int pl=tls_recv(s,plain,sizeof(plain),&itype,15000);
        if(pl<0){return 0;}
        if(itype!=0x16)continue;
        int ho=0;
        while(ho+4<=pl){
            uint8_t ht=plain[ho];uint32_t hl=g24(plain+ho+1);
            
            if(ht==0x14){
                tr_before_fin=tr;
                fin_verify_len=hl>32?32:hl;
                memcpy(fin_verify_data,plain+ho+4,fin_verify_len);
                sha256_upd(&tr,plain+ho,4+hl);
                got_fin=1;
                break;
            }
            sha256_upd(&tr,plain+ho,4+hl);
            ho+=4+hl;
        }
    }
    

    /* ---- verify Finished ---- */
    uint8_t fk[32];hkdf_el(shs,(uint8_t*)"finished",8,NULL,0,fk,32);
    sha256_fin(&tr_before_fin,th);
    uint8_t expected_v[32];hmac_sha256(fk,32,th,32,expected_v);
    if(memcmp(fin_verify_data,expected_v,fin_verify_len)!=0){
        
        
        
        return 0;
    }
    

    /* ---- derive app keys (tr now includes server Finished) ---- */
    tc=tr;sha256_fin(&tc,th);



    hkdf_el(hs_,(uint8_t*)"derived",7,eh,32,dr,32);
    uint8_t ms[32];hkdf_ext(dr,32,z,32,ms);
    uint8_t cap[32],sap[32];
    hkdf_el(ms,(uint8_t*)"c ap traffic",12,th,32,cap,32);
    hkdf_el(ms,(uint8_t*)"s ap traffic",12,th,32,sap,32);
    hkdf_el(cap,(uint8_t*)"key",3,NULL,0,s->cwk,32);
    hkdf_el(cap,(uint8_t*)"iv",2,NULL,0,s->cwi,12);
    hkdf_el(sap,(uint8_t*)"key",3,NULL,0,s->swk,32);
    hkdf_el(sap,(uint8_t*)"iv",2,NULL,0,s->swi,12);
    s->cs=0;s->ss=0;

    /* ---- send Client Finished (tr already includes server Finished) ---- */
    uint8_t cfk[32];hkdf_el(chs,(uint8_t*)"finished",8,NULL,0,cfk,32);
    sha256_fin(&tr,th);
    uint8_t cvd[32];hmac_sha256(cfk,32,th,32,cvd);
    uint8_t fin_hs[36];fin_hs[0]=0x14;put24(fin_hs+1,32);memcpy(fin_hs+4,cvd,32);

    uint8_t tk[32],ti[12];memcpy(tk,s->cwk,32);memcpy(ti,s->cwi,12);
    hkdf_el(chs,(uint8_t*)"key",3,NULL,0,s->cwk,32);
    hkdf_el(chs,(uint8_t*)"iv",2,NULL,0,s->cwi,12);
    uint64_t ts=s->cs;s->cs=0;
    if(tls_send(s,0x16,fin_hs,36)<0){return 0;}
    memcpy(s->cwk,tk,32);memcpy(s->cwi,ti,12);s->cs=ts;
    sha256_upd(&tr,fin_hs,36);



    return 1;
}

/* ===== Bot library API ===== */
struct TLSContext { tls t; };
TLSContext *tls_connect(int fd,const char *host,int httpver){
    TLSContext *ctx=calloc(1,sizeof(TLSContext));
    if(!ctx)return NULL;
    ctx->t.fd=fd;
    if(!do_handshake(&ctx->t,host,httpver)){free(ctx);return NULL;}
    return ctx;
}

void tls_h2_frame_hdr(uint8_t *b,int len,uint8_t type,uint8_t flags,uint32_t sid){
    b[0]=(len>>16)&0xff;b[1]=(len>>8)&0xff;b[2]=len&0xff;
    b[3]=type;b[4]=flags;
    b[5]=(sid>>24)&0x7f;b[6]=(sid>>16)&0xff;b[7]=(sid>>8)&0xff;b[8]=sid&0xff;
}

static int h2_lit(uint8_t *out,int p,int sz,const char *name,const char *val){
    int nl=(int)strlen(name),vl=(int)strlen(val);
    if(p+2+nl+1+vl>sz)return -1;
    out[p++]=0x00;out[p++]=(uint8_t)nl;
    memcpy(out+p,name,(size_t)nl);p+=nl;
    out[p++]=(uint8_t)vl;
    memcpy(out+p,val,(size_t)vl);p+=vl;
    return p;
}

/* Chrome header order: :method, :authority, :scheme, :path, sec-ch-ua*, upgrade-insecure-requests, user-agent, accept, sec-fetch-*, accept-encoding, accept-language */
int tls_h2_hpack_encode_get(uint8_t *out,int sz,const char *path,const char *host){
    int p=0;
    if(p>=sz)return-1;out[p++]=0x82;
    int hl=(int)strlen(host);if(p+2+hl>sz)return-1;out[p++]=0x41;if(hl<254){out[p++]=(uint8_t)hl;}else{return-1;}memcpy(out+p,host,(size_t)hl);p+=hl;
    if(p>=sz)return-1;out[p++]=0x87;
    if(path&&path[0]=='/'&&path[1]==0){
        if(p>=sz)return-1;out[p++]=0x84;
    }else{int pl=(int)strlen(path);if(p+2+pl>sz)return-1;out[p++]=0x44;if(pl<254){out[p++]=(uint8_t)pl;}else{return-1;}memcpy(out+p,path,(size_t)pl);p+=pl;}

    p=h2_lit(out,p,sz,"sec-ch-ua","\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"");if(p<0)return-1;
    p=h2_lit(out,p,sz,"sec-ch-ua-mobile","?0");if(p<0)return-1;
    p=h2_lit(out,p,sz,"sec-ch-ua-platform","\"Windows\"");if(p<0)return-1;
    p=h2_lit(out,p,sz,"upgrade-insecure-requests","1");if(p<0)return-1;

    const char *ua="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    int ul=(int)strlen(ua);if(p+2+ul>sz)return-1;out[p++]=0x7a;if(ul<254){out[p++]=(uint8_t)ul;}else{return-1;}memcpy(out+p,ua,(size_t)ul);p+=ul;

    const char *accept="text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8";
    int axl=(int)strlen(accept);if(p+2+axl>sz)return-1;out[p++]=0x53;if(axl<254){out[p++]=(uint8_t)axl;}else{return-1;}memcpy(out+p,accept,(size_t)axl);p+=axl;

    p=h2_lit(out,p,sz,"sec-fetch-site","none");if(p<0)return-1;
    p=h2_lit(out,p,sz,"sec-fetch-mode","navigate");if(p<0)return-1;
    p=h2_lit(out,p,sz,"sec-fetch-user","?1");if(p<0)return-1;
    p=h2_lit(out,p,sz,"sec-fetch-dest","document");if(p<0)return-1;

    const char *ac="gzip, deflate, br";int al=(int)strlen(ac);if(p+2+al>sz)return-1;out[p++]=0x50;if(al<254){out[p++]=(uint8_t)al;}else{return-1;}memcpy(out+p,ac,(size_t)al);p+=al;
    const char *al2="en-US,en;q=0.9";int a2l=(int)strlen(al2);if(p+2+a2l>sz)return-1;out[p++]=0x51;if(a2l<254){out[p++]=(uint8_t)a2l;}else{return-1;}memcpy(out+p,al2,(size_t)a2l);p+=a2l;
    return p;
}
int tls_write(TLSContext *ctx,const unsigned char *data,int len){
    return tls_send(&ctx->t,0x17,data,len);
}
int tls_read(TLSContext *ctx,unsigned char *buf,int bufsize){
    uint8_t it;
    return tls_recv(&ctx->t,buf,bufsize,&it,15000);
}
int tls_read_nonblock(TLSContext *ctx,unsigned char *buf,int bufsize){
    uint8_t it;
    return tls_recv(&ctx->t,buf,bufsize,&it,1);
}
void tls_close(TLSContext *ctx){
    if(ctx)free(ctx);
}

