#pragma once

#ifndef TLS_H
#define TLS_H

#include <stdint.h>
#include <sys/socket.h>

typedef struct TLSContext TLSContext;

TLSContext *tls_connect(int fd, const char *host, int httpver);
void tls_close(TLSContext *ctx);
int tls_write(TLSContext *ctx, const unsigned char *data, int len);
int tls_read(TLSContext *ctx, unsigned char *buf, int bufsize);
int tls_read_nonblock(TLSContext *ctx, unsigned char *buf, int bufsize);
void tls_h2_frame_hdr(uint8_t *b, int len, uint8_t type, uint8_t flags, uint32_t sid);
int tls_h2_hpack_encode_get(uint8_t *out, int sz, const char *path, const char *host);

#endif
